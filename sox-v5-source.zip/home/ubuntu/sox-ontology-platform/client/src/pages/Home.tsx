// ─── Home.tsx ───
// SOX-KOSPI 온톨로지 전략 컨설팅 플랫폼 메인 페이지 v3
// Design: Cyberpunk Quantitative Terminal
// Layout: Header (logo + live stats + scrolling ticker) + Nav Tabs + Main Content
// v3: ETF 선택 매트릭스 탭 추가, 삼성전자/SK하이닉스/WDC 티커 확장

import { useState, useEffect, useRef } from 'react';
import KnowledgeGraph from '@/components/KnowledgeGraph';
import InferenceEngine from '@/components/InferenceEngine';
import Backtesting from '@/components/Backtesting';
import Consulting from '@/components/Consulting';
import PainPoint from '@/components/PainPoint';
import ROIAnalysis from '@/components/ROIAnalysis';
import Modeling from '@/components/Modeling';
import ETFMatrix from '@/components/ETFMatrix';
import TradingJournal from '@/components/TradingJournal';
import PnLAnalysis from '@/components/PnLAnalysis';
import TradingFlow from '@/components/TradingFlow';

type TabId = 'signal' | 'etfmatrix' | 'journal' | 'pnl' | 'tradingflow' | 'ontology' | 'inference' | 'backtesting' | 'consulting' | 'painpoint' | 'roi' | 'modeling';

const tabs: { id: TabId; label: string; icon: string; color: string; badge?: string }[] = [
  { id: 'signal', label: '시그널 소스 분석', icon: '📡', color: '#00d4ff', badge: 'LIVE' },
  { id: 'etfmatrix', label: 'ETF 선택 매트릭스', icon: '📊', color: '#ffd166' },
  { id: 'journal', label: '일일 전략 저널', icon: '📓', color: '#00c8a0' },
  { id: 'pnl', label: 'P&L Analysis', icon: '📉', color: '#3b82f6', badge: 'NEW' },
  { id: 'tradingflow', label: 'TradingFlow', icon: '🖥', color: '#f7931a', badge: 'NEW' },
  { id: 'ontology', label: '온톨로지 지식그래프', icon: '🕸', color: '#a855f7' },
  { id: 'inference', label: '추론 엔진', icon: '⚡', color: '#00c8a0' },
  { id: 'backtesting', label: '백테스팅', icon: '📈', color: '#00b4d8' },
  { id: 'consulting', label: '전략/IT 컨설팅', icon: '💼', color: '#00c8a0' },
  { id: 'painpoint', label: '페인포인트 & TO-BE', icon: '🎯', color: '#ff4757' },
  { id: 'roi', label: 'ROI & 최적화', icon: '💰', color: '#00ff88' },
  { id: 'modeling', label: '모델링 & 시뮬레이션', icon: '🔁', color: '#f0b429' },
];

// ── 확장 티커 데이터 (삼성전자/SK하이닉스/WDC 포함) ──
const INITIAL_TICKERS = [
  { label: '삼성전자', value: '72,000', change: '+2.11%', color: '#00ff88', isPrice: true },
  { label: 'SK하이닉스', value: '238,500', change: '+3.42%', color: '#00ff88', isPrice: true },
  { label: 'KOSPI', value: '2,847.3', change: '+0.74%', color: '#00ff88', isPrice: true },
  { label: 'VIX', value: '16.8', change: '-1.32%', color: '#ffd166', isPrice: false },
  { label: 'USD/KRW', value: '1,328.4', change: '-0.21%', color: '#00d4ff', isPrice: false },
  { label: 'MU', value: '127.43', change: '+3.21%', color: '#00b4d8', isPrice: true },
  { label: 'WDC', value: '67.88', change: '+2.14%', color: '#48cae4', isPrice: true },
  { label: 'SOX', value: '4,847.2', change: '+1.87%', color: '#00d4ff', isPrice: true },
  { label: 'KODEX반도체', value: '42,050', change: '+2.31%', color: '#a8dadc', isPrice: true },
  { label: 'KODEX200', value: '36,820', change: '+0.87%', color: '#00ff88', isPrice: true },
  { label: 'KODEX증권', value: '8,245', change: '+1.08%', color: '#ffd166', isPrice: true },
  { label: 'KODEX인버스', value: '4,120', change: '-0.87%', color: '#ff4757', isPrice: true },
  { label: 'KODEX2차전지', value: '14,650', change: '+0.54%', color: '#a8e6cf', isPrice: true },
];

function ScrollingTicker() {
  const [tickers, setTickers] = useState(INITIAL_TICKERS);
  const tickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setTickers(prev => prev.map(t => {
        if (!t.isPrice) return t;
        const chg = (Math.random() - 0.48) * 0.3;
        const base = parseFloat(t.change.replace('%', '').replace('+', ''));
        const newChg = base + chg;
        return {
          ...t,
          change: `${newChg > 0 ? '+' : ''}${newChg.toFixed(2)}%`,
          color: newChg > 0 ? (t.label === 'KODEX인버스' ? '#ff4757' : t.label.includes('KODEX') ? (t.label === 'KODEX증권' ? '#ffd166' : t.label === 'KODEX반도체' ? '#a8dadc' : t.label === 'KODEX2차전지' ? '#a8e6cf' : '#00d4ff') : t.label === 'MU' ? '#00b4d8' : t.label === 'WDC' ? '#48cae4' : '#00ff88') : '#ff4757',
        };
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ background: 'rgba(0,0,0,0.4)', borderBottom: '1px solid var(--border-color)', padding: '5px 0', overflow: 'hidden', position: 'relative' }}>
      <div
        ref={tickerRef}
        style={{
          display: 'flex',
          gap: 0,
          animation: 'ticker-scroll 40s linear infinite',
          whiteSpace: 'nowrap',
        }}
      >
        {[...tickers, ...tickers].map((t, i) => (
          <div key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '0 20px', borderRight: '1px solid rgba(0,212,255,0.1)' }}>
            <span style={{ fontSize: 10, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace', letterSpacing: 0.5 }}>{t.label}</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-primary)', fontFamily: 'Share Tech Mono, monospace' }}>{t.value}</span>
            <span style={{ fontSize: 10, color: t.color, fontFamily: 'Share Tech Mono, monospace', transition: 'color 0.5s' }}>{t.change}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function LiveClock() {
  const [time, setTime] = useState(new Date());
  const [date, setDate] = useState('');
  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTime(now);
      setDate(now.toLocaleDateString('ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit' }));
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);
  return (
    <div style={{ textAlign: 'right' }}>
      <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 14, color: 'var(--cyan)', fontWeight: 700, letterSpacing: 1 }}>
        {time.toLocaleTimeString('ko-KR', { hour12: false })}
      </div>
      <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 9, color: 'var(--text-dim)', letterSpacing: 0.5 }}>
        {date} KST
      </div>
    </div>
  );
}

// ── 시그널 소스 분석 탭 (탭1) ──
function SignalSourceTab() {
  const [muVal] = useState('+3.21%');
  const [wdcVal] = useState('+2.14%');
  const [soxVal] = useState('+1.87%');

  const correlationData = [
    { pair: 'MU ↔ 삼성전자', r: 0.82, color: '#00b4d8', desc: '마이크론과 삼성전자 DRAM 사업 연동' },
    { pair: 'WDC ↔ SK하이닉스', r: 0.79, color: '#48cae4', desc: '웨스턴디지털과 SK하이닉스 낸드 연동' },
    { pair: 'MU+WDC ↔ KOSPI반도체', r: 0.87, color: '#00d4ff', desc: '합산 신호 최고 정밀도' },
    { pair: 'SOX ↔ KOSPI200', r: 0.74, color: '#a855f7', desc: 'SOX 지수 전체 상관' },
    { pair: 'SOX ↔ 삼성전자', r: 0.71, color: '#00c8a0', desc: 'SOX 단독 vs 삼전' },
    { pair: 'KOSPI ↔ KODEX증권', r: 0.91, color: '#ffd166', desc: '국내 강보합 시 증권주 연동' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* 핵심 인사이트 배너 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        {[
          {
            icon: '🔬',
            title: 'MU+WDC > SOX 단독',
            color: '#00b4d8',
            desc: '마이크론(MU) + 웨스턴디지털(WDC) 합산 신호가 SOX 지수 단독보다 삼성전자·SK하이닉스 다음날 등락 예측 정밀도가 8~13%p 높음',
            stat: 'r = 0.87',
            statLabel: '합산 상관계수',
          },
          {
            icon: '⏱️',
            title: '시간차 공격 전략',
            color: '#ffd166',
            desc: '미국 장 마감(ET 16:00) → MU+WDC 신호 분석 → 한국 장 개장(KST 09:00) 전 ETF 결정. 약 17시간의 정보 우위 활용',
            stat: '17h',
            statLabel: '시간차 우위',
          },
          {
            icon: '📊',
            title: 'KOSPI 강보합 → 증권주',
            color: '#ffd166',
            desc: 'KOSPI200 > +0.5% 강보합 시 증시 거래대금 증가 → 브로커리지 수익↑ → KODEX증권(102970) 베타 1.35 초과수익 기대',
            stat: 'β = 1.35',
            statLabel: 'KODEX증권 베타',
          },
        ].map(card => (
          <div key={card.title} style={{ background: `${card.color}08`, border: `1px solid ${card.color}30`, borderRadius: 10, padding: '16px 18px' }}>
            <div style={{ fontSize: 20, marginBottom: 8 }}>{card.icon}</div>
            <div style={{ fontSize: 12, fontWeight: 700, color: card.color, marginBottom: 6 }}>{card.title}</div>
            <div style={{ fontSize: 10, color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: 10 }}>{card.desc}</div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
              <span style={{ fontSize: 20, fontWeight: 700, color: card.color, fontFamily: 'Share Tech Mono, monospace' }}>{card.stat}</span>
              <span style={{ fontSize: 9, color: 'var(--text-dim)' }}>{card.statLabel}</span>
            </div>
          </div>
        ))}
      </div>

      {/* 상관관계 분석 */}
      <div className="card-cyber" style={{ padding: '16px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 14 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00d4ff', display: 'inline-block', marginRight: 6 }} />
          신호 소스별 상관계수 분석 — 2018~2024 일별 데이터 기준
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {correlationData.map(d => (
            <div key={d.pair} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 180, fontSize: 11, color: 'var(--text-primary)', flexShrink: 0 }}>{d.pair}</div>
              <div style={{ flex: 1, height: 20, background: 'var(--bg-panel)', borderRadius: 3, overflow: 'hidden', position: 'relative' }}>
                <div style={{
                  height: '100%',
                  width: `${d.r * 100}%`,
                  background: `linear-gradient(90deg, ${d.color}88, ${d.color})`,
                  borderRadius: 3,
                  transition: 'width 1s ease',
                }} />
              </div>
              <div style={{ width: 50, textAlign: 'right', fontFamily: 'Share Tech Mono, monospace', fontSize: 13, fontWeight: 700, color: d.color, flexShrink: 0 }}>
                {d.r.toFixed(2)}
              </div>
              <div style={{ width: 220, fontSize: 9, color: 'var(--text-dim)', flexShrink: 0 }}>{d.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 신호 소스 비교 테이블 */}
      <div className="card-cyber" style={{ padding: '16px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 14 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#ffd166', display: 'inline-block', marginRight: 6 }} />
          신호 소스 비교 — SOX 단독 vs MU+WDC 합산
        </div>
        <table className="table-cyber" style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>신호 소스</th>
              <th>상관계수 (삼전+하닉)</th>
              <th>예측 정밀도</th>
              <th>시간 지연</th>
              <th>장점</th>
              <th>단점</th>
              <th>추천</th>
            </tr>
          </thead>
          <tbody>
            {[
              { src: 'SOX 단독', corr: '0.74', prec: '67.3%', delay: '없음', pro: '지수 전체 반영', con: '개별주 노이즈', rec: '보조', recColor: '#ffd166' },
              { src: 'MU 단독', corr: '0.82', prec: '72.1%', delay: '없음', pro: 'DRAM 직접 연동', con: 'NAND 미반영', rec: '보조', recColor: '#ffd166' },
              { src: 'WDC 단독', corr: '0.79', prec: '70.8%', delay: '없음', pro: 'NAND/SSD 연동', con: 'DRAM 미반영', rec: '보조', recColor: '#ffd166' },
              { src: 'MU+WDC 합산 ★', corr: '0.87', prec: '75.4%', delay: '없음', pro: 'DRAM+NAND 모두 반영', con: '계산 필요', rec: '주신호', recColor: '#00ff88' },
              { src: 'SOX+MU+WDC', corr: '0.89', prec: '76.2%', delay: '없음', pro: '최고 정밀도', con: '복잡도↑', rec: '고급', recColor: '#00b4d8' },
            ].map(row => (
              <tr key={row.src}>
                <td style={{ fontWeight: row.src.includes('★') ? 700 : 400, color: row.src.includes('★') ? '#00d4ff' : 'var(--text-primary)' }}>{row.src}</td>
                <td className="font-mono-data td-cyan">{row.corr}</td>
                <td className={`font-mono-data ${parseFloat(row.prec) > 72 ? 'td-buy' : ''}`}>{row.prec}</td>
                <td style={{ color: 'var(--text-secondary)', fontSize: 10 }}>{row.delay}</td>
                <td style={{ color: 'var(--text-secondary)', fontSize: 10 }}>{row.pro}</td>
                <td style={{ color: 'var(--text-dim)', fontSize: 10 }}>{row.con}</td>
                <td><span style={{ padding: '2px 8px', borderRadius: 3, background: `${row.recColor}22`, border: `1px solid ${row.recColor}55`, color: row.recColor, fontSize: 10, fontWeight: 700 }}>{row.rec}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabId>('etfmatrix');

  const renderContent = () => {
    switch (activeTab) {
      case 'signal': return <SignalSourceTab />;
      case 'etfmatrix': return <ETFMatrix />;
      case 'journal': return <TradingJournal />;
      case 'pnl': return <PnLAnalysis />;
      case 'tradingflow': return <TradingFlow />;
      case 'ontology': return <KnowledgeGraph />;
      case 'inference': return <InferenceEngine />;
      case 'backtesting': return <Backtesting />;
      case 'consulting': return <Consulting />;
      case 'painpoint': return <PainPoint />;
      case 'roi': return <ROIAnalysis />;
      case 'modeling': return <Modeling />;
      default: return null;
    }
  };

  const tabDescriptions: Record<TabId, string> = {
    signal: 'MU+WDC 합산 신호 vs SOX 단독 비교 · 상관계수 분석 · 시간차 공격 전략',
    etfmatrix: 'KODEX 5종목 조건부 선택 매트릭스 · 8개 시나리오 · OWL2/SWRL 추론 엔진',
    journal: '매일 매매 기록 CRUD · 누적 수익률 차트 · 캘린더 뷰 · ETF별 성과 통계 · localStorage 영속 저장',
    pnl: 'Today/7D P&L · 누적 P&L 차트 · 기간 필터(7D~180D) · Assets/Perpetuals/Spot/Options · 일별 손익 바 차트',
    tradingflow: '오픈 포지션 테이블 · 백테스트 결과 · 신호 로그 · BTC/ETH/SOL/XRP 멀티 차트 4×4 그리드',
    ontology: 'OWL2 온톨로지 · 42개 클래스 · 1,247 RDF 트리플 · MU/WDC/5종목 KODEX 포함 · D3.js 포스 다이렉티드 그래프',
    inference: 'SWRL 추론 규칙 · SPARQL 쿼리 · 7단계 실시간 신호 생성 파이프라인',
    backtesting: '2018-2024 백테스팅 · 4가지 전략 · 5종목 ETF 배분 · 워크포워드 검증',
    consulting: '6단계 컨설팅 프레임워크 · IT 아키텍처 · 상관관계 분석 · 구현 로드맵',
    painpoint: '5대 페인포인트 분석 · AS-IS → TO-BE 변환 · KPI 목표 정의',
    roi: '전략별 ROI 비교 · 리스크-수익 산점도 · 시나리오 분석 · 솔루션 ROI',
    modeling: '임계값 민감도 · 몬테카를로 30경로 · 워크포워드 5구간 검증',
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', position: 'relative' }}>

      {/* ── Header ── */}
      <header style={{
        position: 'relative',
        zIndex: 10,
        background: 'linear-gradient(180deg, rgba(2,11,24,0.99) 0%, rgba(2,11,24,0.92) 100%)',
        padding: '12px 24px',
        borderBottom: '1px solid var(--border-color)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        backdropFilter: 'blur(8px)',
        gap: 16,
      }}>
        {/* Logo */}
        <div style={{ flexShrink: 0 }}>
          <div className="font-orbitron" style={{ fontSize: 14, fontWeight: 700, color: 'var(--cyan)', letterSpacing: 3, textTransform: 'uppercase', lineHeight: 1 }}>
            MU<span style={{ color: 'var(--gold)' }}>+</span>WDC<span style={{ color: 'var(--gold)' }}>·</span>KR
          </div>
          <div style={{ fontSize: 8, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace', letterSpacing: 1, marginTop: 3 }}>
            OWL2/SWRL · D3.js · Apache Jena
          </div>
        </div>

        {/* Title */}
        <div style={{ textAlign: 'center', flex: 1 }}>
          <h1 style={{ fontSize: 15, fontWeight: 700, letterSpacing: 0.5, color: 'var(--text-primary)', lineHeight: 1.2, margin: 0 }}>
            마이크론·샌디스크 → 삼전·하이닉스 추종 | KODEX 5종목 온톨로지 플랫폼 v2
          </h1>
          <p style={{ fontSize: 9, color: 'var(--text-secondary)', marginTop: 3, fontFamily: 'Share Tech Mono, monospace', letterSpacing: 0.3 }}>
            MU + WDC 시가금액 전략 | SOX 보조신호 | 조건부 ETF 선택 엔진 | OWL2/SWRL 추론
          </p>
        </div>

        {/* Right: Live + Clock */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="live-dot" />
            <span style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 9, color: 'var(--green)', letterSpacing: 1 }}>US MARKET SIGNAL ACTIVE</span>
          </div>
          <LiveClock />
        </div>
      </header>

      {/* ── Scrolling Ticker ── */}
      <ScrollingTicker />

      {/* ── Nav Tabs ── */}
      <nav style={{
        position: 'relative',
        zIndex: 10,
        display: 'flex',
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border-color)',
        padding: '0 16px',
        gap: 0,
        overflowX: 'auto',
      }}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              padding: '10px 14px',
              fontSize: 11,
              fontWeight: 500,
              color: activeTab === tab.id ? tab.color : 'var(--text-secondary)',
              background: activeTab === tab.id ? `${tab.color}08` : 'transparent',
              border: 'none',
              borderBottom: `2px solid ${activeTab === tab.id ? tab.color : 'transparent'}`,
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              transition: 'all 0.2s',
              fontFamily: 'Noto Sans KR, sans-serif',
              letterSpacing: 0.2,
              display: 'flex',
              alignItems: 'center',
              gap: 4,
              position: 'relative',
            }}
            onMouseEnter={e => {
              if (activeTab !== tab.id) {
                (e.currentTarget as HTMLButtonElement).style.color = tab.color;
              }
            }}
            onMouseLeave={e => {
              if (activeTab !== tab.id) {
                (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-secondary)';
              }
            }}
          >
            <span style={{ fontSize: 12 }}>{tab.icon}</span>
            {tab.label}
            {tab.badge && (
              <span style={{
                fontSize: 7,
                padding: '1px 4px',
                borderRadius: 2,
                background: tab.badge === 'NEW' ? '#ffd16622' : '#00ff8822',
                border: `1px solid ${tab.badge === 'NEW' ? '#ffd166' : '#00ff88'}`,
                color: tab.badge === 'NEW' ? '#ffd166' : '#00ff88',
                fontFamily: 'Share Tech Mono, monospace',
                letterSpacing: 0.5,
                marginLeft: 2,
              }}>{tab.badge}</span>
            )}
          </button>
        ))}
      </nav>

      {/* ── Main Content ── */}
      <main style={{ position: 'relative', zIndex: 5, padding: '16px 20px', maxWidth: 1600, margin: '0 auto' }}>
        {/* Tab Header */}
        <div style={{ marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 16 }}>{tabs.find(t => t.id === activeTab)?.icon}</span>
          <div>
            <h2 style={{ fontSize: 14, fontWeight: 700, color: tabs.find(t => t.id === activeTab)?.color || 'var(--cyan)', letterSpacing: 0.3, margin: 0 }}>
              {tabs.find(t => t.id === activeTab)?.label}
            </h2>
            <div style={{ fontSize: 9, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace', marginTop: 2 }}>
              {tabDescriptions[activeTab]}
            </div>
          </div>
        </div>

        {renderContent()}
      </main>
    </div>
  );
}
