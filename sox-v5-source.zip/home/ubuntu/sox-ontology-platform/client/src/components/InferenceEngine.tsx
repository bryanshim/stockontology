// ─── InferenceEngine.tsx ───
// SOX/MU/SNDK 신호 추론 과정 단계별 시각화 (v2 확장판)
// 마이크론+샌디스크 합산 신호 + KOSPI 강보합 → KODEX증권 매수 로직 포함
// Design: Cyberpunk Terminal — step-by-step reasoning with neon highlights

import { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { signalLogData } from '@/lib/ontologyData';

const inferenceSteps = [
  {
    id: 1,
    title: '미국 시장 데이터 수집',
    desc: 'SOX 지수 + Micron(MU) + SanDisk(SNDK) 전일 종가 및 등락률 수집',
    input: 'SOX: 4,892.31 → 5,049.18\nMU: $104.21 → $108.42\nSNDK: $46.01 → $47.83',
    output: 'sox_return = +3.21%\nmu_return = +4.12%\nsndk_return = +3.87%',
    color: '#00d4ff',
    icon: '📡',
    sparql: 'SELECT ?sox_r ?mu_r ?sndk_r WHERE {\n  :SOX :hasDailyReturn ?sox_r .\n  :Micron :hasDailyReturn ?mu_r .\n  :SanDisk :hasDailyReturn ?sndk_r\n}',
  },
  {
    id: 2,
    title: 'MU+SNDK 합산 신호 계산',
    desc: 'Micron + SanDisk 등락률 합산 → 삼전·하이닉스 예측 정밀도 향상',
    input: 'mu_return = +4.12%\nsndk_return = +3.87%\ncombined = (4.12+3.87)/2',
    output: 'combined_signal = +3.995%\n→ STRONG BUY (반도체 강세)',
    color: '#00b4d8',
    icon: '🔗',
    sparql: 'CONSTRUCT { :combined :hasValue ?avg } WHERE {\n  :Micron :hasDailyReturn ?r1 .\n  :SanDisk :hasDailyReturn ?r2 .\n  BIND((?r1+?r2)/2 AS ?avg)\n}',
  },
  {
    id: 3,
    title: 'SWRL 규칙 매칭',
    desc: 'OWL2/SWRL 규칙 엔진에서 SOX/MU/SNDK 조건 동시 평가',
    input: 'R1: sox_return > 0.0 → MATCHED\nR3: mu>2% AND sndk>2% → MATCHED\nR5: MA20 ABOVE → MATCHED',
    output: 'Rule R1 ✓ R3 ✓ R5 ✓\n→ KODEX반도체 STRONG BUY',
    color: '#a855f7',
    icon: '⚙️',
    sparql: 'CONSTRUCT { :signal :hasType :BUY_SEMI }\nWHERE {\n  :SOX :hasDailyReturn ?r . FILTER(?r > 0.0) .\n  :combined :hasValue ?c . FILTER(?c > 2.0)\n}',
  },
  {
    id: 4,
    title: 'KOSPI200 강보합 판정',
    desc: '국내 KOSPI200 등락률 확인 → +0.5% 이상 시 강보합 판정',
    input: 'KOSPI200_return = +0.64%\n임계값: +0.5%\n0.64% > 0.5% → 강보합!',
    output: 'KOSPI_STATUS = STRONG_BULL\n→ KODEX증권 매수 신호 생성',
    color: '#ffd166',
    icon: '📊',
    sparql: 'ASK {\n  :KOSPI200 :hasDailyReturn ?r .\n  FILTER(?r > 0.5)\n}\n→ TRUE: BUY_KODEX_SECURITIES',
  },
  {
    id: 5,
    title: 'VIX 리스크 체크',
    desc: 'VIX 공포지수 확인 및 포지션 사이징 결정',
    input: 'VIX = 18.42 < 30.0 (임계값)\nRisk Level: NORMAL',
    output: 'Position Size: 100%\n(VIX < 20 → Full Position)',
    color: '#00ff88',
    icon: '🛡️',
    sparql: 'SELECT ?risk ?posSize WHERE {\n  :VIX :hasValue ?v .\n  BIND(IF(?v>30,"HIGH",IF(?v>20,"MID","LOW")) AS ?risk)\n  BIND(IF(?v>30,0.5,IF(?v>20,0.7,1.0)) AS ?posSize)\n}',
  },
  {
    id: 6,
    title: '5종목 최적 ETF 선택',
    desc: '모든 신호 종합 → 5종목 중 최적 ETF 포트폴리오 결정',
    input: 'SOX+MU+SNDK: STRONG BUY\nKOSPI: STRONG_BULL\nVIX: NORMAL',
    output: 'ETF 배분:\n- KODEX반도체 50%\n- KODEX증권 30%\n- KODEX200 20%',
    color: '#00c8a0',
    icon: '🎯',
    sparql: 'SELECT ?etf ?weight WHERE {\n  :portfolio :hasETF ?etf .\n  :portfolio :hasWeight ?weight .\n  ORDER BY DESC(?weight)\n}',
  },
  {
    id: 7,
    title: '포지션 실행 & RDF 저장',
    desc: 'KRX 오전 9시 시장가 매수 주문 실행 및 온톨로지 트리플 저장',
    input: 'ORDER: KODEX반도체 50%\n       KODEX증권 30%\n       KODEX200 20%',
    output: 'EXECUTED: +1.87% 수익 실현\nRDF Triple 저장 완료',
    color: '#00c8a0',
    icon: '🚀',
    sparql: 'INSERT DATA {\n  :trade_20241227 :hasReturn "+1.87%"^^xsd:decimal .\n  :trade_20241227 :hasETF :KODEX_SEMI, :KODEX_SEC .\n  :trade_20241227 :executedAt "2024-12-27T09:00:01"^^xsd:dateTime\n}',
  },
];

// 5종목 의사결정 트리 노드
const decisionNodes = [
  { x: 50, y: 8, label: 'SOX/MU/SNDK\n등락률', color: '#00d4ff', w: 22 },
  { x: 20, y: 25, label: 'SOX > 0%', color: '#00ff88', w: 14 },
  { x: 50, y: 25, label: 'MU+SNDK\n> +2%', color: '#00b4d8', w: 16 },
  { x: 80, y: 25, label: 'SOX < 0%', color: '#ff4757', w: 14 },
  { x: 20, y: 45, label: 'KOSPI\n강보합?', color: '#ffd166', w: 14 },
  { x: 50, y: 45, label: 'KODEX\n반도체↑', color: '#a8dadc', w: 14 },
  { x: 80, y: 45, label: 'SOX < -2%?', color: '#ff4757', w: 14 },
  { x: 10, y: 65, label: 'KODEX\n증권↑', color: '#ffd166', w: 14 },
  { x: 30, y: 65, label: 'KODEX\n200↑', color: '#00d4ff', w: 14 },
  { x: 65, y: 65, label: 'KODEX\n인버스↑', color: '#ff4757', w: 14 },
  { x: 85, y: 65, label: '전량\n인버스↑', color: '#ff4757', w: 14 },
  { x: 50, y: 82, label: 'KODEX\n2차전지↑', color: '#a8e6cf', w: 16 },
];

function generateMultiData() {
  const data = [];
  let sox = 4500, mu = 100, sndk = 44;
  const now = new Date('2024-12-01');
  for (let i = 0; i < 30; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() + i);
    const soxChg = (Math.random() - 0.45) * 80;
    const muChg = (Math.random() - 0.45) * 4;
    const sndkChg = (Math.random() - 0.45) * 2;
    sox += soxChg; mu += muChg; sndk += sndkChg;
    const combined = (muChg / mu + sndkChg / sndk) / 2 * 100;
    data.push({
      date: d.toLocaleDateString('ko-KR', { month: '2-digit', day: '2-digit' }),
      sox: Math.round(sox),
      mu: Math.round(mu * 100) / 100,
      combined: Math.round(combined * 100) / 100,
      signal: soxChg > 0 ? 1 : -1,
    });
  }
  return data;
}

export default function InferenceEngine() {
  const [activeStep, setActiveStep] = useState<number>(-1);
  const [isRunning, setIsRunning] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [multiData] = useState(generateMultiData);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const runInference = () => {
    if (isRunning) return;
    setIsRunning(true);
    setCompletedSteps([]);
    setActiveStep(0);
    let step = 0;
    intervalRef.current = setInterval(() => {
      setCompletedSteps(prev => [...prev, step]);
      step++;
      setActiveStep(step);
      if (step >= inferenceSteps.length) {
        clearInterval(intervalRef.current!);
        setIsRunning(false);
        setActiveStep(-1);
      }
    }, 900);
  };

  useEffect(() => {
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const d = payload[0].payload;
      return (
        <div style={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, padding: '8px 12px', fontSize: 11 }}>
          <div style={{ color: 'var(--text-secondary)', marginBottom: 4 }}>{label}</div>
          <div style={{ color: 'var(--cyan)', fontFamily: 'Share Tech Mono, monospace' }}>SOX: {d.sox?.toLocaleString()}</div>
          <div style={{ color: '#00b4d8', fontFamily: 'Share Tech Mono, monospace' }}>MU: ${d.mu}</div>
          <div style={{ color: d.signal > 0 ? 'var(--green)' : 'var(--red)', marginTop: 2 }}>
            신호: {d.signal > 0 ? '▲ 매수' : '▼ 인버스'}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* Header Banner */}
      <div style={{ background: 'linear-gradient(135deg, rgba(0,180,216,0.08), rgba(168,85,247,0.06))', border: '1px solid rgba(0,180,216,0.2)', borderRadius: 8, padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#00b4d8', marginBottom: 3 }}>
            MU + SNDK 합산 신호 엔진
          </div>
          <div style={{ fontSize: 10, color: 'var(--text-secondary)' }}>
            마이크론(MU) + 샌디스크(SNDK) 주가 합산 → SOX보다 삼성전자·SK하이닉스 예측 정밀도 높음
          </div>
        </div>
        <div style={{ display: 'flex', gap: 16, fontSize: 11 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ color: '#00b4d8', fontWeight: 700, fontFamily: 'Share Tech Mono, monospace' }}>0.82</div>
            <div style={{ color: 'var(--text-dim)', fontSize: 9 }}>MU↔삼전</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ color: '#48cae4', fontWeight: 700, fontFamily: 'Share Tech Mono, monospace' }}>0.78</div>
            <div style={{ color: 'var(--text-dim)', fontSize: 9 }}>SNDK↔삼전</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ color: '#00d4ff', fontWeight: 700, fontFamily: 'Share Tech Mono, monospace' }}>0.74</div>
            <div style={{ color: 'var(--text-dim)', fontSize: 9 }}>SOX↔KOSPI</div>
          </div>
        </div>
      </div>

      {/* Inference Pipeline */}
      <div className="card-cyber" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--cyan)', display: 'inline-block' }} />
            추론 파이프라인 — SOX/MU/SNDK → KOSPI → 5종목 ETF 선택
          </div>
          <button className="btn-cyber-run" onClick={runInference} disabled={isRunning}>
            {isRunning ? '⚡ 추론 실행 중...' : '▶ 7단계 추론 시뮬레이션 실행'}
          </button>
        </div>

        <div style={{ display: 'flex', alignItems: 'stretch', gap: 0, overflowX: 'auto', paddingBottom: 8 }}>
          {inferenceSteps.map((step, idx) => (
            <div key={step.id} style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>
              <div style={{
                background: completedSteps.includes(idx) ? `${step.color}20` : activeStep === idx ? `${step.color}15` : 'var(--bg-panel)',
                border: `1px solid ${completedSteps.includes(idx) ? step.color : activeStep === idx ? step.color : 'var(--border-color)'}`,
                borderRadius: 8, padding: '10px 12px', minWidth: 120, textAlign: 'center',
                transition: 'all 0.4s',
                boxShadow: activeStep === idx ? `0 0 16px ${step.color}44` : completedSteps.includes(idx) ? `0 0 8px ${step.color}22` : 'none',
                position: 'relative',
              }}>
                <div style={{ fontSize: 16, marginBottom: 3 }}>{step.icon}</div>
                <div style={{ fontSize: 9, fontWeight: 700, color: completedSteps.includes(idx) || activeStep === idx ? step.color : 'var(--text-secondary)', marginBottom: 2 }}>
                  STEP {step.id}
                </div>
                <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 3 }}>{step.title}</div>
                <div style={{ fontSize: 8.5, color: 'var(--text-dim)', lineHeight: 1.4 }}>{step.desc}</div>
                {completedSteps.includes(idx) && (
                  <div style={{ position: 'absolute', top: 5, right: 6, fontSize: 10, color: '#00ff88' }}>✓</div>
                )}
              </div>
              {idx < inferenceSteps.length - 1 && (
                <div style={{ padding: '0 5px', color: completedSteps.includes(idx) ? step.color : 'var(--text-dim)', fontSize: 14, flexShrink: 0 }}>→</div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Active Step Detail */}
      {(activeStep >= 0 && activeStep < inferenceSteps.length) && (
        <div className="card-cyber" style={{ padding: '14px 18px', borderColor: inferenceSteps[activeStep].color, boxShadow: `0 0 20px ${inferenceSteps[activeStep].color}33` }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: inferenceSteps[activeStep].color, letterSpacing: 2, textTransform: 'uppercase', marginBottom: 10 }}>
            ⚡ 실행 중: STEP {inferenceSteps[activeStep].id} — {inferenceSteps[activeStep].title}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
            <div>
              <div style={{ fontSize: 9, color: 'var(--text-dim)', marginBottom: 4, letterSpacing: 1 }}>INPUT</div>
              <pre style={{ fontSize: 10, color: 'var(--cyan)', fontFamily: 'Share Tech Mono, monospace', background: 'var(--bg-panel)', padding: 8, borderRadius: 4, margin: 0, lineHeight: 1.6 }}>
                {inferenceSteps[activeStep].input}
              </pre>
            </div>
            <div>
              <div style={{ fontSize: 9, color: 'var(--text-dim)', marginBottom: 4, letterSpacing: 1 }}>SPARQL 쿼리</div>
              <pre style={{ fontSize: 9, color: 'var(--purple)', fontFamily: 'Share Tech Mono, monospace', background: 'var(--bg-panel)', padding: 8, borderRadius: 4, margin: 0, lineHeight: 1.6, wordBreak: 'break-all', whiteSpace: 'pre-wrap' }}>
                {inferenceSteps[activeStep].sparql}
              </pre>
            </div>
            <div>
              <div style={{ fontSize: 9, color: 'var(--text-dim)', marginBottom: 4, letterSpacing: 1 }}>OUTPUT</div>
              <pre style={{ fontSize: 10, color: inferenceSteps[activeStep].color, fontFamily: 'Share Tech Mono, monospace', background: 'var(--bg-panel)', padding: 8, borderRadius: 4, margin: 0, lineHeight: 1.6 }}>
                {inferenceSteps[activeStep].output}
              </pre>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Multi-Signal Chart */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 8 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00b4d8', display: 'inline-block', marginRight: 6 }} />
            SOX + MU 지수 추이 (최근 30일)
          </div>
          <div style={{ display: 'flex', gap: 12, marginBottom: 8 }}>
            {[['SOX', '#00d4ff'], ['MU×50', '#00b4d8']].map(([l, c]) => (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <div style={{ width: 16, height: 2, background: c }} />
                <span style={{ fontSize: 9, color: 'var(--text-dim)' }}>{l}</span>
              </div>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={multiData}>
              <XAxis dataKey="date" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} interval={5} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} domain={['auto', 'auto']} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={multiData[0]?.sox} stroke="rgba(0,212,255,0.15)" strokeDasharray="4,4" />
              <Line type="monotone" dataKey="sox" stroke="#00d4ff" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey={(d: any) => d.mu * 50} stroke="#00b4d8" strokeWidth={1.5} dot={false} strokeDasharray="4,2" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* 5-ETF Decision Tree */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 8 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold)', display: 'inline-block', marginRight: 6 }} />
            5종목 ETF 의사결정 트리
          </div>
          <div style={{ position: 'relative', height: 200 }}>
            <svg width="100%" height="100%" viewBox="0 0 100 90" preserveAspectRatio="none">
              {/* Connections */}
              <line x1="50" y1="12" x2="20" y2="22" stroke="#00d4ff" strokeWidth="0.5" strokeOpacity="0.5" />
              <line x1="50" y1="12" x2="50" y2="22" stroke="#00b4d8" strokeWidth="0.5" strokeOpacity="0.5" />
              <line x1="50" y1="12" x2="80" y2="22" stroke="#ff4757" strokeWidth="0.5" strokeOpacity="0.5" />
              <line x1="20" y1="29" x2="10" y2="42" stroke="#ffd166" strokeWidth="0.5" strokeOpacity="0.6" />
              <line x1="20" y1="29" x2="30" y2="42" stroke="#00d4ff" strokeWidth="0.5" strokeOpacity="0.5" />
              <line x1="50" y1="29" x2="50" y2="42" stroke="#a8dadc" strokeWidth="0.5" strokeOpacity="0.6" />
              <line x1="80" y1="29" x2="65" y2="42" stroke="#ff4757" strokeWidth="0.5" strokeOpacity="0.5" />
              <line x1="80" y1="29" x2="85" y2="42" stroke="#ff4757" strokeWidth="0.5" strokeOpacity="0.6" />
              <line x1="50" y1="49" x2="50" y2="79" stroke="#a8e6cf" strokeWidth="0.5" strokeOpacity="0.4" />

              {/* Nodes */}
              {[
                { x: 50, y: 8, label: 'SOX/MU/SNDK', color: '#00d4ff', w: 22 },
                { x: 20, y: 26, label: 'SOX>0%', color: '#00ff88', w: 14 },
                { x: 50, y: 26, label: 'MU+SNDK>2%', color: '#00b4d8', w: 18 },
                { x: 80, y: 26, label: 'SOX<0%', color: '#ff4757', w: 14 },
                { x: 10, y: 46, label: 'KODEX증권↑', color: '#ffd166', w: 16 },
                { x: 30, y: 46, label: 'KODEX200↑', color: '#00d4ff', w: 16 },
                { x: 50, y: 46, label: 'KODEX반도체↑', color: '#a8dadc', w: 18 },
                { x: 65, y: 46, label: 'KODEX인버스↑', color: '#ff4757', w: 18 },
                { x: 85, y: 46, label: '전량인버스↑', color: '#ff4757', w: 16 },
                { x: 50, y: 82, label: 'KODEX2차전지↑', color: '#a8e6cf', w: 20 },
              ].map((n, i) => (
                <g key={i}>
                  <rect x={n.x - n.w / 2} y={n.y - 4.5} width={n.w} height={9} rx={2} fill={n.color + '22'} stroke={n.color} strokeWidth={0.5} />
                  <text x={n.x} y={n.y + 1} textAnchor="middle" dominantBaseline="middle" fill={n.color} fontSize={2.8} fontFamily="Noto Sans KR, sans-serif">{n.label}</text>
                </g>
              ))}
            </svg>
          </div>
        </div>
      </div>

      {/* KOSPI 강보합 조건 설명 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        {[
          {
            title: '🇰🇷 KOSPI 강보합 조건',
            color: '#ffd166',
            items: [
              'KOSPI200 > +0.5% → 강보합',
              'KODEX증권(102970) 매수',
              '증권업 베타 1.35 → 초과수익',
              '시장 강세 시 증권사 수익 증가',
            ],
          },
          {
            title: '🇺🇸 미국장 폭락 조건',
            color: '#ff4757',
            items: [
              'SOX < -2% → 폭락 판정',
              'KODEX인버스(114800) 전량',
              'MU < -3% 추가 확인',
              'VIX > 30 → 포지션 50% 축소',
            ],
          },
          {
            title: '💡 MU+SNDK 우위성',
            color: '#00b4d8',
            items: [
              'MU↔삼전 상관계수 0.82',
              'SOX↔KOSPI 상관계수 0.74',
              '시간차 공격 전략 활용',
              '미국 장 마감 → 한국 장 선행',
            ],
          },
        ].map((card) => (
          <div key={card.title} style={{ background: `${card.color}08`, border: `1px solid ${card.color}30`, borderRadius: 8, padding: '12px 14px' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: card.color, marginBottom: 8 }}>{card.title}</div>
            {card.items.map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 6, marginBottom: 4 }}>
                <span style={{ color: card.color, fontSize: 9, marginTop: 1, flexShrink: 0 }}>▸</span>
                <span style={{ fontSize: 10, color: 'var(--text-secondary)', lineHeight: 1.4 }}>{item}</span>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Signal Log Table (5종목 확장) */}
      <div className="card-cyber" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)', display: 'inline-block', marginRight: 6 }} />
          실시간 신호 로그 — 최근 10거래일 (5종목 확장)
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table-cyber" style={{ width: '100%' }}>
            <thead>
              <tr>
                <th>날짜</th>
                <th style={{ color: 'var(--cyan)' }}>SOX</th>
                <th style={{ color: '#00b4d8' }}>MU</th>
                <th style={{ color: '#48cae4' }}>SNDK</th>
                <th style={{ color: '#ffd166' }}>KOSPI</th>
                <th>신호</th>
                <th>액션</th>
                <th>포지션</th>
                <th style={{ color: 'var(--gold)' }}>수익</th>
              </tr>
            </thead>
            <tbody>
              {signalLogData.map((row, i) => (
                <tr key={i}>
                  <td className="font-mono-data">{row.date}</td>
                  <td className={`font-mono-data ${row.sox.startsWith('+') ? 'td-buy' : 'td-sell'}`}>{row.sox}</td>
                  <td className={`font-mono-data ${row.mu.startsWith('+') ? 'td-buy' : 'td-sell'}`}>{row.mu}</td>
                  <td className={`font-mono-data ${row.sndk.startsWith('+') ? 'td-buy' : 'td-sell'}`}>{row.sndk}</td>
                  <td className={`font-mono-data ${row.kospi.startsWith('+') ? 'td-buy' : 'td-sell'}`}>{row.kospi}</td>
                  <td style={{ color: row.signal.includes('매수') || row.signal.includes('강') ? 'var(--green)' : row.signal === '매도' || row.signal === '폭락대응' ? 'var(--red)' : '#ffd166' }}>{row.signal}</td>
                  <td style={{ color: 'var(--text-secondary)', fontSize: 10 }}>{row.action}</td>
                  <td style={{ color: row.pos.includes('INV') ? 'var(--red)' : row.pos.includes('SEC') ? '#ffd166' : row.pos.includes('SEMI') ? '#a8dadc' : 'var(--green)', fontSize: 10 }}>{row.pos}</td>
                  <td className={`font-mono-data ${row.ret.startsWith('+') ? 'td-buy' : 'td-sell'}`}>{row.ret}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
