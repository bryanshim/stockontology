// ─── KnowledgeGraph.tsx ───
// D3.js 포스 다이렉티드 그래프 + 미니맵 + 추론 시각화
// Design: Cyberpunk Terminal — neon nodes with glow effects, neural synapse animations

import { useEffect, useRef, useState, useCallback } from 'react';
import * as d3 from 'd3';
import { kgNodes, kgLinks, swrlRules, type KGNode, type KGLink } from '@/lib/ontologyData';

const LAYER_COLORS: Record<string, string> = {
  data: '#00d4ff',
  signal: '#f0b429',
  strategy: '#a855f7',
  performance: '#00ff88',
  consulting: '#00c8a0',
  risk: '#ff4757',
  market: '#0088bb',
};

const LAYER_LABELS: Record<string, string> = {
  data: '데이터 레이어',
  signal: '신호 레이어',
  strategy: '전략 레이어',
  performance: '성과 레이어',
  consulting: '컨설팅 레이어',
  risk: '리스크 레이어',
  market: '시장 레이어',
};

export default function KnowledgeGraph() {
  const svgRef = useRef<SVGSVGElement>(null);
  const minimapRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const simulationRef = useRef<d3.Simulation<KGNode, KGLink> | null>(null);
  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const [selectedNode, setSelectedNode] = useState<KGNode | null>(null);
  const [activeLayer, setActiveLayer] = useState<string | null>(null);
  const [inferenceStep, setInferenceStep] = useState<number>(-1);
  const [isRunningInference, setIsRunningInference] = useState(false);
  const [stats, setStats] = useState({ nodes: kgNodes.length, links: kgLinks.length, triples: 1247, classes: 42 });
  // v2: MU+SNDK+5종목 KODEX 포함

  const runInference = useCallback(() => {
    if (isRunningInference) return;
    setIsRunningInference(true);
    setInferenceStep(0);
    let step = 0;
    const interval = setInterval(() => {
      step++;
      setInferenceStep(step);
      if (step >= swrlRules.length) {
        clearInterval(interval);
        setIsRunningInference(false);
        setInferenceStep(-1);
      }
    }, 800);
  }, [isRunningInference]);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const container = containerRef.current;
    const W = container.clientWidth;
    const H = container.clientHeight;

    const svg = d3.select(svgRef.current)
      .attr('width', W)
      .attr('height', H);

    svg.selectAll('*').remove();

    // ── Defs: glow filters + arrow markers ──
    const defs = svg.append('defs');

    // Glow filters per color
    const glowColors = [
      { id: 'glow-cyan', color: '#00d4ff' },
      { id: 'glow-gold', color: '#f0b429' },
      { id: 'glow-green', color: '#00ff88' },
      { id: 'glow-red', color: '#ff4757' },
      { id: 'glow-purple', color: '#a855f7' },
      { id: 'glow-teal', color: '#00c8a0' },
    ];

    glowColors.forEach(({ id, color }) => {
      const filter = defs.append('filter').attr('id', id).attr('x', '-50%').attr('y', '-50%').attr('width', '200%').attr('height', '200%');
      filter.append('feGaussianBlur').attr('in', 'SourceGraphic').attr('stdDeviation', '3').attr('result', 'blur');
      const merge = filter.append('feMerge');
      merge.append('feMergeNode').attr('in', 'blur');
      merge.append('feMergeNode').attr('in', 'SourceGraphic');
    });

    // Arrow markers
    const arrowColors = ['#00d4ff', '#f0b429', '#00ff88', '#ff4757', '#a855f7', '#00c8a0', '#006688', '#0088bb'];
    arrowColors.forEach((color, i) => {
      defs.append('marker')
        .attr('id', `arrow-${i}`)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', 10)
        .attr('refY', 0)
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .attr('orient', 'auto')
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', color)
        .attr('opacity', 0.7);
    });

    const g = svg.append('g').attr('id', 'kg-main');

    // ── Zoom behavior ──
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.2, 4])
      .on('zoom', (e) => {
        g.attr('transform', e.transform.toString());
        updateMinimap(e.transform);
      });
    zoomRef.current = zoom;
    svg.call(zoom);

    // ── Links ──
    const linkGroup = g.append('g').attr('id', 'links');
    const link = linkGroup.selectAll<SVGLineElement, KGLink>('line')
      .data(kgLinks)
      .join('line')
      .attr('stroke', d => {
        const c = (d as KGLink).color || '#00d4ff';
        return c;
      })
      .attr('stroke-width', d => (d as KGLink).strength * 1.8)
      .attr('stroke-opacity', d => 0.3 + (d as KGLink).strength * 0.3)
      .attr('marker-end', d => {
        const c = (d as KGLink).color || '#00d4ff';
        const idx = arrowColors.indexOf(c);
        return `url(#arrow-${idx >= 0 ? idx : 0})`;
      });

    // Link labels
    const linkLabel = g.append('g').attr('id', 'link-labels')
      .selectAll<SVGTextElement, KGLink>('text')
      .data(kgLinks)
      .join('text')
      .attr('font-size', 8)
      .attr('fill', d => (d as KGLink).color || '#00d4ff')
      .attr('opacity', 0.5)
      .attr('text-anchor', 'middle')
      .attr('font-family', 'Share Tech Mono, monospace')
      .text(d => (d as KGLink).label);

    // ── Nodes ──
    const nodeGroup = g.append('g').attr('id', 'nodes');
    const node = nodeGroup.selectAll<SVGGElement, KGNode>('g')
      .data(kgNodes)
      .join('g')
      .attr('class', 'kg-node')
      .style('cursor', 'pointer')
      .call(
        d3.drag<SVGGElement, KGNode>()
          .on('start', (e, d) => {
            if (!e.active) simulationRef.current?.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
          })
          .on('drag', (e, d) => {
            d.fx = e.x;
            d.fy = e.y;
          })
          .on('end', (e, d) => {
            if (!e.active) simulationRef.current?.alphaTarget(0);
            d.fx = null;
            d.fy = null;
          })
      )
      .on('click', (_, d) => {
        setSelectedNode(d);
        // Zoom to node
        if (svgRef.current && zoomRef.current) {
          const transform = d3.zoomTransform(svgRef.current);
          const scale = Math.min(transform.k * 1.5, 3);
          d3.select(svgRef.current)
            .transition()
            .duration(600)
            .call(
              zoomRef.current.transform,
              d3.zoomIdentity
                .translate(W / 2, H / 2)
                .scale(scale)
                .translate(-(d.x || 0), -(d.y || 0))
            );
        }
      });

    // Outer glow ring
    node.append('circle')
      .attr('r', d => d.r + 6)
      .attr('fill', 'none')
      .attr('stroke', d => d.color)
      .attr('stroke-width', 1)
      .attr('stroke-opacity', 0.2)
      .attr('stroke-dasharray', '4,4');

    // Main circle
    node.append('circle')
      .attr('r', d => d.r)
      .attr('fill', d => d.color + '18')
      .attr('stroke', d => d.color)
      .attr('stroke-width', 1.5)
      .attr('filter', d => {
        const filterMap: Record<string, string> = {
          data: 'url(#glow-cyan)',
          signal: 'url(#glow-gold)',
          strategy: 'url(#glow-purple)',
          performance: 'url(#glow-green)',
          consulting: 'url(#glow-teal)',
          risk: 'url(#glow-red)',
          market: 'url(#glow-cyan)',
        };
        return filterMap[d.layer] || 'url(#glow-cyan)';
      });

    // Inner pulse circle
    node.append('circle')
      .attr('r', d => d.r * 0.4)
      .attr('fill', d => d.color + '33')
      .attr('stroke', d => d.color)
      .attr('stroke-width', 0.5)
      .attr('opacity', 0.6);

    // Labels
    node.each(function(d) {
      const el = d3.select(this);
      const parts = d.label.split('\n');
      const text = el.append('text')
        .attr('text-anchor', 'middle')
        .attr('dominant-baseline', 'middle')
        .attr('fill', d.color)
        .attr('font-size', Math.max(8, d.r * 0.35))
        .attr('font-family', 'Noto Sans KR, sans-serif')
        .attr('font-weight', '700')
        .attr('pointer-events', 'none');

      parts.forEach((p, i) => {
        text.append('tspan')
          .attr('x', 0)
          .attr('dy', i === 0 ? (parts.length > 1 ? '-0.55em' : '0') : '1.15em')
          .text(p);
      });
    });

    // ── Force Simulation ──
    const simulation = d3.forceSimulation<KGNode>(kgNodes)
      .force('link', d3.forceLink<KGNode, KGLink>(kgLinks)
        .id(d => d.id)
        .distance(d => 110 + (1 - (d as KGLink).strength) * 70)
        .strength(d => (d as KGLink).strength * 0.25)
      )
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(W / 2, H / 2))
      .force('collision', d3.forceCollide<KGNode>(d => d.r + 14))
      .on('tick', () => {
        link
          .attr('x1', d => (d.source as KGNode).x || 0)
          .attr('y1', d => (d.source as KGNode).y || 0)
          .attr('x2', d => {
            const src = d.source as KGNode;
            const tgt = d.target as KGNode;
            const dx = (tgt.x || 0) - (src.x || 0);
            const dy = (tgt.y || 0) - (src.y || 0);
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            return (tgt.x || 0) - (dx / dist) * tgt.r;
          })
          .attr('y2', d => {
            const src = d.source as KGNode;
            const tgt = d.target as KGNode;
            const dx = (tgt.x || 0) - (src.x || 0);
            const dy = (tgt.y || 0) - (src.y || 0);
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            return (tgt.y || 0) - (dy / dist) * tgt.r;
          });

        linkLabel
          .attr('x', d => ((d.source as KGNode).x! + (d.target as KGNode).x!) / 2)
          .attr('y', d => ((d.source as KGNode).y! + (d.target as KGNode).y!) / 2 - 4);

        node.attr('transform', d => `translate(${d.x || 0},${d.y || 0})`);
        updateMinimapNodes();
      });

    simulationRef.current = simulation;

    // ── Minimap ──
    function updateMinimap(_transform: d3.ZoomTransform) {
      // handled by minimap SVG
    }

    function updateMinimapNodes() {
      if (!minimapRef.current) return;
      const mm = d3.select(minimapRef.current);
      const mmW = 160, mmH = 100;
      const scaleX = mmW / W;
      const scaleY = mmH / H;

      mm.selectAll('circle.mm-node')
        .data(kgNodes)
        .join('circle')
        .attr('class', 'mm-node')
        .attr('cx', d => (d.x || 0) * scaleX)
        .attr('cy', d => (d.y || 0) * scaleY)
        .attr('r', d => Math.max(2, d.r * scaleX))
        .attr('fill', d => d.color + '88')
        .attr('stroke', d => d.color)
        .attr('stroke-width', 0.5);
    }

    return () => {
      simulation.stop();
    };
  }, []);

  // Layer filter effect
  useEffect(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.selectAll<SVGGElement, KGNode>('.kg-node')
      .attr('opacity', d => {
        if (!activeLayer) return 1;
        return d.layer === activeLayer ? 1 : 0.15;
      });
    svg.selectAll<SVGLineElement, KGLink>('line')
      .attr('opacity', d => {
        if (!activeLayer) return 1;
        const src = d.source as KGNode;
        const tgt = d.target as KGNode;
        return (src.layer === activeLayer || tgt.layer === activeLayer) ? 0.8 : 0.05;
      });
  }, [activeLayer]);

  const resetView = () => {
    if (!svgRef.current || !zoomRef.current) return;
    d3.select(svgRef.current)
      .transition()
      .duration(750)
      .call(zoomRef.current.transform, d3.zoomIdentity);
    setActiveLayer(null);
    setSelectedNode(null);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Stats Bar */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { label: 'OWL 클래스', value: stats.classes, color: '#00d4ff' },
          { label: '온톨로지 노드', value: stats.nodes, color: '#f0b429' },
          { label: '객체속성 링크', value: stats.links, color: '#a855f7' },
          { label: 'RDF 트리플', value: stats.triples.toLocaleString(), color: '#00ff88' },
        ].map(s => (
          <div key={s.label} className="stat-card-cyber">
            <div style={{ fontSize: 10, color: 'var(--text-secondary)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>{s.label}</div>
            <div className="font-mono-data" style={{ fontSize: 22, fontWeight: 700, color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Graph Container */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 260px', gap: 16 }}>
        <div>
          <div
            ref={containerRef}
            style={{ width: '100%', height: 560, background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, position: 'relative', overflow: 'hidden' }}
          >
            <svg ref={svgRef} style={{ width: '100%', height: '100%' }} />

            {/* Minimap */}
            <div className="minimap-container">
              <div style={{ fontSize: 8, color: 'var(--text-dim)', padding: '3px 6px', letterSpacing: 1, textTransform: 'uppercase' }}>MINIMAP</div>
              <svg ref={minimapRef} width={160} height={85} style={{ display: 'block' }} />
            </div>

            {/* Controls */}
            <div style={{ position: 'absolute', top: 14, left: 14, display: 'flex', gap: 8, zIndex: 10 }}>
              <button className="btn-cyber" onClick={resetView} style={{ fontSize: 10 }}>↺ 리셋</button>
              <button className="btn-cyber" onClick={runInference} disabled={isRunningInference} style={{ fontSize: 10, borderColor: isRunningInference ? 'var(--purple)' : undefined, color: isRunningInference ? 'var(--purple)' : undefined }}>
                {isRunningInference ? '⚡ 추론중...' : '⚡ 추론 실행'}
              </button>
            </div>

            {/* Legend */}
            <div style={{ position: 'absolute', bottom: 14, left: 14, display: 'flex', flexWrap: 'wrap', gap: 8, zIndex: 10 }}>
              {Object.entries(LAYER_LABELS).map(([layer, label]) => (
                <button
                  key={layer}
                  onClick={() => setActiveLayer(activeLayer === layer ? null : layer)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 4, fontSize: 9, color: activeLayer === layer ? LAYER_COLORS[layer] : 'var(--text-secondary)',
                    background: activeLayer === layer ? `${LAYER_COLORS[layer]}18` : 'transparent',
                    border: `1px solid ${activeLayer === layer ? LAYER_COLORS[layer] : 'transparent'}`,
                    borderRadius: 4, padding: '2px 6px', cursor: 'pointer', transition: 'all 0.2s',
                  }}
                >
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: LAYER_COLORS[layer], display: 'inline-block' }} />
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Properties Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Node Properties */}
          <div className="card-cyber" style={{ padding: '14px 16px', flex: 1 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--cyan)', display: 'inline-block' }} />
              OWL 속성 패널
            </div>
            {selectedNode ? (
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: selectedNode.color, marginBottom: 10 }}>
                  {selectedNode.label.replace('\n', ' ')}
                </div>
                <div style={{ fontSize: 10, color: 'var(--text-dim)', marginBottom: 8, fontFamily: 'Share Tech Mono, monospace' }}>
                  {selectedNode.type}
                </div>
                <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginBottom: 10, lineHeight: 1.6, borderBottom: '1px solid var(--border-color)', paddingBottom: 8 }}>
                  {selectedNode.desc}
                </div>
                {selectedNode.props?.map(([k, v]) => (
                  <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 10 }}>
                    <span style={{ color: 'var(--cyan)', fontFamily: 'Share Tech Mono, monospace' }}>{k}</span>
                    <span style={{ color: 'var(--text-secondary)', textAlign: 'right', maxWidth: '55%', wordBreak: 'break-all' }}>{v}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ color: 'var(--text-dim)', fontSize: 11, textAlign: 'center', paddingTop: 20 }}>
                노드를 클릭하면<br />OWL 속성이 표시됩니다
              </div>
            )}
          </div>

          {/* Layer Stats */}
          <div className="card-cyber" style={{ padding: '12px 14px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>레이어 통계</div>
            {Object.entries(LAYER_LABELS).map(([layer, label]) => {
              const count = kgNodes.filter(n => n.layer === layer).length;
              return (
                <div key={layer} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: LAYER_COLORS[layer], flexShrink: 0 }} />
                  <span style={{ fontSize: 10, color: 'var(--text-secondary)', flex: 1 }}>{label}</span>
                  <span style={{ fontSize: 10, color: LAYER_COLORS[layer], fontFamily: 'Share Tech Mono, monospace' }}>{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* SWRL Rules */}
      <div className="card-cyber" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--purple)', display: 'inline-block' }} />
          SWRL 추론 규칙 — {swrlRules.length}개 규칙 정의
          {isRunningInference && <span style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--cyan)', animation: 'pulse-dot 1s infinite' }}>⚡ 추론 실행 중...</span>}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
          {swrlRules.map((rule, idx) => (
            <div
              key={rule.id}
              className="rule-box"
              style={{
                borderColor: inferenceStep === idx + 1 ? rule.color : `${rule.color}44`,
                background: inferenceStep === idx + 1 ? `${rule.color}18` : `${rule.color}08`,
                boxShadow: inferenceStep === idx + 1 ? `0 0 16px ${rule.color}44` : 'none',
                transition: 'all 0.4s',
                color: rule.color,
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontWeight: 700, fontSize: 10 }}>[{rule.id}] {rule.name}</span>
                {inferenceStep === idx + 1 && <span style={{ fontSize: 9, color: '#00ff88' }}>✓ 실행중</span>}
              </div>
              <div style={{ fontSize: 9, opacity: 0.8, marginBottom: 4, wordBreak: 'break-all', lineHeight: 1.5 }}>{rule.rule}</div>
              <div style={{ fontSize: 9, color: 'var(--text-secondary)', lineHeight: 1.4 }}>{rule.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
