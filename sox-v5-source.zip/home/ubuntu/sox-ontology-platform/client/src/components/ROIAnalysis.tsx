// ─── ROIAnalysis.tsx ───
// ROI 분석 탭 — 전략별 ROI, 리스크-수익 산점도, 시나리오 분석
// Design: Cyberpunk Terminal — financial metrics with neon highlights

import {
  BarChart, Bar, ScatterChart, Scatter, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, Cell, ReferenceLine, Legend
} from 'recharts';
import { strategyCompareData } from '@/lib/ontologyData';

const roiBarData = [
  { name: '전략A', roi: 87.4, color: '#00d4ff' },
  { name: '전략B', roi: 112.3, color: '#f0b429' },
  { name: '전략C', roi: 134.7, color: '#00ff88' },
  { name: '전략D', roi: 118.9, color: '#a855f7' },
  { name: 'Buy&Hold', roi: 23.1, color: '#555' },
];

const scatterData = strategyCompareData.map(s => ({
  name: s.name.replace('\n', ' '),
  x: Math.abs(s.mdd),
  y: s.annualReturn,
  sharpe: s.sharpe,
  color: ['#00d4ff', '#f0b429', '#00ff88', '#a855f7'][strategyCompareData.indexOf(s)],
}));

const scenarios = [
  {
    name: '강세 시나리오',
    icon: '🐂',
    color: '#00ff88',
    desc: 'SOX 상승 추세 지속 시',
    return: '+20%~+25%',
    prob: '30%',
    details: ['반도체 슈퍼사이클 지속', 'AI 투자 확대', 'KODEX200 집중 포지션'],
  },
  {
    name: '기본 시나리오',
    icon: '↔',
    color: '#f0b429',
    desc: '혼조장세 지속 시',
    return: '+12%~+16%',
    prob: '50%',
    details: ['SOX 등락 반복', '인버스/정방향 스위칭', '전략C 기본 운용'],
  },
  {
    name: '약세 시나리오',
    icon: '🐻',
    color: '#ff4757',
    desc: '하락장 + 인버스 미작동 시',
    return: '-5%~+3%',
    prob: '20%',
    details: ['글로벌 경기 침체', 'VIX 30 초과 지속', '현금 비중 50% 전환'],
  },
];

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const d = payload[0].payload;
    return (
      <div style={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, padding: '8px 12px', fontSize: 11 }}>
        <div style={{ color: d.color, fontWeight: 700, marginBottom: 4 }}>{d.name}</div>
        <div style={{ color: 'var(--red)' }}>MDD: -{d.x}%</div>
        <div style={{ color: 'var(--green)' }}>연환산: +{d.y}%</div>
        <div style={{ color: 'var(--gold)' }}>샤프: {d.sharpe}</div>
      </div>
    );
  }
  return null;
};

export default function ROIAnalysis() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Summary Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { label: '최고 총수익률', value: '+134.7%', sub: '전략C (MA결합)', color: '#00ff88' },
          { label: '최고 샤프지수', value: '2.14', sub: '전략D (리스크관리)', color: '#f0b429' },
          { label: '최저 MDD', value: '-9.8%', sub: '전략D', color: '#ff4757' },
          { label: '기대 연수익', value: '+12~16%', sub: '기본 시나리오', color: '#00d4ff' },
        ].map(s => (
          <div key={s.label} className="stat-card-cyber">
            <div style={{ fontSize: 9, color: 'var(--text-secondary)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>{s.label}</div>
            <div className="font-mono-data" style={{ fontSize: 22, fontWeight: 700, color: s.color, margin: '4px 0 2px' }}>{s.value}</div>
            <div style={{ fontSize: 9, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* ROI Bar Chart */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>전략별 총수익률 ROI</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={roiBarData} layout="vertical">
              <CartesianGrid stroke="rgba(0,212,255,0.04)" horizontal={false} />
              <XAxis type="number" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} unit="%" />
              <YAxis type="category" dataKey="name" tick={{ fill: '#7ba3c4', fontSize: 10 }} tickLine={false} width={60} />
              <Tooltip
                contentStyle={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, fontSize: 11 }}
                formatter={(v: any) => [`+${v}%`, '총수익률']}
                labelStyle={{ color: 'var(--text-secondary)' }}
              />
              <ReferenceLine x={23.1} stroke="rgba(255,159,67,0.5)" strokeDasharray="4,4" label={{ value: 'KOSPI', fill: '#ff9f43', fontSize: 9 }} />
              <Bar dataKey="roi" radius={[0, 4, 4, 0]}>
                {roiBarData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} fillOpacity={0.8} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Risk-Return Scatter */}
        <div className="card-cyber card-cyber-gold" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>리스크-수익 산점도</div>
          <ResponsiveContainer width="100%" height={220}>
            <ScatterChart>
              <CartesianGrid stroke="rgba(0,212,255,0.04)" />
              <XAxis type="number" dataKey="x" name="MDD" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} label={{ value: 'MDD (%)', fill: '#3d6480', fontSize: 9, position: 'insideBottom', offset: -2 }} />
              <YAxis type="number" dataKey="y" name="연환산수익" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} label={{ value: '연환산(%)', fill: '#3d6480', fontSize: 9, angle: -90, position: 'insideLeft' }} />
              <Tooltip content={<CustomTooltip />} />
              <Scatter data={scatterData} shape={(props: any) => {
                const { cx, cy, payload } = props;
                return (
                  <g>
                    <circle cx={cx} cy={cy} r={10} fill={payload.color + '44'} stroke={payload.color} strokeWidth={1.5} />
                    <text x={cx} y={cy + 1} textAnchor="middle" dominantBaseline="middle" fill={payload.color} fontSize={8} fontFamily="Noto Sans KR">
                      {payload.name.split(' ')[0]}
                    </text>
                  </g>
                );
              }} />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Scenarios */}
      <div className="card-cyber" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--cyan)', display: 'inline-block', marginRight: 6 }} />
          투자 시나리오 분석 (1억원 기준)
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
          {scenarios.map(s => (
            <div key={s.name} style={{ background: `${s.color}08`, border: `1px solid ${s.color}33`, borderRadius: 8, padding: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                <span style={{ fontSize: 20 }}>{s.icon}</span>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: s.color }}>{s.name}</div>
                  <div style={{ fontSize: 10, color: 'var(--text-dim)' }}>{s.desc}</div>
                </div>
                <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
                  <div style={{ fontSize: 9, color: 'var(--text-dim)' }}>발생확률</div>
                  <div className="font-mono-data" style={{ fontSize: 14, color: s.color }}>{s.prob}</div>
                </div>
              </div>
              <div style={{ marginBottom: 10, padding: '8px 12px', background: 'var(--bg-panel)', borderRadius: 6 }}>
                <div style={{ fontSize: 9, color: 'var(--text-dim)', marginBottom: 2 }}>기대 연수익</div>
                <div className="font-mono-data" style={{ fontSize: 18, fontWeight: 700, color: s.color }}>{s.return}</div>
              </div>
              {s.details.map((d, i) => (
                <div key={i} style={{ display: 'flex', gap: 5, marginBottom: 3, fontSize: 10, color: 'var(--text-secondary)' }}>
                  <span style={{ color: s.color }}>▸</span> {d}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Strategy Comparison Table */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>전략별 상세 성과 비교</div>
          <table className="table-cyber">
            <thead>
              <tr>
                <th>지표</th>
                <th style={{ color: '#00d4ff' }}>전략A</th>
                <th style={{ color: '#f0b429' }}>전략B</th>
                <th style={{ color: '#00ff88' }}>전략C ★</th>
                <th style={{ color: '#a855f7' }}>전략D</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>총수익률</td><td className="td-buy font-mono-data">+87.4%</td><td className="td-buy font-mono-data">+112.3%</td><td className="td-buy font-mono-data">+134.7%</td><td className="td-buy font-mono-data">+118.9%</td></tr>
              <tr><td>연환산</td><td className="td-buy font-mono-data">+11.8%</td><td className="td-buy font-mono-data">+14.2%</td><td className="td-buy font-mono-data">+16.1%</td><td className="td-buy font-mono-data">+14.9%</td></tr>
              <tr><td>MDD</td><td className="td-sell font-mono-data">-18.3%</td><td className="td-sell font-mono-data">-15.1%</td><td className="td-sell font-mono-data">-14.2%</td><td className="td-sell font-mono-data">-9.8%</td></tr>
              <tr><td>샤프지수</td><td className="td-gold font-mono-data">1.47</td><td className="td-gold font-mono-data">1.73</td><td className="td-gold font-mono-data">1.98</td><td className="td-gold font-mono-data">2.14</td></tr>
              <tr><td>승률</td><td>58.2%</td><td>61.4%</td><td>63.7%</td><td>62.1%</td></tr>
              <tr><td>총 거래수</td><td>1,243</td><td>876</td><td>934</td><td>812</td></tr>
            </tbody>
          </table>
        </div>

        {/* Solution ROI */}
        <div className="card-cyber card-cyber-green" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>솔루션 도입 ROI 추정</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { label: '시스템 구축 비용 (3개월)', value: '약 500만원', color: 'var(--red)', icon: '💸' },
              { label: '초과수익 기대 (1억 투자 기준)', value: '연 +800~1,600만원', color: 'var(--green)', icon: '💰' },
              { label: '투자 회수 기간', value: '3~6개월', color: 'var(--cyan)', icon: '⏱️' },
              { label: '3년 누적 기대 ROI', value: '+4,300~9,300만원', color: 'var(--gold)', icon: '📈' },
            ].map(item => (
              <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: 'var(--bg-panel)', borderRadius: 6, border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 16 }}>{item.icon}</span>
                  <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{item.label}</span>
                </div>
                <span className="font-mono-data" style={{ fontSize: 15, fontWeight: 700, color: item.color }}>{item.value}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12, padding: '10px 12px', background: 'rgba(0,255,136,0.08)', border: '1px solid rgba(0,255,136,0.3)', borderRadius: 6 }}>
            <div style={{ fontSize: 10, color: 'var(--green)', fontWeight: 700, marginBottom: 4 }}>✓ ROI 결론</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              1억원 투자 기준 연 초과수익 800~1,600만원 대비 구축비용 500만원으로 <span style={{ color: 'var(--gold)' }}>3~6개월 내 투자 회수</span> 가능. 
              3년 누적 기준 <span style={{ color: 'var(--green)' }}>ROI 860~1,860%</span> 예상.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
