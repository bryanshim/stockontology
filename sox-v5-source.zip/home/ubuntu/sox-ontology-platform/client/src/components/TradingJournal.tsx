// ─── TradingJournal.tsx ───
// 일일 전략 저널 — 매매 기록 CRUD + 수익률 차트 + 캘린더 뷰 + 전략별 통계
// Design: Cyberpunk Terminal — dark navy + cyan/gold accent
// Data: localStorage 영속 저장

import { useState, useEffect, useCallback } from 'react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine, Cell,
} from 'recharts';

// ── 타입 정의 ──
type ETFCode = 'KODEX반도체' | 'KODEX인버스' | 'KODEX증권' | 'KODEX2차전지' | 'KODEX200' | 'HOLD';
type Scenario = '①반도체급등' | '②미국장폭락' | '③국내강보합' | '④EV모멘텀' | '⑤소폭상승' | '⑥반도체약세' | '⑦혼조' | '⑧VIX급등' | '수동';

export interface TradeRecord {
  id: string;
  date: string;          // YYYY-MM-DD
  scenario: Scenario;
  etf: ETFCode;
  muChange: number;      // MU 등락률 %
  wdcChange: number;     // WDC 등락률 %
  soxChange: number;     // SOX 등락률 %
  kospiChange: number;   // KOSPI 등락률 %
  vix: number;
  buyPrice: number;      // 매수가
  sellPrice: number;     // 매도가 (0이면 미청산)
  quantity: number;      // 수량
  pnl: number;           // 손익 (원)
  pnlRate: number;       // 수익률 %
  memo: string;
  isOpen: boolean;       // 미청산 여부
}

const ETF_OPTIONS: ETFCode[] = ['KODEX반도체', 'KODEX인버스', 'KODEX증권', 'KODEX2차전지', 'KODEX200', 'HOLD'];
const SCENARIO_OPTIONS: Scenario[] = ['①반도체급등', '②미국장폭락', '③국내강보합', '④EV모멘텀', '⑤소폭상승', '⑥반도체약세', '⑦혼조', '⑧VIX급등', '수동'];

const ETF_COLORS: Record<ETFCode, string> = {
  'KODEX반도체': '#00d4ff',
  'KODEX인버스': '#ff4757',
  'KODEX증권': '#ffd166',
  'KODEX2차전지': '#a8e6cf',
  'KODEX200': '#00b4d8',
  'HOLD': '#6b7280',
};

// ── 샘플 초기 데이터 ──
const SAMPLE_RECORDS: TradeRecord[] = [
  { id: '1', date: '2026-04-28', scenario: '①반도체급등', etf: 'KODEX반도체', muChange: 3.21, wdcChange: 2.14, soxChange: 1.87, kospiChange: 0.74, vix: 17.2, buyPrice: 41200, sellPrice: 42050, quantity: 100, pnl: 85000, pnlRate: 2.06, memo: 'MU+WDC 동반 +3%↑ 강세 신호 → 반도체 급등 시나리오 적중', isOpen: false },
  { id: '2', date: '2026-04-29', scenario: '③국내강보합', etf: 'KODEX증권', muChange: 0.32, wdcChange: -0.18, soxChange: 0.21, kospiChange: 0.64, vix: 18.4, buyPrice: 8120, sellPrice: 8245, quantity: 200, pnl: 25000, pnlRate: 1.54, memo: 'KOSPI +0.64% 강보합, 거래대금 증가 확인 후 매수', isOpen: false },
  { id: '3', date: '2026-04-30', scenario: '②미국장폭락', etf: 'KODEX인버스', muChange: -2.87, wdcChange: -3.12, soxChange: -2.94, kospiChange: -1.24, vix: 28.7, buyPrice: 4080, sellPrice: 4210, quantity: 300, pnl: 39000, pnlRate: 3.19, memo: 'MU -2.87% 패닉셀 → 인버스 즉시 매수. VIX 28.7 확인', isOpen: false },
  { id: '4', date: '2026-05-02', scenario: '⑤소폭상승', etf: 'KODEX200', muChange: 0.54, wdcChange: 0.41, soxChange: 0.38, kospiChange: 0.31, vix: 19.1, buyPrice: 36650, sellPrice: 36820, quantity: 50, pnl: 8500, pnlRate: 0.46, memo: '방향 불확실, 소폭 상승 → KODEX200 안전 선택', isOpen: false },
  { id: '5', date: '2026-05-06', scenario: '④EV모멘텀', etf: 'KODEX2차전지', muChange: 0.12, wdcChange: -0.08, soxChange: 0.14, kospiChange: 0.42, vix: 16.8, buyPrice: 14520, sellPrice: 0, quantity: 100, pnl: 0, pnlRate: 0, memo: '정부 EV 보조금 정책 발표 → 2차전지 독립 모멘텀. 미청산', isOpen: true },
  { id: '6', date: '2026-05-07', scenario: '①반도체급등', etf: 'KODEX반도체', muChange: 4.12, wdcChange: 3.87, soxChange: 3.21, kospiChange: 1.08, vix: 16.2, buyPrice: 42050, sellPrice: 0, quantity: 80, pnl: 0, pnlRate: 0, memo: 'MU +4.12% 강세 → 반도체 급등 시나리오. 오늘 매수 미청산', isOpen: true },
];

const STORAGE_KEY = 'sox-trading-journal-v1';

function loadRecords(): TradeRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return SAMPLE_RECORDS;
}

function saveRecords(records: TradeRecord[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch {}
}

// ── 커스텀 툴팁 ──
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const val = payload[0]?.value ?? 0;
  return (
    <div style={{ background: '#071d35', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 6, padding: '8px 12px', fontSize: 11 }}>
      <div style={{ color: '#7ba3c4', marginBottom: 4 }}>{label}</div>
      <div style={{ color: val >= 0 ? '#00ff88' : '#ff4757', fontWeight: 700, fontFamily: 'Share Tech Mono, monospace' }}>
        {val >= 0 ? '+' : ''}{typeof val === 'number' ? val.toFixed(2) : val}%
      </div>
    </div>
  );
}

// ── 빈 폼 기본값 ──
function emptyForm(): Omit<TradeRecord, 'id'> {
  const today = new Date().toISOString().slice(0, 10);
  return {
    date: today, scenario: '①반도체급등', etf: 'KODEX반도체',
    muChange: 0, wdcChange: 0, soxChange: 0, kospiChange: 0, vix: 18,
    buyPrice: 0, sellPrice: 0, quantity: 0,
    pnl: 0, pnlRate: 0, memo: '', isOpen: true,
  };
}

export default function TradingJournal() {
  const [records, setRecords] = useState<TradeRecord[]>(loadRecords);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<TradeRecord, 'id'>>(emptyForm());
  const [viewMode, setViewMode] = useState<'list' | 'calendar' | 'stats'>('list');
  const [filterEtf, setFilterEtf] = useState<ETFCode | 'ALL'>('ALL');
  const [calendarMonth, setCalendarMonth] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  });
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // 저장
  useEffect(() => { saveRecords(records); }, [records]);

  // 손익 자동 계산
  const calcPnl = useCallback((f: Omit<TradeRecord, 'id'>) => {
    if (f.sellPrice > 0 && f.buyPrice > 0 && f.quantity > 0) {
      const pnl = (f.sellPrice - f.buyPrice) * f.quantity;
      const pnlRate = ((f.sellPrice - f.buyPrice) / f.buyPrice) * 100;
      return { pnl, pnlRate, isOpen: false };
    }
    return { pnl: 0, pnlRate: 0, isOpen: true };
  }, []);

  const handleFormChange = (key: keyof Omit<TradeRecord, 'id'>, value: any) => {
    setForm(prev => {
      const updated = { ...prev, [key]: value };
      const { pnl, pnlRate, isOpen } = calcPnl(updated);
      return { ...updated, pnl, pnlRate, isOpen };
    });
  };

  const handleSubmit = () => {
    if (!form.date || !form.etf || form.buyPrice <= 0) return;
    if (editId) {
      setRecords(prev => prev.map(r => r.id === editId ? { ...form, id: editId } : r));
      setEditId(null);
    } else {
      const newRecord: TradeRecord = { ...form, id: Date.now().toString() };
      setRecords(prev => [newRecord, ...prev].sort((a, b) => b.date.localeCompare(a.date)));
    }
    setForm(emptyForm());
    setShowForm(false);
  };

  const handleEdit = (r: TradeRecord) => {
    setForm({ ...r });
    setEditId(r.id);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
    setDeleteConfirm(null);
  };

  // ── 통계 계산 ──
  const closedRecords = records.filter(r => !r.isOpen);
  const totalPnl = closedRecords.reduce((s, r) => s + r.pnl, 0);
  const avgPnlRate = closedRecords.length > 0 ? closedRecords.reduce((s, r) => s + r.pnlRate, 0) / closedRecords.length : 0;
  const winCount = closedRecords.filter(r => r.pnlRate > 0).length;
  const winRate = closedRecords.length > 0 ? (winCount / closedRecords.length) * 100 : 0;
  const maxWin = closedRecords.length > 0 ? Math.max(...closedRecords.map(r => r.pnlRate)) : 0;
  const maxLoss = closedRecords.length > 0 ? Math.min(...closedRecords.map(r => r.pnlRate)) : 0;

  // 누적 수익률 차트 데이터
  const cumulativeData = (() => {
    const sorted = [...closedRecords].sort((a, b) => a.date.localeCompare(b.date));
    let cum = 0;
    return sorted.map(r => {
      cum += r.pnlRate;
      return { date: r.date.slice(5), cumRate: parseFloat(cum.toFixed(2)), dayRate: r.pnlRate, etf: r.etf };
    });
  })();

  // ETF별 성과 집계
  const etfStats = ETF_OPTIONS.filter(e => e !== 'HOLD').map(etf => {
    const recs = closedRecords.filter(r => r.etf === etf);
    const avg = recs.length > 0 ? recs.reduce((s, r) => s + r.pnlRate, 0) / recs.length : 0;
    const wins = recs.filter(r => r.pnlRate > 0).length;
    return { etf, count: recs.length, avgRate: parseFloat(avg.toFixed(2)), winRate: recs.length > 0 ? Math.round((wins / recs.length) * 100) : 0 };
  }).filter(e => e.count > 0);

  // 필터된 레코드
  const filteredRecords = filterEtf === 'ALL' ? records : records.filter(r => r.etf === filterEtf);

  // ── 캘린더 뷰 ──
  const CalendarView = () => {
    const { year, month } = calendarMonth;
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const monthName = new Date(year, month).toLocaleDateString('ko-KR', { year: 'numeric', month: 'long' });
    const recordsByDate: Record<string, TradeRecord[]> = {};
    records.forEach(r => {
      const d = r.date;
      if (!recordsByDate[d]) recordsByDate[d] = [];
      recordsByDate[d].push(r);
    });
    const cells: (number | null)[] = [...Array(firstDay).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
    while (cells.length % 7 !== 0) cells.push(null);

    return (
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <button onClick={() => setCalendarMonth(p => { const d = new Date(p.year, p.month - 1); return { year: d.getFullYear(), month: d.getMonth() }; })} style={{ background: 'rgba(0,212,255,0.1)', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 4, color: '#00d4ff', padding: '4px 12px', cursor: 'pointer', fontSize: 14 }}>‹</button>
          <span style={{ fontWeight: 700, color: 'var(--text-primary)', fontSize: 13 }}>{monthName}</span>
          <button onClick={() => setCalendarMonth(p => { const d = new Date(p.year, p.month + 1); return { year: d.getFullYear(), month: d.getMonth() }; })} style={{ background: 'rgba(0,212,255,0.1)', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 4, color: '#00d4ff', padding: '4px 12px', cursor: 'pointer', fontSize: 14 }}>›</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
          {['일', '월', '화', '수', '목', '금', '토'].map(d => (
            <div key={d} style={{ textAlign: 'center', fontSize: 10, color: 'var(--text-dim)', padding: '4px 0', fontWeight: 700 }}>{d}</div>
          ))}
          {cells.map((day, i) => {
            if (!day) return <div key={i} />;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const dayRecords = recordsByDate[dateStr] || [];
            const dayPnl = dayRecords.filter(r => !r.isOpen).reduce((s, r) => s + r.pnlRate, 0);
            const hasTrade = dayRecords.length > 0;
            const isToday = dateStr === new Date().toISOString().slice(0, 10);
            return (
              <div key={i} style={{
                minHeight: 60,
                background: hasTrade ? (dayPnl > 0 ? 'rgba(0,255,136,0.06)' : dayPnl < 0 ? 'rgba(255,71,87,0.06)' : 'rgba(0,212,255,0.04)') : 'rgba(255,255,255,0.02)',
                border: `1px solid ${isToday ? '#00d4ff' : hasTrade ? (dayPnl > 0 ? 'rgba(0,255,136,0.3)' : 'rgba(255,71,87,0.3)') : 'rgba(255,255,255,0.05)'}`,
                borderRadius: 6,
                padding: '4px 6px',
                cursor: hasTrade ? 'pointer' : 'default',
              }}>
                <div style={{ fontSize: 10, color: isToday ? '#00d4ff' : 'var(--text-secondary)', fontWeight: isToday ? 700 : 400, marginBottom: 3 }}>{day}</div>
                {dayRecords.map((r, ri) => (
                  <div key={ri} style={{ fontSize: 8, padding: '1px 4px', borderRadius: 2, background: `${ETF_COLORS[r.etf]}22`, color: ETF_COLORS[r.etf], marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {r.etf.replace('KODEX', '')} {r.isOpen ? '🔓' : r.pnlRate >= 0 ? `+${r.pnlRate.toFixed(1)}%` : `${r.pnlRate.toFixed(1)}%`}
                  </div>
                ))}
                {hasTrade && !dayRecords.every(r => r.isOpen) && (
                  <div style={{ fontSize: 8, color: dayPnl >= 0 ? '#00ff88' : '#ff4757', fontFamily: 'Share Tech Mono, monospace', fontWeight: 700 }}>
                    {dayPnl >= 0 ? '+' : ''}{dayPnl.toFixed(2)}%
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // ── 입력 폼 ──
  const FormPanel = () => (
    <div style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.05), rgba(168,85,247,0.03))', border: '1px solid rgba(0,212,255,0.25)', borderRadius: 10, padding: '18px 20px', marginBottom: 16 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: '#00d4ff', marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span>{editId ? '✏️ 매매 기록 수정' : '➕ 새 매매 기록 입력'}</span>
        <button onClick={() => { setShowForm(false); setEditId(null); setForm(emptyForm()); }} style={{ background: 'rgba(255,71,87,0.15)', border: '1px solid rgba(255,71,87,0.4)', borderRadius: 4, color: '#ff4757', padding: '3px 10px', cursor: 'pointer', fontSize: 11 }}>✕ 닫기</button>
      </div>

      {/* Row 1: 날짜 + 시나리오 + ETF */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr 1.5fr', gap: 10, marginBottom: 10 }}>
        {[
          { label: '날짜', key: 'date', type: 'date' },
        ].map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 9, color: 'var(--text-dim)', display: 'block', marginBottom: 4 }}>{f.label}</label>
            <input type={f.type} value={(form as any)[f.key]} onChange={e => handleFormChange(f.key as any, e.target.value)}
              style={{ width: '100%', background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 4, padding: '6px 8px', color: 'var(--text-primary)', fontSize: 11, fontFamily: 'Share Tech Mono, monospace', boxSizing: 'border-box' }} />
          </div>
        ))}
        <div>
          <label style={{ fontSize: 9, color: 'var(--text-dim)', display: 'block', marginBottom: 4 }}>시나리오</label>
          <select value={form.scenario} onChange={e => handleFormChange('scenario', e.target.value as Scenario)}
            style={{ width: '100%', background: '#071d35', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 4, padding: '6px 8px', color: 'var(--text-primary)', fontSize: 11, boxSizing: 'border-box' }}>
            {SCENARIO_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label style={{ fontSize: 9, color: 'var(--text-dim)', display: 'block', marginBottom: 4 }}>선택 ETF</label>
          <select value={form.etf} onChange={e => handleFormChange('etf', e.target.value as ETFCode)}
            style={{ width: '100%', background: '#071d35', border: `1px solid ${ETF_COLORS[form.etf]}55`, borderRadius: 4, padding: '6px 8px', color: ETF_COLORS[form.etf], fontSize: 11, fontWeight: 700, boxSizing: 'border-box' }}>
            {ETF_OPTIONS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
        </div>
      </div>

      {/* Row 2: 신호 데이터 */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, marginBottom: 10 }}>
        {[
          { label: 'MU 등락률 (%)', key: 'muChange' },
          { label: 'WDC 등락률 (%)', key: 'wdcChange' },
          { label: 'SOX 등락률 (%)', key: 'soxChange' },
          { label: 'KOSPI 등락률 (%)', key: 'kospiChange' },
          { label: 'VIX', key: 'vix' },
        ].map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 9, color: 'var(--text-dim)', display: 'block', marginBottom: 4 }}>{f.label}</label>
            <input type="number" step="0.01" value={(form as any)[f.key]} onChange={e => handleFormChange(f.key as any, parseFloat(e.target.value) || 0)}
              style={{ width: '100%', background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,212,255,0.15)', borderRadius: 4, padding: '6px 8px', color: 'var(--text-primary)', fontSize: 11, fontFamily: 'Share Tech Mono, monospace', boxSizing: 'border-box' }} />
          </div>
        ))}
      </div>

      {/* Row 3: 매매 정보 */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 10 }}>
        {[
          { label: '매수가 (원)', key: 'buyPrice' },
          { label: '매도가 (원, 0=미청산)', key: 'sellPrice' },
          { label: '수량 (주)', key: 'quantity' },
        ].map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 9, color: 'var(--text-dim)', display: 'block', marginBottom: 4 }}>{f.label}</label>
            <input type="number" value={(form as any)[f.key]} onChange={e => handleFormChange(f.key as any, parseFloat(e.target.value) || 0)}
              style={{ width: '100%', background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,212,255,0.15)', borderRadius: 4, padding: '6px 8px', color: 'var(--text-primary)', fontSize: 11, fontFamily: 'Share Tech Mono, monospace', boxSizing: 'border-box' }} />
          </div>
        ))}
      </div>

      {/* 자동 계산 결과 */}
      {form.sellPrice > 0 && form.buyPrice > 0 && form.quantity > 0 && (
        <div style={{ display: 'flex', gap: 16, marginBottom: 10, padding: '8px 12px', background: form.pnlRate >= 0 ? 'rgba(0,255,136,0.06)' : 'rgba(255,71,87,0.06)', border: `1px solid ${form.pnlRate >= 0 ? 'rgba(0,255,136,0.3)' : 'rgba(255,71,87,0.3)'}`, borderRadius: 6 }}>
          <div><span style={{ fontSize: 9, color: 'var(--text-dim)' }}>손익 </span><span style={{ fontSize: 14, fontWeight: 700, color: form.pnlRate >= 0 ? '#00ff88' : '#ff4757', fontFamily: 'Share Tech Mono, monospace' }}>{form.pnl >= 0 ? '+' : ''}{form.pnl.toLocaleString()}원</span></div>
          <div><span style={{ fontSize: 9, color: 'var(--text-dim)' }}>수익률 </span><span style={{ fontSize: 14, fontWeight: 700, color: form.pnlRate >= 0 ? '#00ff88' : '#ff4757', fontFamily: 'Share Tech Mono, monospace' }}>{form.pnlRate >= 0 ? '+' : ''}{form.pnlRate.toFixed(2)}%</span></div>
        </div>
      )}

      {/* 메모 */}
      <div style={{ marginBottom: 12 }}>
        <label style={{ fontSize: 9, color: 'var(--text-dim)', display: 'block', marginBottom: 4 }}>메모 / 매매 근거</label>
        <textarea value={form.memo} onChange={e => handleFormChange('memo', e.target.value)} rows={2}
          placeholder="시나리오 판단 근거, 시장 상황, 특이사항 등을 기록하세요..."
          style={{ width: '100%', background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,212,255,0.15)', borderRadius: 4, padding: '8px 10px', color: 'var(--text-primary)', fontSize: 11, resize: 'vertical', boxSizing: 'border-box', fontFamily: 'Noto Sans KR, sans-serif', lineHeight: 1.5 }} />
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={handleSubmit} style={{ background: 'linear-gradient(135deg, rgba(0,212,255,0.2), rgba(0,180,216,0.15))', border: '1px solid #00d4ff', borderRadius: 6, color: '#00d4ff', padding: '8px 20px', cursor: 'pointer', fontSize: 12, fontWeight: 700, letterSpacing: 0.5 }}>
          {editId ? '✓ 수정 완료' : '✓ 기록 저장'}
        </button>
        <button onClick={() => { setForm(emptyForm()); setEditId(null); setShowForm(false); }} style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6, color: 'var(--text-secondary)', padding: '8px 16px', cursor: 'pointer', fontSize: 11 }}>
          취소
        </button>
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* ── 상단 KPI 카드 ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10 }}>
        {[
          { label: '총 매매 횟수', val: `${records.length}회`, sub: `청산 ${closedRecords.length} / 미청산 ${records.length - closedRecords.length}`, color: '#00d4ff' },
          { label: '누적 손익', val: `${totalPnl >= 0 ? '+' : ''}${totalPnl.toLocaleString()}원`, sub: '청산 기준', color: totalPnl >= 0 ? '#00ff88' : '#ff4757' },
          { label: '평균 수익률', val: `${avgPnlRate >= 0 ? '+' : ''}${avgPnlRate.toFixed(2)}%`, sub: '청산 기준', color: avgPnlRate >= 0 ? '#00ff88' : '#ff4757' },
          { label: '승률', val: `${winRate.toFixed(1)}%`, sub: `${winCount}승 ${closedRecords.length - winCount}패`, color: winRate >= 60 ? '#00ff88' : winRate >= 50 ? '#ffd166' : '#ff4757' },
          { label: '최대 수익', val: `+${maxWin.toFixed(2)}%`, sub: '단일 거래', color: '#00ff88' },
          { label: '최대 손실', val: `${maxLoss.toFixed(2)}%`, sub: '단일 거래', color: '#ff4757' },
        ].map(card => (
          <div key={card.label} style={{ background: `${card.color}08`, border: `1px solid ${card.color}25`, borderRadius: 8, padding: '12px 14px' }}>
            <div style={{ fontSize: 9, color: 'var(--text-dim)', marginBottom: 4, letterSpacing: 0.3 }}>{card.label}</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: card.color, fontFamily: 'Share Tech Mono, monospace', marginBottom: 2 }}>{card.val}</div>
            <div style={{ fontSize: 9, color: 'var(--text-dim)' }}>{card.sub}</div>
          </div>
        ))}
      </div>

      {/* ── 누적 수익률 차트 ── */}
      {cumulativeData.length > 0 && (
        <div className="card-cyber" style={{ padding: '14px 18px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00ff88', display: 'inline-block', marginRight: 6 }} />
            누적 수익률 추이
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={cumulativeData} margin={{ top: 4, right: 16, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
              <XAxis dataKey="date" tick={{ fill: '#3d6480', fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={0} stroke="rgba(255,255,255,0.15)" strokeDasharray="4 4" />
              <Line type="monotone" dataKey="cumRate" stroke="#00ff88" strokeWidth={2} dot={{ fill: '#00ff88', r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* ── 뷰 전환 + 필터 + 추가 버튼 ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <div style={{ display: 'flex', gap: 4 }}>
          {(['list', 'calendar', 'stats'] as const).map(mode => (
            <button key={mode} onClick={() => setViewMode(mode)} style={{
              padding: '6px 14px', fontSize: 11, borderRadius: 4, cursor: 'pointer', fontWeight: viewMode === mode ? 700 : 400,
              background: viewMode === mode ? 'rgba(0,212,255,0.15)' : 'transparent',
              border: `1px solid ${viewMode === mode ? '#00d4ff' : 'rgba(255,255,255,0.1)'}`,
              color: viewMode === mode ? '#00d4ff' : 'var(--text-secondary)',
            }}>
              {mode === 'list' ? '📋 목록' : mode === 'calendar' ? '📅 캘린더' : '📊 ETF별 통계'}
            </button>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {viewMode === 'list' && (
            <select value={filterEtf} onChange={e => setFilterEtf(e.target.value as any)}
              style={{ background: '#071d35', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 4, padding: '5px 10px', color: 'var(--text-secondary)', fontSize: 11 }}>
              <option value="ALL">전체 ETF</option>
              {ETF_OPTIONS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          )}
          <button onClick={() => { setShowForm(!showForm); setEditId(null); setForm(emptyForm()); }} style={{
            background: 'linear-gradient(135deg, rgba(0,212,255,0.2), rgba(0,180,216,0.1))',
            border: '1px solid #00d4ff', borderRadius: 6, color: '#00d4ff', padding: '6px 16px', cursor: 'pointer', fontSize: 11, fontWeight: 700,
          }}>
            {showForm ? '✕ 닫기' : '➕ 새 기록 추가'}
          </button>
        </div>
      </div>

      {/* ── 입력 폼 ── */}
      {showForm && <FormPanel />}

      {/* ── 목록 뷰 ── */}
      {viewMode === 'list' && (
        <div className="card-cyber" style={{ padding: '14px 18px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00d4ff', display: 'inline-block', marginRight: 6 }} />
            매매 기록 — {filteredRecords.length}건
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-bright)' }}>
                  {['날짜', '시나리오', 'ETF', 'MU%', 'WDC%', 'SOX%', 'KOSPI%', 'VIX', '매수가', '매도가', '수량', '손익', '수익률', '상태', '메모', ''].map(h => (
                    <th key={h} style={{ padding: '7px 10px', textAlign: 'center', color: 'var(--text-secondary)', fontSize: 9, fontWeight: 700, letterSpacing: 0.5, whiteSpace: 'nowrap', background: 'rgba(0,212,255,0.03)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredRecords.length === 0 && (
                  <tr><td colSpan={16} style={{ textAlign: 'center', padding: '32px', color: 'var(--text-dim)', fontSize: 12 }}>매매 기록이 없습니다. 새 기록을 추가하세요.</td></tr>
                )}
                {filteredRecords.map(r => (
                  <tr key={r.id} style={{ borderBottom: '1px solid rgba(0,212,255,0.05)', transition: 'background 0.15s' }}
                    onMouseEnter={e => (e.currentTarget as HTMLTableRowElement).style.background = 'rgba(0,212,255,0.03)'}
                    onMouseLeave={e => (e.currentTarget as HTMLTableRowElement).style.background = 'transparent'}>
                    <td style={{ padding: '8px 10px', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{r.date}</td>
                    <td style={{ padding: '8px 10px', fontSize: 10, color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{r.scenario}</td>
                    <td style={{ padding: '8px 10px', textAlign: 'center' }}>
                      <span style={{ padding: '2px 8px', borderRadius: 3, background: `${ETF_COLORS[r.etf]}18`, border: `1px solid ${ETF_COLORS[r.etf]}55`, color: ETF_COLORS[r.etf], fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap' }}>{r.etf}</span>
                    </td>
                    {[r.muChange, r.wdcChange, r.soxChange, r.kospiChange].map((v, i) => (
                      <td key={i} style={{ padding: '8px 6px', textAlign: 'center', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: v > 0 ? '#00ff88' : v < 0 ? '#ff4757' : 'var(--text-dim)', whiteSpace: 'nowrap' }}>
                        {v > 0 ? '+' : ''}{v.toFixed(2)}%
                      </td>
                    ))}
                    <td style={{ padding: '8px 6px', textAlign: 'center', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: r.vix > 25 ? '#ff4757' : r.vix > 20 ? '#ffd166' : 'var(--text-secondary)' }}>{r.vix.toFixed(1)}</td>
                    <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: 'var(--text-primary)', whiteSpace: 'nowrap' }}>{r.buyPrice.toLocaleString()}</td>
                    <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: r.sellPrice > 0 ? 'var(--text-primary)' : 'var(--text-dim)', whiteSpace: 'nowrap' }}>{r.sellPrice > 0 ? r.sellPrice.toLocaleString() : '—'}</td>
                    <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: 'var(--text-secondary)' }}>{r.quantity.toLocaleString()}</td>
                    <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: r.isOpen ? 'var(--text-dim)' : r.pnl >= 0 ? '#00ff88' : '#ff4757', whiteSpace: 'nowrap' }}>
                      {r.isOpen ? '—' : `${r.pnl >= 0 ? '+' : ''}${r.pnl.toLocaleString()}원`}
                    </td>
                    <td style={{ padding: '8px 8px', textAlign: 'center', fontFamily: 'Share Tech Mono, monospace', fontSize: 11, fontWeight: 700, color: r.isOpen ? 'var(--text-dim)' : r.pnlRate >= 0 ? '#00ff88' : '#ff4757' }}>
                      {r.isOpen ? '—' : `${r.pnlRate >= 0 ? '+' : ''}${r.pnlRate.toFixed(2)}%`}
                    </td>
                    <td style={{ padding: '8px 8px', textAlign: 'center' }}>
                      <span style={{ fontSize: 9, padding: '2px 6px', borderRadius: 3, background: r.isOpen ? 'rgba(255,213,102,0.15)' : 'rgba(0,255,136,0.1)', border: `1px solid ${r.isOpen ? '#ffd16655' : '#00ff8855'}`, color: r.isOpen ? '#ffd166' : '#00ff88' }}>
                        {r.isOpen ? '🔓 미청산' : '✓ 청산'}
                      </span>
                    </td>
                    <td style={{ padding: '8px 10px', fontSize: 9, color: 'var(--text-dim)', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={r.memo}>{r.memo || '—'}</td>
                    <td style={{ padding: '8px 8px', whiteSpace: 'nowrap' }}>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button onClick={() => handleEdit(r)} style={{ background: 'rgba(0,212,255,0.1)', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 3, color: '#00d4ff', padding: '3px 8px', cursor: 'pointer', fontSize: 9 }}>수정</button>
                        {deleteConfirm === r.id ? (
                          <>
                            <button onClick={() => handleDelete(r.id)} style={{ background: 'rgba(255,71,87,0.2)', border: '1px solid #ff4757', borderRadius: 3, color: '#ff4757', padding: '3px 8px', cursor: 'pointer', fontSize: 9 }}>확인</button>
                            <button onClick={() => setDeleteConfirm(null)} style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 3, color: 'var(--text-dim)', padding: '3px 6px', cursor: 'pointer', fontSize: 9 }}>취소</button>
                          </>
                        ) : (
                          <button onClick={() => setDeleteConfirm(r.id)} style={{ background: 'rgba(255,71,87,0.08)', border: '1px solid rgba(255,71,87,0.2)', borderRadius: 3, color: '#ff4757', padding: '3px 8px', cursor: 'pointer', fontSize: 9 }}>삭제</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── 캘린더 뷰 ── */}
      {viewMode === 'calendar' && (
        <div className="card-cyber" style={{ padding: '16px 20px' }}>
          <CalendarView />
        </div>
      )}

      {/* ── ETF별 통계 뷰 ── */}
      {viewMode === 'stats' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* ETF별 평균 수익률 바 차트 */}
          <div className="card-cyber" style={{ padding: '14px 18px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#ffd166', display: 'inline-block', marginRight: 6 }} />
              ETF별 평균 수익률
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={etfStats} margin={{ top: 4, right: 16, bottom: 0, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
                <XAxis dataKey="etf" tick={{ fill: '#3d6480', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => v.replace('KODEX', '')} />
                <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} />
                <Tooltip formatter={(v: any) => [`${v}%`, '평균 수익률']} contentStyle={{ background: '#071d35', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 6, fontSize: 11 }} />
                <ReferenceLine y={0} stroke="rgba(255,255,255,0.15)" />
                <Bar dataKey="avgRate" radius={[3, 3, 0, 0]}>
                  {etfStats.map(e => <Cell key={e.etf} fill={ETF_COLORS[e.etf as ETFCode]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* ETF별 상세 통계 테이블 */}
          <div className="card-cyber" style={{ padding: '14px 18px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#a855f7', display: 'inline-block', marginRight: 6 }} />
              ETF별 상세 성과
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-bright)' }}>
                  {['ETF', '매매 횟수', '평균 수익률', '승률', '평가'].map(h => (
                    <th key={h} style={{ padding: '7px 12px', textAlign: 'center', color: 'var(--text-secondary)', fontSize: 9, fontWeight: 700, letterSpacing: 0.5 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {etfStats.length === 0 && (
                  <tr><td colSpan={5} style={{ textAlign: 'center', padding: '24px', color: 'var(--text-dim)', fontSize: 11 }}>청산된 매매 기록이 없습니다.</td></tr>
                )}
                {etfStats.map(e => (
                  <tr key={e.etf} style={{ borderBottom: '1px solid rgba(0,212,255,0.05)' }}>
                    <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                      <span style={{ padding: '3px 10px', borderRadius: 3, background: `${ETF_COLORS[e.etf as ETFCode]}18`, border: `1px solid ${ETF_COLORS[e.etf as ETFCode]}55`, color: ETF_COLORS[e.etf as ETFCode], fontWeight: 700, fontSize: 11 }}>{e.etf}</span>
                    </td>
                    <td style={{ padding: '10px 12px', textAlign: 'center', fontFamily: 'Share Tech Mono, monospace', color: 'var(--text-primary)' }}>{e.count}회</td>
                    <td style={{ padding: '10px 12px', textAlign: 'center', fontFamily: 'Share Tech Mono, monospace', fontWeight: 700, fontSize: 13, color: e.avgRate >= 0 ? '#00ff88' : '#ff4757' }}>
                      {e.avgRate >= 0 ? '+' : ''}{e.avgRate.toFixed(2)}%
                    </td>
                    <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                        <div style={{ width: 60, height: 6, background: 'rgba(255,255,255,0.08)', borderRadius: 3, overflow: 'hidden' }}>
                          <div style={{ height: '100%', width: `${e.winRate}%`, background: e.winRate >= 60 ? '#00ff88' : e.winRate >= 50 ? '#ffd166' : '#ff4757', borderRadius: 3 }} />
                        </div>
                        <span style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 11, color: e.winRate >= 60 ? '#00ff88' : e.winRate >= 50 ? '#ffd166' : '#ff4757' }}>{e.winRate}%</span>
                      </div>
                    </td>
                    <td style={{ padding: '10px 12px', textAlign: 'center', fontSize: 10 }}>
                      <span style={{ padding: '2px 8px', borderRadius: 3, background: e.avgRate > 1 ? 'rgba(0,255,136,0.1)' : e.avgRate > 0 ? 'rgba(255,213,102,0.1)' : 'rgba(255,71,87,0.1)', color: e.avgRate > 1 ? '#00ff88' : e.avgRate > 0 ? '#ffd166' : '#ff4757', fontSize: 10 }}>
                        {e.avgRate > 1 ? '✓ 우수' : e.avgRate > 0 ? '△ 보통' : '✕ 부진'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 일별 수익률 바 차트 */}
          {cumulativeData.length > 0 && (
            <div className="card-cyber" style={{ padding: '14px 18px' }}>
              <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00c8a0', display: 'inline-block', marginRight: 6 }} />
                일별 수익률
              </div>
              <ResponsiveContainer width="100%" height={140}>
                <BarChart data={cumulativeData} margin={{ top: 4, right: 16, bottom: 0, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
                  <XAxis dataKey="date" tick={{ fill: '#3d6480', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} />
                  <Tooltip formatter={(v: any) => [`${v}%`, '일별 수익률']} contentStyle={{ background: '#071d35', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 6, fontSize: 11 }} />
                  <ReferenceLine y={0} stroke="rgba(255,255,255,0.15)" />
                  <Bar dataKey="dayRate" radius={[2, 2, 0, 0]}>
                    {cumulativeData.map((d, i) => <Cell key={i} fill={d.dayRate >= 0 ? '#00ff88' : '#ff4757'} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
