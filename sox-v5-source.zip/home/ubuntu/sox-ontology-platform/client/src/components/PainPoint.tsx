// ─── PainPoint.tsx ───
// 페인포인트 분석 & TO-BE 모델 정의 컴포넌트
// Design: Cyberpunk Terminal — AS-IS vs TO-BE transformation visualization

export default function PainPoint() {
  const painPoints = [
    {
      id: '①',
      title: '정보 비대칭',
      asis: '미국 반도체 업종 동향을 실시간으로 파악하지 못하고, 전날 미국장의 영향을 체계적으로 한국 전략에 반영하지 못함',
      tobe: '실시간 데이터 파이프라인',
      tobeDesc: 'Bloomberg/Yahoo Finance API 연동으로 SOX 종가 자동 수집, 익일 한국장 오전 9시 이전 시그널 자동 생성',
      metric: '신호 생성 지연: 24시간 → <1분',
    },
    {
      id: '②',
      title: '감(感) 의존 의사결정',
      asis: 'SOX 지수와 KOSPI200 간의 구조적 관계를 정량화하지 못해 감에 의존한 투자 결정으로 손실 발생',
      tobe: '온톨로지 기반 추론 엔진',
      tobeDesc: 'OWL2/SWRL 규칙으로 SOX-KOSPI 관계를 형식화하고, Apache Jena 추론기로 자동 시그널 추론 및 SPARQL 검증',
      metric: '의사결정 정확도: 감 의존 → 63.7% 규칙 기반',
    },
    {
      id: '③',
      title: '리스크 관리 부재',
      asis: '시장 급변 시 손절 기준이 없고, 인버스/정방향 스위칭 타이밍을 놓쳐 양쪽에서 손실 발생',
      tobe: '정량적 리스크 관리',
      tobeDesc: 'MDD 3% 초과 시 자동 스탑로스, VIX 30 초과 시 현금 50% 전환, 포지션 사이즈 최적화 자동 실행',
      metric: 'MDD 개선: -25% → -9.8% (전략D)',
    },
    {
      id: '④',
      title: '검증 없는 전략 실행',
      asis: '과거 데이터로 백테스팅을 수행하지 않고 실전 매매에 투입, 과적합 전략으로 실전에서 손실',
      tobe: '워크포워드 백테스팅',
      tobeDesc: '10년 이상 데이터 기반 인샘플/아웃오브샘플 검증, 격자탐색으로 최적 파라미터 도출 후 실전 투입',
      metric: '아웃오브샘플 효율성: 평균 84.6%',
    },
    {
      id: '⑤',
      title: '온톨로지 부재',
      asis: '시장 참여자, 지수, ETF, 전략, 리스크 간의 의미적 관계가 정의되지 않아 지식 재활용 불가',
      tobe: '지식그래프 플랫폼',
      tobeDesc: '투자 도메인 온톨로지(시장/지수/ETF/전략/리스크)를 RDF/OWL로 구조화하여 지식 재활용 및 확장 가능',
      metric: 'RDF 트리플: 0 → 1,247개 / OWL 클래스: 42개',
    },
  ];

  const solutionComponents = [
    {
      title: '데이터 파이프라인',
      items: ['Bloomberg/Yahoo Finance API 연동', 'SOX 종가 자동 수집 (미국장 마감 후)', '익일 9시 이전 신호 자동 생성', '데이터 품질 검증 및 이상치 처리'],
      color: '#00d4ff',
      icon: '📡',
    },
    {
      title: '온톨로지 엔진',
      items: ['OWL2 클래스 계층 정의 (42개)', 'SWRL 추론 규칙 구현 (6개+)', 'Apache Jena 추론기 연동', 'SPARQL 쿼리 기반 신호 추출'],
      color: '#a855f7',
      icon: '🧠',
    },
    {
      title: '백테스팅 플랫폼',
      items: ['2015-2024 10년 데이터 기반', '4가지 전략 변형 비교', '워크포워드 검증 자동화', '몬테카를로 1000회 시뮬레이션'],
      color: '#f0b429',
      icon: '🔁',
    },
    {
      title: '리스크 관리 시스템',
      items: ['트레일링 스탑로스 (MDD 3%)', 'VIX 연동 포지션 조절', 'VaR/CVaR 일별 계산', '자동 알림 및 리포트'],
      color: '#ff4757',
      icon: '🛡️',
    },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Header Banner */}
      <div className="card-cyber" style={{ padding: '20px 24px', background: 'linear-gradient(135deg, rgba(4,20,38,0.8), rgba(7,29,53,0.8))', borderColor: 'var(--cyan-dim)', textAlign: 'center' }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: 'var(--cyan)', textTransform: 'uppercase', marginBottom: 6 }}>
          PAIN POINT → SOLUTION → TO-BE MODEL
        </div>
        <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 6 }}>
          SOX-KOSPI 투자 전략 혁신 프레임워크
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
          5대 페인포인트 분석 → 온톨로지 기반 솔루션 → TO-BE 자동화 플랫폼
        </div>
      </div>

      {/* AS-IS vs TO-BE Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 40px 1fr', gap: 0 }}>
        {/* AS-IS Column */}
        <div>
          <div style={{ fontSize: 11, letterSpacing: 2, color: 'var(--red)', fontWeight: 700, textAlign: 'center', marginBottom: 10, textTransform: 'uppercase', padding: '6px 0', background: 'rgba(255,71,87,0.08)', borderRadius: 4 }}>
            AS-IS 현황 (페인포인트)
          </div>
          {painPoints.map(pp => (
            <div key={pp.id} className="pp-card asis" style={{ marginBottom: 8 }}>
              <div className="pp-card-title">{pp.id} {pp.title}</div>
              <div className="pp-text">{pp.asis}</div>
            </div>
          ))}
        </div>

        {/* Arrow Column */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <div style={{ fontSize: 10, color: 'var(--cyan)', textAlign: 'center', letterSpacing: 1, textTransform: 'uppercase', writingMode: 'vertical-rl', transform: 'rotate(180deg)', marginBottom: 8 }}>
            TRANSFORMATION
          </div>
          {painPoints.map((_, i) => (
            <div key={i} style={{ fontSize: 18, color: 'var(--cyan)', lineHeight: 3.2 }}>→</div>
          ))}
        </div>

        {/* TO-BE Column */}
        <div>
          <div style={{ fontSize: 11, letterSpacing: 2, color: 'var(--green)', fontWeight: 700, textAlign: 'center', marginBottom: 10, textTransform: 'uppercase', padding: '6px 0', background: 'rgba(0,255,136,0.08)', borderRadius: 4 }}>
            TO-BE 모델 (솔루션)
          </div>
          {painPoints.map(pp => (
            <div key={pp.id} className="pp-card tobe" style={{ marginBottom: 8 }}>
              <div className="pp-card-title">{pp.id} {pp.tobe}</div>
              <div className="pp-text">{pp.tobeDesc}</div>
              <div style={{ marginTop: 4, fontSize: 10, color: 'var(--cyan)', fontFamily: 'Share Tech Mono, monospace' }}>
                📊 {pp.metric}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Solution Components */}
      <div className="card-cyber card-cyber-green" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 14 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)', display: 'inline-block', marginRight: 6 }} />
          TO-BE 솔루션 구성 요소
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {solutionComponents.map(comp => (
            <div key={comp.title} style={{ background: `${comp.color}08`, border: `1px solid ${comp.color}33`, borderRadius: 8, padding: 14 }}>
              <div style={{ fontSize: 20, marginBottom: 6 }}>{comp.icon}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: comp.color, marginBottom: 10 }}>{comp.title}</div>
              {comp.items.map((item, i) => (
                <div key={i} style={{ display: 'flex', gap: 5, marginBottom: 4, fontSize: 10, color: 'var(--text-secondary)' }}>
                  <span style={{ color: comp.color, flexShrink: 0 }}>▸</span> {item}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* KPI Targets */}
      <div className="card-cyber" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold)', display: 'inline-block', marginRight: 6 }} />
          TO-BE KPI 목표 지표
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
          {[
            { label: '연환산 수익률', asis: '~5%', tobe: '+16.1%', color: '#00ff88' },
            { label: '최대 낙폭(MDD)', asis: '-25%', tobe: '-9.8%', color: '#ff4757' },
            { label: '샤프 지수', asis: '0.3~0.5', tobe: '2.14', color: '#f0b429' },
            { label: '신호 생성 속도', asis: '수동 (24h)', tobe: '자동 (<1min)', color: '#00d4ff' },
            { label: '투자 회수 기간', asis: '미측정', tobe: '3~6개월', color: '#a855f7' },
          ].map(kpi => (
            <div key={kpi.label} className="stat-card-cyber">
              <div style={{ fontSize: 9, color: 'var(--text-secondary)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 6 }}>{kpi.label}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                <span style={{ fontSize: 9, color: 'var(--text-dim)' }}>AS-IS</span>
                <span className="font-mono-data" style={{ fontSize: 11, color: 'var(--red)' }}>{kpi.asis}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 9, color: 'var(--text-dim)' }}>TO-BE</span>
                <span className="font-mono-data" style={{ fontSize: 13, fontWeight: 700, color: kpi.color }}>{kpi.tobe}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
