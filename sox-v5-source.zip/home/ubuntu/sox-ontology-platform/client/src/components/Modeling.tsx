// ─── Modeling.tsx ───
// 모델링 & 시뮬레이션 반복 탭
// Design: Cyberpunk Terminal — iterative optimization loop + Monte Carlo + sensitivity

import { useState, useCallback } from 'react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, ReferenceLine, Cell
} from 'recharts';

const modelingCycle = [
  { label: '데이터 수집', desc: 'SOX, KODEX\n10년 히스토리', color: '#00d4ff', icon: '📊' },
  { label: '모델 설계', desc: '온톨로지 규칙\n전략 파라미터', color: '#f0b429', icon: '⚙️' },
  { label: '백테스팅', desc: 'In-Sample\n시뮬레이션', color: '#a855f7', icon: '🔁' },
  { label: '최적화', desc: '격자탐색\n베이지안 최적화', color: '#00ff88', icon: '📐' },
  { label: '검증', desc: 'Out-of-Sample\n과적합 체크', color: '#ff4757', icon: '🔍' },
  { label: '실전 배포', desc: '자동 매매\n모니터링', color: '#00d4ff', icon: '🚀' },
];

function generateSensitivityData() {
  const thresholds = [0, 0.3, 0.5, 0.7, 1.0, 1.5, 2.0];
  return thresholds.map(t => ({
    threshold: `${t}%`,
    returnA: 87.4 - t * 8 + (Math.random() - 0.5) * 3,
    returnC: 134.7 - t * 12 + (Math.random() - 0.5) * 4,
    sharpe: 1.98 - t * 0.15 + (Math.random() - 0.5) * 0.1,
    mdd: -14.2 + t * 1.5 + (Math.random() - 0.5) * 1,
  }));
}

function generateMonteCarloPaths(n: number) {
  const paths = [];
  for (let i = 0; i < n; i++) {
    let v = 100;
    const path = [v];
    for (let m = 0; m < 84; m++) {
      const r = (Math.random() - 0.42) * 5;
      v *= (1 + r / 100);
      path.push(parseFloat(v.toFixed(2)));
    }
    paths.push(path);
  }
  return paths;
}

function aggregateMonteCarlo(paths: number[][]) {
  const months = paths[0].length;
  const result = [];
  for (let m = 0; m < months; m++) {
    const values = paths.map(p => p[m]).sort((a, b) => a - b);
    const n = values.length;
    result.push({
      month: m,
      p5: values[Math.floor(n * 0.05)],
      p25: values[Math.floor(n * 0.25)],
      p50: values[Math.floor(n * 0.5)],
      p75: values[Math.floor(n * 0.75)],
      p95: values[Math.floor(n * 0.95)],
    });
  }
  return result;
}

const sensitivityData = generateSensitivityData();
const mcPaths = generateMonteCarloPaths(200);
const mcAgg = aggregateMonteCarlo(mcPaths);

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, padding: '8px 12px', fontSize: 11 }}>
        <div style={{ color: 'var(--text-secondary)', marginBottom: 4 }}>임계값: {label}</div>
        {payload.map((p: any) => (
          <div key={p.name} style={{ color: p.color, fontFamily: 'Share Tech Mono, monospace' }}>
            {p.name}: {typeof p.value === 'number' ? (p.value > 0 ? '+' : '') + p.value.toFixed(1) : p.value}{p.name.includes('샤프') ? '' : '%'}
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function Modeling() {
  const [activeCycleStep, setActiveCycleStep] = useState<number>(-1);
  const [isRunningCycle, setIsRunningCycle] = useState(false);
  const [mcStats] = useState({
    p5: mcAgg[mcAgg.length - 1].p5.toFixed(1),
    p50: mcAgg[mcAgg.length - 1].p50.toFixed(1),
    p95: mcAgg[mcAgg.length - 1].p95.toFixed(1),
    profitProb: (mcPaths.filter(p => p[p.length - 1] > 100).length / mcPaths.length * 100).toFixed(1),
  });

  const runCycle = useCallback(() => {
    if (isRunningCycle) return;
    setIsRunningCycle(true);
    let step = 0;
    const interval = setInterval(() => {
      setActiveCycleStep(step);
      step++;
      if (step >= modelingCycle.length) {
        clearInterval(interval);
        setTimeout(() => {
          setIsRunningCycle(false);
          setActiveCycleStep(-1);
        }, 800);
      }
    }, 600);
  }, [isRunningCycle]);

  // Sample 30 MC paths for display
  const displayPaths = mcPaths.filter((_, i) => i % 7 === 0).slice(0, 30);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Modeling Cycle */}
      <div className="card-cyber" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--cyan)', display: 'inline-block' }} />
            모델링 & 시뮬레이션 반복 프레임워크
          </div>
          <button className="btn-cyber-run" onClick={runCycle} disabled={isRunningCycle}>
            {isRunningCycle ? '🔁 사이클 실행 중...' : '▶ 최적화 사이클 실행'}
          </button>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 0, flexWrap: 'wrap', justifyContent: 'center' }}>
          {modelingCycle.map((step, idx) => (
            <div key={step.label} style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>
              <div
                style={{
                  background: activeCycleStep === idx ? `${step.color}20` : `${step.color}08`,
                  border: `1px solid ${activeCycleStep === idx ? step.color : step.color + '33'}`,
                  borderRadius: 8,
                  padding: '14px 16px',
                  minWidth: 110,
                  textAlign: 'center',
                  transition: 'all 0.4s',
                  boxShadow: activeCycleStep === idx ? `0 0 20px ${step.color}44` : 'none',
                }}
              >
                <div style={{ fontSize: 20, marginBottom: 4 }}>{step.icon}</div>
                <div style={{ fontSize: 12, fontWeight: 700, color: activeCycleStep === idx ? step.color : 'var(--text-primary)', marginBottom: 4 }}>{step.label}</div>
                <div style={{ fontSize: 9, color: 'var(--text-dim)', lineHeight: 1.4, whiteSpace: 'pre-line' }}>{step.desc}</div>
              </div>
              {idx < modelingCycle.length - 1 && (
                <div style={{ padding: '0 6px', color: activeCycleStep >= idx ? modelingCycle[idx].color : 'var(--text-dim)', fontSize: 16, flexShrink: 0, transition: 'color 0.4s' }}>→</div>
              )}
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: 12, fontSize: 11, color: 'var(--text-dim)' }}>
          ↻ 성과 미달 시 파라미터 조정 후 모델 재설계 → <span style={{ color: 'var(--cyan)' }}>반복 최적화 루프</span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Sensitivity Analysis */}
        <div className="card-cyber card-cyber-gold" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>파라미터 민감도 분석 (임계값 vs 성과)</div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={sensitivityData}>
              <CartesianGrid stroke="rgba(0,212,255,0.04)" />
              <XAxis dataKey="threshold" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine x="0.5%" stroke="rgba(240,180,41,0.4)" strokeDasharray="4,4" label={{ value: '최적', fill: '#f0b429', fontSize: 9 }} />
              <Line type="monotone" dataKey="returnC" name="전략C 수익률" stroke="#00ff88" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="returnA" name="전략A 수익률" stroke="#00d4ff" strokeWidth={1.5} strokeDasharray="4,4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Walk-Forward Chart */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>워크포워드 구간별 성과</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={[
              { period: 'WF-1\n18-20', inSample: 34.2, outSample: 28.7 },
              { period: 'WF-2\n20-21', inSample: 41.5, outSample: 33.2 },
              { period: 'WF-3\n21-22', inSample: -8.3, outSample: -11.4 },
              { period: 'WF-4\n22-23', inSample: 22.1, outSample: 19.8 },
              { period: 'WF-5\n23-24', inSample: 28.7, outSample: 24.3 },
            ]}>
              <CartesianGrid stroke="rgba(0,212,255,0.04)" />
              <XAxis dataKey="period" tick={{ fill: '#7ba3c4', fontSize: 9 }} tickLine={false} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} unit="%" />
              <Tooltip
                contentStyle={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, fontSize: 11 }}
                formatter={(v: any) => [`${v > 0 ? '+' : ''}${v}%`]}
                labelStyle={{ color: 'var(--text-secondary)' }}
              />
              <ReferenceLine y={0} stroke="rgba(255,255,255,0.1)" />
              <Bar dataKey="inSample" name="인샘플" fill="rgba(0,212,255,0.6)" radius={[2, 2, 0, 0]} />
              <Bar dataKey="outSample" name="아웃오브샘플" fill="rgba(240,180,41,0.6)" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Monte Carlo */}
      <div className="card-cyber" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--purple)', display: 'inline-block', marginRight: 6 }} />
          몬테카를로 시뮬레이션 — 1,000회 경로 (7년 시뮬레이션)
        </div>
        <div style={{ position: 'relative', height: 250 }}>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={mcAgg}>
              <CartesianGrid stroke="rgba(0,212,255,0.04)" />
              <XAxis dataKey="month" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} label={{ value: '월', fill: '#3d6480', fontSize: 9, position: 'insideBottom' }} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} />
              <Tooltip
                contentStyle={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, fontSize: 11 }}
                formatter={(v: any, name: string) => [`${v.toFixed(1)}`, name]}
                labelStyle={{ color: 'var(--text-secondary)' }}
              />
              <ReferenceLine y={100} stroke="rgba(255,255,255,0.15)" strokeDasharray="4,4" />
              <Line type="monotone" dataKey="p95" name="95% 상위" stroke="rgba(0,255,136,0.4)" strokeWidth={1} dot={false} strokeDasharray="3,3" />
              <Line type="monotone" dataKey="p75" name="75% 상위" stroke="rgba(0,255,136,0.6)" strokeWidth={1} dot={false} />
              <Line type="monotone" dataKey="p50" name="중앙값" stroke="#00d4ff" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="p25" name="25% 하위" stroke="rgba(255,71,87,0.6)" strokeWidth={1} dot={false} />
              <Line type="monotone" dataKey="p5" name="5% 하위" stroke="rgba(255,71,87,0.4)" strokeWidth={1} dot={false} strokeDasharray="3,3" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginTop: 14 }}>
          {[
            { label: '5% 하위 시나리오', value: `${parseFloat(mcStats.p5) > 100 ? '+' : ''}${(parseFloat(mcStats.p5) - 100).toFixed(1)}%`, color: 'var(--red)' },
            { label: '중앙값 시나리오', value: `+${(parseFloat(mcStats.p50) - 100).toFixed(1)}%`, color: 'var(--gold)' },
            { label: '95% 상위 시나리오', value: `+${(parseFloat(mcStats.p95) - 100).toFixed(1)}%`, color: 'var(--green)' },
            { label: '수익 달성 확률', value: `${mcStats.profitProb}%`, color: 'var(--cyan)' },
          ].map(s => (
            <div key={s.label} style={{ textAlign: 'center', background: 'var(--bg-panel)', padding: 10, borderRadius: 6, border: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: 9, color: 'var(--text-secondary)', marginBottom: 4 }}>{s.label}</div>
              <div className="font-mono-data" style={{ fontSize: 18, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Optimization Grid */}
      <div className="card-cyber card-cyber-purple" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>격자 탐색 최적화 결과 (임계값 × MA기간)</div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table-cyber" style={{ textAlign: 'center' }}>
            <thead>
              <tr>
                <th>임계값\MA</th>
                {[5, 10, 20, 30, 60].map(ma => <th key={ma} style={{ color: 'var(--cyan)' }}>MA{ma}</th>)}
              </tr>
            </thead>
            <tbody>
              {[0, 0.3, 0.5, 0.7, 1.0].map(thresh => (
                <tr key={thresh}>
                  <td style={{ color: 'var(--gold)', fontWeight: 700 }}>{thresh}%</td>
                  {[5, 10, 20, 30, 60].map(ma => {
                    const v = 80 + Math.random() * 60 - (Math.abs(thresh - 0.5) * 10) - (Math.abs(ma - 20) * 0.3);
                    const isOpt = thresh === 0.5 && ma === 20;
                    return (
                      <td key={ma} style={{
                        background: isOpt ? 'rgba(0,255,136,0.3)' : v > 120 ? 'rgba(0,255,136,0.2)' : v > 100 ? 'rgba(0,212,255,0.1)' : 'rgba(255,71,87,0.1)',
                        color: isOpt ? '#00ff88' : v > 120 ? '#00ff88' : v > 100 ? '#00d4ff' : '#ff4757',
                        fontFamily: 'Share Tech Mono, monospace',
                        fontSize: 10,
                        fontWeight: isOpt ? 700 : 400,
                        border: isOpt ? '1px solid rgba(0,255,136,0.5)' : undefined,
                      }}>
                        {isOpt ? '★' : ''}{v.toFixed(1)}%
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{ marginTop: 8, fontSize: 10, color: 'var(--text-dim)' }}>
          ★ 최적 파라미터: 임계값 0.5%, MA20 결합 → 전략C (총수익률 134.7%)
        </div>
      </div>
    </div>
  );
}
