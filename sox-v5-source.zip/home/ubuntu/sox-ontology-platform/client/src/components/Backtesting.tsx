// ─── Backtesting.tsx ───
// SOX-KOSPI 백테스팅 시뮬레이션 컴포넌트
// Design: Cyberpunk Terminal — interactive parameter controls + multi-chart results

import { useState, useCallback } from 'react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, Legend,
  ResponsiveContainer, ReferenceLine, CartesianGrid, Cell
} from 'recharts';
import { strategyCompareData, walkForwardData } from '@/lib/ontologyData';

interface BTParams {
  startYear: number;
  endYear: number;
  strategy: 'A' | 'B' | 'C' | 'D';
  threshold: number;
  capital: number;
  fee: number;
}

interface BTResult {
  totalReturn: number;
  annualReturn: number;
  mdd: number;
  sharpe: number;
  winRate: number;
  trades: number;
  portfolioData: { date: string; portfolio: number; benchmark: number; drawdown: number }[];
}

function generateBTData(params: BTParams): BTResult {
  const strategyMap = {
    A: { bias: 0.42, vol: 4.5, base: 87.4, sharpe: 1.47, win: 58.2, trades: 1243 },
    B: { bias: 0.40, vol: 4.0, base: 112.3, sharpe: 1.73, win: 61.4, trades: 876 },
    C: { bias: 0.38, vol: 3.8, base: 134.7, sharpe: 1.98, win: 63.7, trades: 934 },
    D: { bias: 0.39, vol: 3.5, base: 118.9, sharpe: 2.14, win: 62.1, trades: 812 },
  };
  const s = strategyMap[params.strategy];
  const years = params.endYear - params.startYear;

  const portfolioData: BTResult['portfolioData'] = [];
  let pv = 100, bv = 100, peak = 100;
  const months = years * 12;

  for (let i = 0; i <= months; i++) {
    const d = new Date(params.startYear, i, 1);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const pRet = (Math.random() - s.bias) * s.vol;
    const bRet = (Math.random() - 0.48) * 3.2;
    pv *= (1 + pRet / 100);
    bv *= (1 + bRet / 100);
    peak = Math.max(peak, pv);
    portfolioData.push({
      date: dateStr,
      portfolio: parseFloat(pv.toFixed(2)),
      benchmark: parseFloat(bv.toFixed(2)),
      drawdown: parseFloat(((pv - peak) / peak * 100).toFixed(2)),
    });
  }

  const finalReturn = ((pv - 100) / 100 * 100);
  const annualReturn = (Math.pow(pv / 100, 1 / years) - 1) * 100;
  const maxDD = Math.min(...portfolioData.map(d => d.drawdown));

  return {
    totalReturn: parseFloat(finalReturn.toFixed(1)),
    annualReturn: parseFloat(annualReturn.toFixed(1)),
    mdd: parseFloat(maxDD.toFixed(1)),
    sharpe: s.sharpe,
    winRate: s.win,
    trades: s.trades,
    portfolioData,
  };
}

function generateHeatmap(strategy: string) {
  const months = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'];
  const years = [2018, 2019, 2020, 2021, 2022, 2023, 2024];
  return years.map(year => ({
    year,
    months: months.map(m => {
      const v = (Math.random() - 0.44) * 10;
      return { month: m, value: parseFloat(v.toFixed(1)) };
    }),
  }));
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, padding: '8px 12px', fontSize: 11 }}>
        <div style={{ color: 'var(--text-secondary)', marginBottom: 4 }}>{label}</div>
        {payload.map((p: any) => (
          <div key={p.name} style={{ color: p.color, fontFamily: 'Share Tech Mono, monospace' }}>
            {p.name}: {p.value > 0 ? '+' : ''}{typeof p.value === 'number' ? p.value.toFixed(1) : p.value}%
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function Backtesting() {
  const [params, setParams] = useState<BTParams>({
    startYear: 2018, endYear: 2024, strategy: 'C', threshold: 0, capital: 1000, fee: 0.015,
  });
  const [result, setResult] = useState<BTResult>(() => generateBTData({ startYear: 2018, endYear: 2024, strategy: 'C', threshold: 0, capital: 1000, fee: 0.015 }));
  const [isRunning, setIsRunning] = useState(false);
  const [heatmapData] = useState(() => generateHeatmap('C'));

  const runBacktest = useCallback(() => {
    setIsRunning(true);
    setTimeout(() => {
      setResult(generateBTData(params));
      setIsRunning(false);
    }, 1200);
  }, [params]);

  const strategyColors: Record<string, string> = { A: '#00d4ff', B: '#f0b429', C: '#00ff88', D: '#a855f7' };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Parameter Controls */}
      <div className="card-cyber" style={{ padding: '14px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 14 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--cyan)', display: 'inline-block', marginRight: 6 }} />
          백테스팅 파라미터 설정
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, alignItems: 'flex-end' }}>
          {[
            { label: '시작 연도', type: 'select', id: 'startYear', options: [2015, 2016, 2017, 2018, 2019, 2020], value: params.startYear, onChange: (v: any) => setParams(p => ({ ...p, startYear: +v })) },
            { label: '종료 연도', type: 'select', id: 'endYear', options: [2022, 2023, 2024, 2025], value: params.endYear, onChange: (v: any) => setParams(p => ({ ...p, endYear: +v })) },
          ].map(ctrl => (
            <div key={ctrl.id} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              <label style={{ fontSize: 10, color: 'var(--text-secondary)', letterSpacing: 0.5 }}>{ctrl.label}</label>
              <select className="select-cyber" value={ctrl.value} onChange={e => ctrl.onChange(e.target.value)} style={{ width: 100 }}>
                {ctrl.options.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          ))}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 10, color: 'var(--text-secondary)', letterSpacing: 0.5 }}>신호 소스</label>
            <select className="select-cyber" style={{ width: 140 }} defaultValue="mu_sndk">
              <option value="sox">SOX 단독</option>
              <option value="mu_sndk">MU+SNDK 합산 ★</option>
              <option value="sox_mu">SOX+MU 복합</option>
            </select>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 10, color: 'var(--text-secondary)', letterSpacing: 0.5 }}>전략 선택</label>
            <select className="select-cyber" value={params.strategy} onChange={e => setParams(p => ({ ...p, strategy: e.target.value as any }))} style={{ width: 160 }}>
              <option value="A">전략A: 단순 모멘텀</option>
              <option value="B">전략B: 필터(±0.5%)</option>
              <option value="C">전략C: MA20 결합 ★</option>
              <option value="D">전략D: 리스크 관리</option>
            </select>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 10, color: 'var(--text-secondary)', letterSpacing: 0.5 }}>임계값 (%)</label>
            <input className="input-cyber" type="number" value={params.threshold} step={0.1} min={0} max={2} onChange={e => setParams(p => ({ ...p, threshold: +e.target.value }))} style={{ width: 80 }} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 10, color: 'var(--text-secondary)', letterSpacing: 0.5 }}>초기 투자금 (만원)</label>
            <input className="input-cyber" type="number" value={params.capital} step={100} min={100} onChange={e => setParams(p => ({ ...p, capital: +e.target.value }))} style={{ width: 100 }} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 10, color: 'var(--text-secondary)', letterSpacing: 0.5 }}>수수료 (%)</label>
            <input className="input-cyber" type="number" value={params.fee} step={0.001} min={0} max={0.5} onChange={e => setParams(p => ({ ...p, fee: +e.target.value }))} style={{ width: 80 }} />
          </div>
          <button className="btn-cyber-run" onClick={runBacktest} disabled={isRunning}>
            {isRunning ? '⏳ 시뮬레이션 중...' : '▶ 백테스팅 실행'}
          </button>
        </div>
        {isRunning && (
          <div style={{ marginTop: 12 }}>
            <div className="progress-cyber">
              <div className="progress-cyber-fill" style={{ width: '100%', animation: 'shimmer 1.5s infinite', backgroundSize: '200% 100%' }} />
            </div>
          </div>
        )}
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10 }}>
        {[
          { label: '총 수익률', value: `${result.totalReturn > 0 ? '+' : ''}${result.totalReturn}%`, color: result.totalReturn > 0 ? 'var(--green)' : 'var(--red)', sub: `vs KOSPI +23.1%` },
          { label: '연환산 수익률', value: `${result.annualReturn > 0 ? '+' : ''}${result.annualReturn}%`, color: result.annualReturn > 0 ? 'var(--green)' : 'var(--red)', sub: 'CAGR' },
          { label: '최대 낙폭', value: `${result.mdd}%`, color: 'var(--red)', sub: 'MDD' },
          { label: '샤프 지수', value: result.sharpe.toFixed(2), color: 'var(--gold)', sub: 'Sharpe Ratio' },
          { label: '승률', value: `${result.winRate}%`, color: 'var(--cyan)', sub: 'Win Rate' },
          { label: '총 거래수', value: result.trades.toLocaleString(), color: 'var(--purple)', sub: '매매 횟수' },
        ].map(s => (
          <div key={s.label} className="stat-card-cyber">
            <div style={{ fontSize: 9, color: 'var(--text-secondary)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>{s.label}</div>
            <div className="font-mono-data" style={{ fontSize: 18, fontWeight: 700, color: s.color, margin: '4px 0 2px' }}>{s.value}</div>
            <div style={{ fontSize: 9, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>포트폴리오 가치 추이</div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={result.portfolioData}>
              <CartesianGrid stroke="rgba(0,212,255,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} interval={Math.floor(result.portfolioData.length / 6)} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10, color: '#7ba3c4' }} />
              <Line type="monotone" dataKey="portfolio" name={`전략${params.strategy}`} stroke={strategyColors[params.strategy]} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="benchmark" name="Buy&Hold" stroke="#ff9f43" strokeWidth={1.5} strokeDasharray="4,4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>낙폭 (Drawdown)</div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={result.portfolioData}>
              <CartesianGrid stroke="rgba(255,71,87,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} interval={Math.floor(result.portfolioData.length / 6)} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={0} stroke="rgba(255,255,255,0.1)" />
              <Line type="monotone" dataKey="drawdown" name="낙폭" stroke="#ff4757" strokeWidth={1.5} dot={false} fill="rgba(255,71,87,0.1)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Strategy Compare */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>전략별 성과 비교</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={strategyCompareData}>
              <CartesianGrid stroke="rgba(0,212,255,0.04)" />
              <XAxis dataKey="name" tick={{ fill: '#7ba3c4', fontSize: 9 }} tickLine={false} />
              <YAxis tick={{ fill: '#3d6480', fontSize: 9 }} tickLine={false} />
              <Tooltip content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  const d = payload[0].payload;
                  return (
                    <div style={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, padding: '8px 12px', fontSize: 10 }}>
                      <div style={{ color: 'var(--text-secondary)', marginBottom: 4 }}>{label.replace('\n', ' ')}</div>
                      <div style={{ color: 'var(--green)' }}>총수익: +{d.totalReturn}%</div>
                      <div style={{ color: 'var(--cyan)' }}>연환산: +{d.annualReturn}%</div>
                      <div style={{ color: 'var(--red)' }}>MDD: {d.mdd}%</div>
                      <div style={{ color: 'var(--gold)' }}>샤프: {d.sharpe}</div>
                    </div>
                  );
                }
                return null;
              }} />
              <Bar dataKey="totalReturn" name="총수익률(%)">
                {strategyCompareData.map((_, i) => (
                  <Cell key={i} fill={['rgba(0,212,255,0.7)', 'rgba(240,180,41,0.7)', 'rgba(0,255,136,0.7)', 'rgba(168,85,247,0.7)'][i]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Monthly Heatmap */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>월별 수익률 히트맵</div>
          <div style={{ overflowX: 'auto' }}>
            <table className="heatmap-table">
              <thead>
                <tr>
                  <th style={{ textAlign: 'left', color: 'var(--text-dim)' }}>연도</th>
                  {['1','2','3','4','5','6','7','8','9','10','11','12'].map(m => <th key={m}>{m}월</th>)}
                </tr>
              </thead>
              <tbody>
                {heatmapData.map(row => (
                  <tr key={row.year}>
                    <td style={{ color: 'var(--text-secondary)', fontWeight: 700, paddingRight: 6 }}>{row.year}</td>
                    {row.months.map((cell, i) => {
                      const intensity = Math.min(Math.abs(cell.value) / 8, 1);
                      const bg = cell.value > 0
                        ? `rgba(0,255,136,${0.15 + intensity * 0.7})`
                        : `rgba(255,71,87,${0.15 + intensity * 0.7})`;
                      const tc = cell.value > 0 ? '#00ff88' : '#ff4757';
                      return (
                        <td key={i} style={{ background: bg, color: tc, borderRadius: 2, padding: '2px 3px', textAlign: 'center' }}>
                          {cell.value > 0 ? '+' : ''}{cell.value}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 5종목 ETF 배분 현황 */}
      <div className="card-cyber" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#ffd166', display: 'inline-block', marginRight: 6 }} />
          5종목 KODEX ETF 스위칭 전략 — 신호별 배분 현황
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
          {[
            { name: 'KODEX반도체', code: '091160', trigger: 'MU+SNDK > +2%', color: '#a8dadc', alloc: 50, ret: '+1.24%' },
            { name: 'KODEX증권', code: '102970', trigger: 'KOSPI > +0.5%', color: '#ffd166', alloc: 30, ret: '+1.08%' },
            { name: 'KODEX200', code: '069500', trigger: 'SOX > 0%', color: '#00d4ff', alloc: 20, ret: '+0.87%' },
            { name: 'KODEX인버스', code: '114800', trigger: 'SOX < 0%', color: '#ff4757', alloc: 0, ret: '-0.87%' },
            { name: 'KODEX2차전지', code: '305720', trigger: 'EV사이클+강세', color: '#a8e6cf', alloc: 0, ret: '+0.54%' },
          ].map(etf => (
            <div key={etf.code} style={{ background: `${etf.color}08`, border: `1px solid ${etf.color}30`, borderRadius: 8, padding: '12px 14px' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: etf.color, marginBottom: 4 }}>{etf.name}</div>
              <div style={{ fontSize: 9, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace', marginBottom: 8 }}>{etf.code}</div>
              <div style={{ fontSize: 9, color: 'var(--text-secondary)', marginBottom: 8, lineHeight: 1.4 }}>트리거: {etf.trigger}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 9, color: 'var(--text-dim)' }}>현재 배분</div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: etf.alloc > 0 ? etf.color : 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace' }}>{etf.alloc}%</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 9, color: 'var(--text-dim)' }}>전일 수익</div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: etf.ret.startsWith('+') ? 'var(--green)' : 'var(--red)', fontFamily: 'Share Tech Mono, monospace' }}>{etf.ret}</div>
                </div>
              </div>
              <div style={{ marginTop: 8, height: 3, background: 'var(--bg-panel)', borderRadius: 2 }}>
                <div style={{ height: '100%', width: `${etf.alloc}%`, background: etf.color, borderRadius: 2, transition: 'width 0.5s' }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Walk-Forward Results */}
      <div className="card-cyber" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--purple)', display: 'inline-block', marginRight: 6 }} />
          워크포워드 테스트 결과 — 인샘플/아웃오브샘플 검증
        </div>
        <table className="table-cyber">
          <thead>
            <tr>
              <th>구간</th>
              <th>기간</th>
              <th style={{ color: 'var(--cyan)' }}>인샘플 수익</th>
              <th style={{ color: 'var(--gold)' }}>아웃오브샘플 수익</th>
              <th style={{ color: 'var(--green)' }}>효율성</th>
              <th>평가</th>
            </tr>
          </thead>
          <tbody>
            {walkForwardData.map(row => (
              <tr key={row.period}>
                <td className="font-mono-data td-cyan">{row.period}</td>
                <td>{row.range}</td>
                <td className={`font-mono-data ${row.inSample > 0 ? 'td-buy' : 'td-sell'}`}>{row.inSample > 0 ? '+' : ''}{row.inSample}%</td>
                <td className={`font-mono-data ${row.outSample > 0 ? 'td-buy' : 'td-sell'}`}>{row.outSample > 0 ? '+' : ''}{row.outSample}%</td>
                <td className="font-mono-data td-gold">{row.efficiency ? `${row.efficiency}%` : '-'}</td>
                <td style={{ color: row.efficiency ? 'var(--green)' : 'var(--red)', fontSize: 10 }}>
                  {row.efficiency ? (row.efficiency > 85 ? '✓ 우수' : '✓ 양호') : '✗ 손실구간'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
