// ─── ETFMatrix.tsx ───
// KODEX 5종목 조건부 선택 매트릭스
// Design: Cyberpunk Terminal — 8 scenarios × 5 ETF decision table + ETF detail cards
// Based on: MU+WDC 시가금액 전략 | SOX 보조신호 | 조건부 ETF 선택 엔진 | OWL2/SWRL 추론

import { useState, useEffect } from 'react';

// ── 8개 시나리오 데이터 ──
const scenarios = [
  {
    id: 1,
    name: '① 반도체 급등',
    muWdc: '≥ +1%',
    sox: '강세',
    kospi: '미확인',
    vix: '정상',
    etf: 'KODEX 반도체',
    etfCode: 'semi',
    etfColor: '#00d4ff',
    logic: 'MU+WDC 복합 +2%↑ → 삼전·하닉 +2% 예상',
  },
  {
    id: 2,
    name: '② 미국장 폭락',
    muWdc: '≤ -2%',
    sox: '약세',
    kospi: '하락 예상',
    vix: '≥ 25',
    etf: 'KODEX 인버스',
    etfCode: 'inv',
    etfColor: '#ff4757',
    logic: '낙폭 -2% 이상 = 패닉셀 → KOSPI 하락 확정적',
  },
  {
    id: 3,
    name: '③ 국내 강보합',
    muWdc: '±0.5%',
    sox: '중립',
    kospi: '강보합',
    vix: '보통',
    etf: 'KODEX 증권',
    etfCode: 'sec',
    etfColor: '#ffd166',
    logic: '국내 증시 환황 → 거래대금↑ → 증권사 실적↑',
  },
  {
    id: 4,
    name: '④ EV 모멘텀',
    muWdc: '중립',
    sox: '중립',
    kospi: '보합',
    vix: '정상',
    etf: 'KODEX 2차전지',
    etfCode: 'bat',
    etfColor: '#a8e6cf',
    logic: 'EV/배터리 관련 뉴스·정책 → 배터리 섹터 독립 강세',
  },
  {
    id: 5,
    name: '⑤ 소폭 상승',
    muWdc: '+0~1%',
    sox: '소폭↑',
    kospi: '보합~소폭↑',
    vix: '정상',
    etf: 'KODEX 200',
    etfCode: 'k200',
    etfColor: '#00b4d8',
    logic: '방향은 상승이나 섹터 불확실 → 시장 평균 추종',
  },
  {
    id: 6,
    name: '⑥ 반도체 약세',
    muWdc: '-1~-2%',
    sox: '약세',
    kospi: '하락 예상',
    vix: '정상',
    etf: 'KODEX 인버스',
    etfCode: 'inv',
    etfColor: '#ff4757',
    logic: 'MU+WDC 동반 -1% 이하 → KOSPI 하락 헤지',
  },
  {
    id: 7,
    name: '⑦ 혼조 (MU↑WDC↓)',
    muWdc: '분리',
    sox: '혼조',
    kospi: '불확실',
    vix: '↑',
    etf: 'KODEX 200',
    etfCode: 'k200',
    etfColor: '#00b4d8',
    logic: '신호 불일치 시 안전자산 KODEX200 or HOLD',
  },
  {
    id: 8,
    name: '⑧ VIX 급등 (리스크오프)',
    muWdc: '관계없음',
    sox: '폭락',
    kospi: '패닉',
    vix: '≥ 30',
    etf: 'KODEX 인버스',
    etfCode: 'inv',
    etfColor: '#ff4757',
    logic: '공포지수 30↑ = 전면 리스크오프 → 인버스 최우선',
  },
];

// ── 5종목 ETF 카드 데이터 ──
const etfCards = [
  {
    code: 'semi',
    name: 'KODEX 반도체',
    ticker: '091160',
    type: '반도체 섹터 ETF',
    color: '#00d4ff',
    desc: '삼성전자·SK하이닉스 비중 합산 70%+. MU+WDC 강세 시 최고 수익. 반도체 사이클 일일 때 KODEX200 대비 2~3배 수익률.',
    triggers: ['MU ≥ +1%', 'WDC ≥ +1%', 'SOX 강세'],
    beta: 1.42,
    avgRet: '+1.87%',
    winRate: '63.2%',
  },
  {
    code: 'bat',
    name: 'KODEX 2차전지',
    ticker: '305720',
    type: '배터리 섹터 ETF',
    color: '#a8e6cf',
    desc: 'LG에너지솔루션·삼성SDI·SK이노베이션. 반도체와 독립 움직임. EV 수요 급등 or 국내 강보합이지만 반도체 약세 시 대안.',
    triggers: ['MU 중립', 'EV 수요↑', 'KOSPI 강보합'],
    beta: 1.28,
    avgRet: '+1.24%',
    winRate: '58.7%',
  },
  {
    code: 'sec',
    name: 'KODEX 증권',
    ticker: '102970',
    type: '증권업 섹터 ETF',
    color: '#ffd166',
    desc: '미래에셋·키움·한국투자 등 증권사. 국내 강보합 시 증시 거래대금↑ → 브로커리지 수익↑. MU 신호 무관, 순수 국내 지수 연동.',
    triggers: ['KOSPI 강보합', '거래대금↑'],
    beta: 1.35,
    avgRet: '+1.08%',
    winRate: '61.4%',
  },
  {
    code: 'k200',
    name: 'KODEX 200',
    ticker: '069500',
    type: 'KOSPI200 ETF',
    color: '#00b4d8',
    desc: '시장 전반 상승 추종. 미국장 소폭 상승이지만 섹터 방향 불확실 시 안전한 롱 선택. KOSPI 시장 베타 1.0 추종.',
    triggers: ['미국장 소폭↑', '섹터 불명확'],
    beta: 1.0,
    avgRet: '+0.87%',
    winRate: '57.3%',
  },
  {
    code: 'inv',
    name: 'KODEX 인버스',
    ticker: '114800',
    type: 'KOSPI200 역추종 ETF',
    color: '#ff4757',
    desc: '미국장 폭락 시 핵심 헤지 수단. MU+WDC 동반 -2% 이상 급락 시 KOSPI 하락 확실. 지체없이 매수. VIX ≥ 25 자동 트리거.',
    triggers: ['MU ≤ -2%', '미국장 폭락', 'VIX ≥ 25'],
    beta: -1.0,
    avgRet: '+1.43%',
    winRate: '66.1%',
  },
];

// ── 실시간 시뮬레이션 데이터 ──
function generateLiveSignal() {
  const scenarios_pool = [
    { scenario: 1, mu: +2.14, wdc: +1.87, sox: +1.42, kospi: +0.74, vix: 17.2, recommended: 'semi' },
    { scenario: 3, mu: +0.32, wdc: -0.18, sox: +0.21, kospi: +0.64, vix: 18.4, recommended: 'sec' },
    { scenario: 5, mu: +0.54, wdc: +0.41, sox: +0.38, kospi: +0.31, vix: 19.1, recommended: 'k200' },
    { scenario: 2, mu: -2.87, wdc: -3.12, sox: -2.94, kospi: -1.24, vix: 28.7, recommended: 'inv' },
    { scenario: 4, mu: +0.12, wdc: -0.08, sox: +0.14, kospi: +0.42, vix: 16.8, recommended: 'bat' },
  ];
  return scenarios_pool[Math.floor(Math.random() * scenarios_pool.length)];
}

export default function ETFMatrix() {
  const [activeScenario, setActiveScenario] = useState<number | null>(null);
  const [liveSignal, setLiveSignal] = useState(generateLiveSignal);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedEtf, setSelectedEtf] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveSignal(generateLiveSignal());
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const runAnalysis = () => {
    setIsAnalyzing(true);
    setActiveScenario(null);
    setSelectedEtf(null);
    setTimeout(() => {
      const sig = generateLiveSignal();
      setLiveSignal(sig);
      setActiveScenario(sig.scenario);
      setSelectedEtf(sig.recommended);
      setIsAnalyzing(false);
    }, 1400);
  };

  const getEtfColor = (code: string) => etfCards.find(e => e.code === code)?.color || '#00d4ff';
  const getEtfName = (code: string) => etfCards.find(e => e.code === code)?.name || '';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* ── 상단 실시간 신호 배너 ── */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(0,212,255,0.06) 0%, rgba(168,85,247,0.04) 50%, rgba(0,200,160,0.06) 100%)',
        border: '1px solid rgba(0,212,255,0.2)',
        borderRadius: 10,
        padding: '14px 20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 12,
      }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#00d4ff', marginBottom: 3, letterSpacing: 0.5 }}>
            MU+WDC 시가금액 전략 | SOX 보조신호 | 조건부 ETF 선택 엔진 | OWL2/SWRL 추론
          </div>
          <div style={{ fontSize: 10, color: 'var(--text-secondary)', fontFamily: 'Share Tech Mono, monospace' }}>
            마이크론(MU) + 웨스턴디지털(WDC) 합산 등락률 → 삼성전자·SK하이닉스 예측 → KODEX 5종목 조건부 선택
          </div>
        </div>
        <div style={{ display: 'flex', gap: 20, alignItems: 'center' }}>
          {[
            { label: 'MU', val: `${liveSignal.mu > 0 ? '+' : ''}${liveSignal.mu.toFixed(2)}%`, color: liveSignal.mu > 0 ? '#00ff88' : '#ff4757' },
            { label: 'WDC', val: `${liveSignal.wdc > 0 ? '+' : ''}${liveSignal.wdc.toFixed(2)}%`, color: liveSignal.wdc > 0 ? '#00ff88' : '#ff4757' },
            { label: 'SOX', val: `${liveSignal.sox > 0 ? '+' : ''}${liveSignal.sox.toFixed(2)}%`, color: liveSignal.sox > 0 ? '#00ff88' : '#ff4757' },
            { label: 'KOSPI', val: `${liveSignal.kospi > 0 ? '+' : ''}${liveSignal.kospi.toFixed(2)}%`, color: liveSignal.kospi > 0 ? '#ffd166' : '#ff4757' },
            { label: 'VIX', val: liveSignal.vix.toFixed(1), color: liveSignal.vix > 25 ? '#ff4757' : liveSignal.vix > 20 ? '#ffd166' : '#00ff88' },
          ].map(item => (
            <div key={item.label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 9, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace', marginBottom: 2 }}>{item.label}</div>
              <div style={{ fontSize: 14, fontWeight: 700, color: item.color, fontFamily: 'Share Tech Mono, monospace', transition: 'color 0.5s' }}>{item.val}</div>
            </div>
          ))}
          <button
            className="btn-cyber-run"
            onClick={runAnalysis}
            disabled={isAnalyzing}
            style={{ marginLeft: 8 }}
          >
            {isAnalyzing ? '⚡ 분석 중...' : '▶ 실시간 분석'}
          </button>
        </div>
      </div>

      {/* ── 추천 결과 배너 ── */}
      {selectedEtf && !isAnalyzing && (
        <div style={{
          background: `${getEtfColor(selectedEtf)}12`,
          border: `2px solid ${getEtfColor(selectedEtf)}`,
          borderRadius: 10,
          padding: '12px 20px',
          display: 'flex',
          alignItems: 'center',
          gap: 16,
          boxShadow: `0 0 24px ${getEtfColor(selectedEtf)}33`,
        }}>
          <div style={{ fontSize: 24 }}>🎯</div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 3 }}>OWL2/SWRL 추론 완료 — 시나리오 {activeScenario} 매칭</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: getEtfColor(selectedEtf) }}>
              추천 ETF: {getEtfName(selectedEtf)}
            </div>
          </div>
          <div style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-secondary)', fontFamily: 'Share Tech Mono, monospace' }}>
            MU: {liveSignal.mu > 0 ? '+' : ''}{liveSignal.mu.toFixed(2)}% | WDC: {liveSignal.wdc > 0 ? '+' : ''}{liveSignal.wdc.toFixed(2)}% | VIX: {liveSignal.vix.toFixed(1)}
          </div>
        </div>
      )}

      {/* ── 메인 매트릭스 테이블 ── */}
      <div className="card-cyber" style={{ padding: '16px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#00d4ff', display: 'inline-block' }} />
          KODEX 5종목 조건부 선택 매트릭스 — 핵심 전략
          {isAnalyzing && <span style={{ marginLeft: 8, color: '#00d4ff', animation: 'pulse-dot 0.8s infinite' }}>⚡ 추론 중...</span>}
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-bright)' }}>
                {['시나리오', '미국장 (MU+WDC)', 'SOX 보조', '국내 KOSPI', 'VIX / 환율', '▶ 선택 ETF', '근거 / 논리'].map(h => (
                  <th key={h} style={{
                    padding: '8px 12px',
                    textAlign: 'center',
                    color: 'var(--text-secondary)',
                    fontWeight: 700,
                    fontSize: 10,
                    letterSpacing: 0.5,
                    whiteSpace: 'nowrap',
                    background: 'rgba(0,212,255,0.04)',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {scenarios.map((sc) => {
                const isActive = activeScenario === sc.id;
                const isHovered = false;
                return (
                  <tr
                    key={sc.id}
                    onClick={() => setActiveScenario(activeScenario === sc.id ? null : sc.id)}
                    style={{
                      borderBottom: '1px solid rgba(0,212,255,0.06)',
                      background: isActive ? `${sc.etfColor}0d` : 'transparent',
                      cursor: 'pointer',
                      transition: 'background 0.2s',
                      boxShadow: isActive ? `inset 0 0 20px ${sc.etfColor}08` : 'none',
                    }}
                    onMouseEnter={e => { (e.currentTarget as HTMLTableRowElement).style.background = `${sc.etfColor}08`; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLTableRowElement).style.background = isActive ? `${sc.etfColor}0d` : 'transparent'; }}
                  >
                    {/* 시나리오명 */}
                    <td style={{ padding: '10px 12px', fontWeight: 700, color: isActive ? sc.etfColor : 'var(--text-primary)', whiteSpace: 'nowrap', fontSize: 11 }}>
                      {sc.name}
                    </td>
                    {/* MU+WDC */}
                    <td style={{ padding: '10px 12px', textAlign: 'center', fontFamily: 'Share Tech Mono, monospace', fontWeight: 700, color: sc.muWdc.includes('-') ? '#ff4757' : sc.muWdc.includes('+') ? '#00ff88' : 'var(--text-secondary)', fontSize: 12 }}>
                      {sc.muWdc}
                    </td>
                    {/* SOX */}
                    <td style={{ padding: '10px 12px', textAlign: 'center', color: sc.sox === '강세' ? '#00ff88' : sc.sox === '약세' || sc.sox === '폭락' ? '#ff4757' : 'var(--text-secondary)', fontSize: 11 }}>
                      {sc.sox}
                    </td>
                    {/* KOSPI */}
                    <td style={{ padding: '10px 12px', textAlign: 'center', color: sc.kospi.includes('강') ? '#ffd166' : sc.kospi.includes('하락') || sc.kospi.includes('패닉') ? '#ff4757' : 'var(--text-secondary)', fontSize: 11 }}>
                      {sc.kospi}
                    </td>
                    {/* VIX */}
                    <td style={{ padding: '10px 12px', textAlign: 'center', fontFamily: 'Share Tech Mono, monospace', color: sc.vix.includes('≥') ? '#ff4757' : 'var(--text-secondary)', fontSize: 11 }}>
                      {sc.vix}
                    </td>
                    {/* ETF 배지 */}
                    <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                      <span style={{
                        display: 'inline-block',
                        padding: '4px 12px',
                        borderRadius: 4,
                        background: `${sc.etfColor}22`,
                        border: `1px solid ${sc.etfColor}`,
                        color: sc.etfColor,
                        fontWeight: 700,
                        fontSize: 11,
                        whiteSpace: 'nowrap',
                        boxShadow: isActive ? `0 0 10px ${sc.etfColor}44` : 'none',
                      }}>
                        {sc.etf}
                      </span>
                    </td>
                    {/* 논리 */}
                    <td style={{ padding: '10px 12px', color: 'var(--text-secondary)', fontSize: 10, lineHeight: 1.5, maxWidth: 280 }}>
                      {sc.logic}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── 5종목 ETF 카드 ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
        {etfCards.map(etf => {
          const isSelected = selectedEtf === etf.code;
          return (
            <div
              key={etf.code}
              onClick={() => setSelectedEtf(selectedEtf === etf.code ? null : etf.code)}
              style={{
                background: isSelected ? `${etf.color}14` : `${etf.color}06`,
                border: `1px solid ${isSelected ? etf.color : etf.color + '40'}`,
                borderRadius: 10,
                padding: '14px 16px',
                cursor: 'pointer',
                transition: 'all 0.3s',
                boxShadow: isSelected ? `0 0 20px ${etf.color}33` : 'none',
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = etf.color; }}
              onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = isSelected ? etf.color : etf.color + '40'; }}
            >
              {/* ETF 이름 */}
              <div style={{ fontSize: 14, fontWeight: 700, color: etf.color, marginBottom: 2 }}>{etf.name}</div>
              <div style={{ fontSize: 9, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace', marginBottom: 6 }}>
                {etf.ticker} | {etf.type}
              </div>

              {/* 설명 */}
              <div style={{ fontSize: 10, color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 10, minHeight: 60 }}>
                {etf.desc}
              </div>

              {/* 트리거 배지 */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 10 }}>
                {etf.triggers.map(t => (
                  <span key={t} style={{
                    fontSize: 9,
                    padding: '2px 7px',
                    borderRadius: 3,
                    background: `${etf.color}18`,
                    border: `1px solid ${etf.color}55`,
                    color: etf.color,
                    fontFamily: 'Share Tech Mono, monospace',
                    whiteSpace: 'nowrap',
                  }}>{t}</span>
                ))}
              </div>

              {/* 지표 */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, borderTop: `1px solid ${etf.color}22`, paddingTop: 8 }}>
                {[
                  { label: '베타', val: etf.beta.toFixed(1), color: etf.color },
                  { label: '평균수익', val: etf.avgRet, color: etf.avgRet.startsWith('+') ? '#00ff88' : '#ff4757' },
                  { label: '승률', val: etf.winRate, color: '#ffd166' },
                ].map(m => (
                  <div key={m.label} style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 8, color: 'var(--text-dim)', marginBottom: 2 }}>{m.label}</div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: m.color, fontFamily: 'Share Tech Mono, monospace' }}>{m.val}</div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── 전략 요약 카드 ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        {[
          {
            title: '🇺🇸 미국장 신호 우선순위',
            color: '#00d4ff',
            items: [
              'MU+WDC 합산 > SOX 단독 (정밀도 +8%)',
              'MU ≥ +1% AND WDC ≥ +1% → 반도체 급등',
              'MU ≤ -2% → 즉시 인버스 (지체없이)',
              'MU↑ WDC↓ 분리 → 혼조 → KODEX200 대기',
            ],
          },
          {
            title: '🇰🇷 국내 지수 조건',
            color: '#ffd166',
            items: [
              'KOSPI200 > +0.5% → 강보합 → KODEX증권',
              '거래대금 증가 시 증권사 베타 1.35 활용',
              'KOSPI 하락 예상 시 인버스 헤지',
              '국내 독립 모멘텀 시 2차전지 대안',
            ],
          },
          {
            title: '⚡ VIX 리스크 관리',
            color: '#ff4757',
            items: [
              'VIX ≥ 30 → 전면 리스크오프 → 인버스',
              'VIX ≥ 25 → 포지션 50% 축소',
              'VIX 20~25 → 정상 but 모니터링',
              'VIX < 20 → 풀 포지션 가능',
            ],
          },
        ].map(card => (
          <div key={card.title} style={{ background: `${card.color}08`, border: `1px solid ${card.color}30`, borderRadius: 8, padding: '14px 16px' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: card.color, marginBottom: 10 }}>{card.title}</div>
            {card.items.map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 6, marginBottom: 5 }}>
                <span style={{ color: card.color, fontSize: 9, marginTop: 2, flexShrink: 0 }}>▸</span>
                <span style={{ fontSize: 10, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{item}</span>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* ── 일일 전략 체크리스트 ── */}
      <div className="card-cyber" style={{ padding: '14px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00c8a0', display: 'inline-block', marginRight: 6 }} />
          일일 전략 실행 체크리스트 — 미국 장 마감(ET 16:00) 이후 → 한국 장 개장(KST 09:00) 전
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {[
            { step: 'STEP 1', title: 'MU+WDC 확인', desc: '미국 장 마감 후 MU, WDC 종가 등락률 수집', time: 'ET 16:05', color: '#00d4ff' },
            { step: 'STEP 2', title: 'SOX+VIX 보조', desc: 'SOX 지수 및 VIX 공포지수 확인 (임계값 체크)', time: 'ET 16:10', color: '#a855f7' },
            { step: 'STEP 3', title: '시나리오 매칭', desc: '8개 시나리오 중 해당 조건 확인 → ETF 결정', time: 'ET 16:15', color: '#ffd166' },
            { step: 'STEP 4', title: 'KRX 매수 실행', desc: '한국 장 개장 9:00 시장가 매수 (전일 보유 청산 후)', time: 'KST 09:00', color: '#00c8a0' },
          ].map(s => (
            <div key={s.step} style={{ background: `${s.color}08`, border: `1px solid ${s.color}30`, borderRadius: 8, padding: '12px 14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <span style={{ fontSize: 9, fontWeight: 700, color: s.color, fontFamily: 'Share Tech Mono, monospace', letterSpacing: 1 }}>{s.step}</span>
                <span style={{ fontSize: 8, color: 'var(--text-dim)', fontFamily: 'Share Tech Mono, monospace' }}>{s.time}</span>
              </div>
              <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>{s.title}</div>
              <div style={{ fontSize: 10, color: 'var(--text-secondary)', lineHeight: 1.4 }}>{s.desc}</div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
