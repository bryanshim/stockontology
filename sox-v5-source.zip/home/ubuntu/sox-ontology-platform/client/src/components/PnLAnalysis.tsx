// ─── PnLAnalysis.tsx ───
// P&L Analysis — Today/7D KPI + 기간 필터 + 누적 P&L 차트 + 카테고리 탭
// Design: 이미지 참조 — 깔끔한 흰 배경 / 골드 언더라인 탭 / 녹색 수치

import { useState, useMemo } from 'react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ReferenceLine, Cell,
} from 'recharts';

// ── 타입 ──
type Category = 'Assets' | 'Perpetuals & Futures' | 'Spot' | 'Options';
type Period = '7D' | '30D' | '60D' | '90D' | '180D' | 'Custom';

// ── 데이터 생성 헬퍼 ──
function generatePnLData(days: number, seed: number, startVal: number) {
  const data: { date: string; pnl: number; cumPnl: number; daily: number }[] = [];
  let cum = startVal;
  const now = new Date('2026-05-12');
  for (let i = days; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const daily = (Math.sin((i + seed) * 0.7) * 180 + Math.cos((i + seed) * 0.3) * 120 + (Math.random() - 0.4) * 200);
    cum += daily;
    data.push({ date: dateStr, pnl: parseFloat(daily.toFixed(2)), cumPnl: parseFloat(cum.toFixed(2)), daily: parseFloat(daily.toFixed(2)) });
  }
  return data;
}

const ALL_DATA: Record<Category, ReturnType<typeof generatePnLData>> = {
  'Assets': generatePnLData(180, 1, -579),
  'Perpetuals & Futures': generatePnLData(180, 5, -200),
  'Spot': generatePnLData(180, 9, 0),
  'Options': generatePnLData(180, 13, 100),
};

const PERIOD_DAYS: Record<Period, number> = { '7D': 7, '30D': 30, '60D': 60, '90D': 90, '180D': 180, 'Custom': 60 };

const ACCOUNTS = ['UTA', 'Main Account', 'Sub-01', 'Sub-02'];

// ── 커스텀 툴팁 ──
function PnLTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const v = payload[0]?.value ?? 0;
  return (
    <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, padding: '10px 14px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: 12 }}>
      <div style={{ color: '#6b7280', marginBottom: 4 }}>{label}</div>
      <div style={{ color: v >= 0 ? '#16a34a' : '#dc2626', fontWeight: 700, fontSize: 15 }}>
        {v >= 0 ? '+' : ''}{v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </div>
    </div>
  );
}

export default function PnLAnalysis() {
  const [category, setCategory] = useState<Category>('Assets');
  const [period, setPeriod] = useState<Period>('60D');
  const [account, setAccount] = useState('UTA');
  const [showCustom, setShowCustom] = useState(false);
  const [customStart, setCustomStart] = useState('2026-03-01');
  const [customEnd, setCustomEnd] = useState('2026-05-12');

  const fullData = ALL_DATA[category];

  const chartData = useMemo(() => {
    const days = PERIOD_DAYS[period];
    return fullData.slice(-days - 1);
  }, [fullData, period]);

  const todayPnL = chartData[chartData.length - 1]?.daily ?? 0;
  const sevenDayPnL = chartData.slice(-7).reduce((s, d) => s + d.daily, 0);
  const cumPnL = chartData[chartData.length - 1]?.cumPnl ?? 0;
  const startCum = chartData[0]?.cumPnl ?? 0;

  // 일별 P&L 바 차트 데이터
  const dailyData = chartData.map(d => ({
    date: d.date.slice(5),
    value: d.daily,
  }));

  // 누적 P&L 라인 차트 데이터
  const cumData = chartData.map(d => ({
    date: d.date.slice(5),
    value: d.cumPnl,
  }));

  const categories: Category[] = ['Assets', 'Perpetuals & Futures', 'Spot', 'Options'];
  const periods: Period[] = ['7D', '30D', '60D', '90D', '180D', 'Custom'];

  return (
    <div style={{ background: '#ffffff', minHeight: '100vh', color: '#111827', fontFamily: "'Inter', 'Noto Sans KR', sans-serif" }}>
      <div style={{ maxWidth: 960, margin: '0 auto', padding: '32px 24px' }}>

        {/* ── 헤더 ── */}
        <h1 style={{ fontSize: 26, fontWeight: 700, color: '#111827', marginBottom: 24 }}>P&L Analysis</h1>

        {/* ── 카테고리 탭 ── */}
        <div style={{ display: 'flex', gap: 0, borderBottom: '1px solid #e5e7eb', marginBottom: 24 }}>
          {categories.map(cat => (
            <button key={cat} onClick={() => setCategory(cat)} style={{
              padding: '10px 20px', fontSize: 14, fontWeight: category === cat ? 600 : 400,
              color: category === cat ? '#111827' : '#6b7280',
              background: 'transparent', border: 'none', cursor: 'pointer',
              borderBottom: category === cat ? '2px solid #f59e0b' : '2px solid transparent',
              marginBottom: -1, transition: 'all 0.15s',
            }}>{cat}</button>
          ))}
        </div>

        {/* ── 계정 선택 ── */}
        <div style={{ marginBottom: 24 }}>
          <select value={account} onChange={e => setAccount(e.target.value)} style={{
            padding: '8px 32px 8px 12px', fontSize: 14, border: '1px solid #d1d5db',
            borderRadius: 6, background: '#fff', color: '#111827', cursor: 'pointer',
            appearance: 'none', backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%236b7280' d='M6 8L1 3h10z'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center',
          }}>
            {ACCOUNTS.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>

        {/* ── Today & 7D P&L KPI ── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, marginBottom: 28 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <span style={{ fontSize: 13, color: '#6b7280', fontWeight: 500 }}>Today's P&L (USD)</span>
              <span style={{ fontSize: 11, color: '#9ca3af' }}>↗</span>
            </div>
            <div style={{ fontSize: 36, fontWeight: 700, color: todayPnL >= 0 ? '#16a34a' : '#dc2626', letterSpacing: -0.5, marginBottom: 8 }}>
              {todayPnL >= 0 ? '+' : ''}{todayPnL.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af', lineHeight: 1.5 }}>
              Real-time updates from 6AM to 12AM (midnight) UTC.<br />
              Last updated at 2026-05-13 12:11:26 (UTC). ↻
            </div>
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <span style={{ fontSize: 13, color: '#6b7280', fontWeight: 500 }}>7 Day's P&L (USD)</span>
              <span style={{ fontSize: 11, color: '#9ca3af' }}>↗</span>
            </div>
            <div style={{ fontSize: 36, fontWeight: 700, color: sevenDayPnL >= 0 ? '#16a34a' : '#dc2626', letterSpacing: -0.5, marginBottom: 8 }}>
              {sevenDayPnL >= 0 ? '+' : ''}{sevenDayPnL.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af' }}>
              Data as of 2026-05-12 23:59:59 (UTC)
            </div>
          </div>
        </div>

        {/* ── 기간 필터 ── */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 8, flexWrap: 'wrap' }}>
          {periods.map(p => (
            <button key={p} onClick={() => { setPeriod(p); if (p === 'Custom') setShowCustom(true); else setShowCustom(false); }} style={{
              padding: '7px 18px', fontSize: 13, borderRadius: 6, cursor: 'pointer', fontWeight: period === p ? 600 : 400,
              background: period === p ? '#fef3c7' : 'transparent',
              border: `1px solid ${period === p ? '#f59e0b' : '#e5e7eb'}`,
              color: period === p ? '#92400e' : '#6b7280',
              transition: 'all 0.15s',
            }}>{p === '7D' ? 'Last 7 D' : p === '30D' ? 'Last 30 D' : p === '60D' ? 'Last 60 D' : p === '90D' ? 'Last 90 D' : p === '180D' ? 'Last 180 D' : 'Custom Time Frame'}</button>
          ))}
        </div>

        {/* 커스텀 날짜 */}
        {showCustom && (
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 12, padding: '12px 16px', background: '#f9fafb', borderRadius: 8, border: '1px solid #e5e7eb' }}>
            <span style={{ fontSize: 12, color: '#6b7280' }}>시작일</span>
            <input type="date" value={customStart} onChange={e => setCustomStart(e.target.value)} style={{ padding: '5px 10px', fontSize: 12, border: '1px solid #d1d5db', borderRadius: 4, color: '#111827' }} />
            <span style={{ fontSize: 12, color: '#6b7280' }}>~</span>
            <input type="date" value={customEnd} onChange={e => setCustomEnd(e.target.value)} style={{ padding: '5px 10px', fontSize: 12, border: '1px solid #d1d5db', borderRadius: 4, color: '#111827' }} />
          </div>
        )}

        <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 24 }}>
          Data as of 2026-05-12 23:59:59 (UTC)
        </div>

        {/* ── 누적 P&L 차트 ── */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 4 }}>
            <h2 style={{ fontSize: 16, fontWeight: 600, color: '#111827' }}>Cumulative P&L (USD)</h2>
            <span style={{ fontSize: 11, color: '#9ca3af' }}>↗</span>
          </div>
          <div style={{ fontSize: 28, fontWeight: 700, color: cumPnL >= 0 ? '#16a34a' : '#dc2626', marginBottom: 20, letterSpacing: -0.5 }}>
            {cumPnL >= 0 ? '+' : ''}{cumPnL.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={cumData} margin={{ top: 8, right: 16, bottom: 0, left: 16 }}>
              <defs>
                <linearGradient id="pnlGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="date" tick={{ fill: '#9ca3af', fontSize: 10 }} axisLine={false} tickLine={false}
                interval={Math.floor(cumData.length / 8)} />
              <YAxis tick={{ fill: '#9ca3af', fontSize: 10 }} axisLine={false} tickLine={false}
                tickFormatter={v => v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v.toFixed(0)} />
              <Tooltip content={<PnLTooltip />} />
              <ReferenceLine y={0} stroke="#e5e7eb" strokeWidth={1} />
              <Area type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} fill="url(#pnlGrad)" dot={false} activeDot={{ r: 4, fill: '#3b82f6' }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* ── 일별 P&L 바 차트 ── */}
        <div style={{ marginBottom: 32 }}>
          <h2 style={{ fontSize: 16, fontWeight: 600, color: '#111827', marginBottom: 16 }}>Daily P&L (USD)</h2>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={dailyData} margin={{ top: 4, right: 16, bottom: 0, left: 16 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="date" tick={{ fill: '#9ca3af', fontSize: 10 }} axisLine={false} tickLine={false}
                interval={Math.floor(dailyData.length / 8)} />
              <YAxis tick={{ fill: '#9ca3af', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<PnLTooltip />} />
              <ReferenceLine y={0} stroke="#e5e7eb" />
              <Bar dataKey="value" radius={[2, 2, 0, 0]}>
                {dailyData.map((d, i) => <Cell key={i} fill={d.value >= 0 ? '#16a34a' : '#dc2626'} fillOpacity={0.8} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* ── 기간별 통계 요약 ── */}
        <div style={{ background: '#f9fafb', borderRadius: 12, padding: '20px 24px', border: '1px solid #e5e7eb' }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, color: '#374151', marginBottom: 16 }}>기간 성과 요약 — {period === 'Custom' ? `${customStart} ~ ${customEnd}` : `Last ${period}`}</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {[
              { label: '누적 P&L', val: `${cumPnL >= 0 ? '+' : ''}$${cumPnL.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, color: cumPnL >= 0 ? '#16a34a' : '#dc2626' },
              { label: '평균 일별 P&L', val: `${(chartData.reduce((s, d) => s + d.daily, 0) / chartData.length) >= 0 ? '+' : ''}$${(chartData.reduce((s, d) => s + d.daily, 0) / chartData.length).toFixed(2)}`, color: '#3b82f6' },
              { label: '최대 일별 수익', val: `+$${Math.max(...chartData.map(d => d.daily)).toFixed(2)}`, color: '#16a34a' },
              { label: '최대 일별 손실', val: `$${Math.min(...chartData.map(d => d.daily)).toFixed(2)}`, color: '#dc2626' },
              { label: '수익 일수', val: `${chartData.filter(d => d.daily > 0).length}일`, color: '#16a34a' },
              { label: '손실 일수', val: `${chartData.filter(d => d.daily < 0).length}일`, color: '#dc2626' },
              { label: '승률', val: `${((chartData.filter(d => d.daily > 0).length / chartData.length) * 100).toFixed(1)}%`, color: '#f59e0b' },
              { label: '변동성 (σ)', val: `$${Math.sqrt(chartData.reduce((s, d) => s + Math.pow(d.daily - chartData.reduce((a, b) => a + b.daily, 0) / chartData.length, 2), 0) / chartData.length).toFixed(2)}`, color: '#8b5cf6' },
            ].map(item => (
              <div key={item.label} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 4 }}>{item.label}</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: item.color }}>{item.val}</div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
