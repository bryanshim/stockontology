// ─── Consulting.tsx ───
// 전략/IT 컨설팅 탭 — 6단계 프레임워크 + 아키텍처 + 상관관계 분석
// Design: Cyberpunk Terminal — step flow + architecture layers + correlation matrix

import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, Tooltip } from 'recharts';
import { correlationMatrix } from '@/lib/ontologyData';

const consultingSteps = [
  { num: '01', title: '현황 진단', sub: 'AS-IS 분석\n데이터 수집', color: '#00d4ff', icon: '🔍' },
  { num: '02', title: '전략 컨설팅', sub: '방향성 수립\n목표 정의', color: '#f0b429', icon: '🎯' },
  { num: '03', title: 'IT 컨설팅', sub: '온톨로지 설계\n시스템 아키텍처', color: '#a855f7', icon: '⚙️' },
  { num: '04', title: '데이터 분석', sub: '백테스팅\n상관관계 분석', color: '#00ff88', icon: '📊' },
  { num: '05', title: '솔루션 제공', sub: '플랫폼 구축\n자동화 시스템', color: '#00c8a0', icon: '🚀' },
  { num: '06', title: 'ROI 분석', sub: '성과 검증\n지속 최적화', color: '#ff9f43', icon: '💰' },
];

const archLayers = [
  { label: '데이터 수집층', desc: 'Bloomberg/Yahoo Finance API → Raw Data Lake (S3)', color: '#00d4ff', icon: '📡' },
  { label: '온톨로지 엔진', desc: 'OWL2/SWRL 온톨로지 → Apache Jena 추론기', color: '#f0b429', icon: '🧠' },
  { label: '신호 생성층', desc: 'SPARQL 쿼리 → 실시간 매매 시그널 생성', color: '#00ff88', icon: '⚡' },
  { label: '백테스팅 엔진', desc: 'Python Backtrader / Zipline 시뮬레이션', color: '#a855f7', icon: '🔁' },
  { label: '리스크 관리', desc: 'VaR/CVaR 계산 → 자동 스탑로스 실행', color: '#ff4757', icon: '🛡️' },
  { label: '대시보드/API', desc: 'React 웹앱 + REST API → 실시간 모니터링', color: '#00c8a0', icon: '🖥️' },
];

const radarData = [
  { subject: '전략 정합성', A: 85, B: 92 },
  { subject: '데이터 품질', A: 70, B: 95 },
  { subject: '리스크 관리', A: 40, B: 90 },
  { subject: '자동화 수준', A: 20, B: 88 },
  { subject: '검증 체계', A: 30, B: 92 },
  { subject: '확장성', A: 50, B: 85 },
];

function getCorrColor(v: number): string {
  if (v === 1.0) return 'rgba(0,212,255,0.3)';
  if (v >= 0.7) return 'rgba(0,255,136,0.5)';
  if (v >= 0.4) return 'rgba(0,255,136,0.25)';
  if (v >= 0) return 'rgba(0,212,255,0.15)';
  if (v >= -0.4) return 'rgba(255,71,87,0.2)';
  if (v >= -0.7) return 'rgba(255,71,87,0.4)';
  return 'rgba(255,71,87,0.6)';
}

function getCorrTextColor(v: number): string {
  if (v === 1.0) return '#00d4ff';
  if (v >= 0.7) return '#00ff88';
  if (v >= 0.4) return '#7bff99';
  if (v >= 0) return '#7ba3c4';
  if (v >= -0.4) return '#ff8899';
  return '#ff4757';
}

export default function Consulting() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Step Flow */}
      <div className="card-cyber" style={{ padding: '16px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 16 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--cyan)', display: 'inline-block', marginRight: 6 }} />
          6단계 컨설팅 프레임워크
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 0, flexWrap: 'wrap', justifyContent: 'center' }}>
          {consultingSteps.map((step, idx) => (
            <div key={step.num} style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>
              <div
                style={{
                  background: `${step.color}10`,
                  border: `1px solid ${step.color}44`,
                  borderRadius: 8,
                  padding: '12px 16px',
                  minWidth: 110,
                  textAlign: 'center',
                  transition: 'all 0.3s',
                  cursor: 'default',
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLDivElement).style.borderColor = step.color;
                  (e.currentTarget as HTMLDivElement).style.boxShadow = `0 0 12px ${step.color}44`;
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLDivElement).style.borderColor = `${step.color}44`;
                  (e.currentTarget as HTMLDivElement).style.boxShadow = 'none';
                }}
              >
                <div style={{ fontSize: 18, marginBottom: 4 }}>{step.icon}</div>
                <div className="font-orbitron" style={{ fontSize: 16, fontWeight: 900, color: step.color, lineHeight: 1, marginBottom: 4 }}>{step.num}</div>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 2 }}>{step.title}</div>
                <div style={{ fontSize: 9, color: 'var(--text-dim)', lineHeight: 1.4, whiteSpace: 'pre-line' }}>{step.sub}</div>
              </div>
              {idx < consultingSteps.length - 1 && (
                <div style={{ padding: '0 6px', color: 'var(--text-dim)', fontSize: 14, flexShrink: 0 }}>→</div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Problem & Solution */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>전략 컨설팅 — 문제 정의 & 솔루션</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div style={{ background: 'var(--bg-panel)', border: '1px solid var(--border-color)', borderRadius: 6, padding: 12 }}>
              <div style={{ color: 'var(--red)', fontWeight: 700, fontSize: 10, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>문제 식별</div>
              {['감에 의존한 투자 의사결정', '미국장-한국장 연관성 미활용', '리스크 관리 체계 부재', '반도체 사이클 대응 전략 없음', '백테스팅 검증 부재'].map((item, i) => (
                <div key={i} style={{ color: 'var(--text-secondary)', fontSize: 11, lineHeight: 2, display: 'flex', gap: 6 }}>
                  <span style={{ color: 'var(--red)' }}>⚠</span> {item}
                </div>
              ))}
            </div>
            <div style={{ background: 'var(--bg-panel)', border: '1px solid var(--border-color)', borderRadius: 6, padding: 12 }}>
              <div style={{ color: 'var(--green)', fontWeight: 700, fontSize: 10, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>솔루션 방향</div>
              {['온톨로지 기반 자동 추론 시스템', 'SOX→KOSPI 시그널 체계화', '정량적 리스크 관리 룰 도입', '반도체 사이클 온톨로지 모델링', '백테스팅 검증된 규칙 기반 매매'].map((item, i) => (
                <div key={i} style={{ color: 'var(--text-secondary)', fontSize: 11, lineHeight: 2, display: 'flex', gap: 6 }}>
                  <span style={{ color: 'var(--green)' }}>✅</span> {item}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* IT Architecture */}
        <div className="card-cyber card-cyber-gold" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>IT 컨설팅 — 시스템 아키텍처</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {archLayers.map((layer, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'var(--bg-panel)', padding: '8px 10px', borderRadius: 4, border: `1px solid ${layer.color}22`, transition: 'border-color 0.2s' }}>
                <span style={{ fontSize: 14, flexShrink: 0 }}>{layer.icon}</span>
                <span style={{ color: layer.color, minWidth: 100, fontSize: 11, fontWeight: 700, fontFamily: 'Share Tech Mono, monospace' }}>{layer.label}</span>
                <span style={{ color: 'var(--text-secondary)', fontSize: 10, lineHeight: 1.4 }}>{layer.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* AS-IS vs TO-BE Radar */}
        <div className="card-cyber" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>AS-IS vs TO-BE 역량 비교</div>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="rgba(0,212,255,0.1)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#7ba3c4', fontSize: 10 }} />
              <Radar name="AS-IS" dataKey="A" stroke="#ff4757" fill="#ff4757" fillOpacity={0.2} />
              <Radar name="TO-BE" dataKey="B" stroke="#00ff88" fill="#00ff88" fillOpacity={0.2} />
              <Tooltip
                contentStyle={{ background: 'rgba(4,20,38,0.95)', border: '1px solid var(--border-bright)', borderRadius: 6, fontSize: 11 }}
                labelStyle={{ color: 'var(--text-secondary)' }}
              />
            </RadarChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 16, marginTop: 4 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: '#ff4757' }}>
              <span style={{ width: 10, height: 2, background: '#ff4757', display: 'inline-block' }} /> AS-IS 현황
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: '#00ff88' }}>
              <span style={{ width: 10, height: 2, background: '#00ff88', display: 'inline-block' }} /> TO-BE 목표
            </div>
          </div>
        </div>

        {/* Correlation Matrix */}
        <div className="card-cyber card-cyber-purple" style={{ padding: '14px 16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 10 }}>데이터 분석 — 상관관계 매트릭스</div>
          <div style={{ overflowX: 'auto' }}>
            <table className="table-cyber" style={{ textAlign: 'center' }}>
              <thead>
                <tr>
                  <th style={{ textAlign: 'left' }}>지표</th>
                  {correlationMatrix.labels.map(l => <th key={l} style={{ fontSize: 9 }}>{l}</th>)}
                </tr>
              </thead>
              <tbody>
                {correlationMatrix.data.map((row, i) => (
                  <tr key={i}>
                    <td style={{ textAlign: 'left', color: 'var(--text-secondary)', fontWeight: 700, fontSize: 10 }}>{correlationMatrix.labels[i]}</td>
                    {row.map((v, j) => (
                      <td key={j} style={{ background: getCorrColor(v), color: getCorrTextColor(v), fontFamily: 'Share Tech Mono, monospace', fontSize: 10, fontWeight: v === 1 ? 700 : 400 }}>
                        {v.toFixed(2)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{ marginTop: 10, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {[
              { color: 'rgba(0,255,136,0.5)', label: '강한 양의 상관 (≥0.7)' },
              { color: 'rgba(0,212,255,0.15)', label: '약한 양의 상관' },
              { color: 'rgba(255,71,87,0.4)', label: '강한 음의 상관 (≤-0.7)' },
            ].map(item => (
              <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 9, color: 'var(--text-secondary)' }}>
                <span style={{ width: 10, height: 10, background: item.color, display: 'inline-block', borderRadius: 2 }} />
                {item.label}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Implementation Roadmap */}
      <div className="card-cyber card-cyber-green" style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, color: 'var(--text-secondary)', textTransform: 'uppercase', marginBottom: 12 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)', display: 'inline-block', marginRight: 6 }} />
          구현 로드맵 — 3개월 실행 계획
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
          {[
            {
              phase: 'PHASE 1', period: '1개월차', color: '#00d4ff', title: '기반 구축',
              items: ['온톨로지 스키마 설계 (OWL2)', 'SOX/KODEX 데이터 파이프라인', '기초 SWRL 추론 규칙 구현', '백테스팅 엔진 개발'],
            },
            {
              phase: 'PHASE 2', period: '2개월차', color: '#f0b429', title: '고도화',
              items: ['MA20 크로스 신호 통합', 'VIX 연동 리스크 관리', '워크포워드 검증 자동화', '실시간 신호 생성 시스템'],
            },
            {
              phase: 'PHASE 3', period: '3개월차', color: '#00ff88', title: '배포 & 최적화',
              items: ['웹 대시보드 완성', '자동 매매 API 연동', '성과 모니터링 시스템', 'ROI 검증 및 최적화'],
            },
          ].map(phase => (
            <div key={phase.phase} style={{ background: `${phase.color}08`, border: `1px solid ${phase.color}33`, borderRadius: 8, padding: 14 }}>
              <div className="font-orbitron" style={{ fontSize: 10, fontWeight: 700, color: phase.color, letterSpacing: 2, marginBottom: 2 }}>{phase.phase}</div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>{phase.period}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 10 }}>{phase.title}</div>
              {phase.items.map((item, i) => (
                <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 4, fontSize: 11, color: 'var(--text-secondary)' }}>
                  <span style={{ color: phase.color, flexShrink: 0 }}>▸</span> {item}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
