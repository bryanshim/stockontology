// ─── TradingFlow.tsx ───
// TradingFlow 대시보드 — 포지션 테이블 + 전략 성과 + 멀티 차트 그리드
// Design: 다크 터미널 — 이미지2/3 참조 (TradingView 스타일 다크 대시보드)

import { useState, useMemo } from 'react';
import {
  LineChart, Line, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts';

// ── 타입 ──
type Side = 'LONG' | 'SHORT';
type Symbol = 'BTCUSDT' | 'ETHUSDT' | 'SOLUSDT' | 'XRPUSDT';
type TF = '30M' | '1H' | '4H' | '1D';

interface Position {
  symbol: Symbol;
  side: Side;
  size: number;
  entryPrice: number;
  markPrice: number;
  pnl: number;
  pnlPct: number;
  liqPrice: number;
  leverage: number;
  margin: number;
  tp: number;
}

// ── 샘플 포지션 ──
const POSITIONS: Position[] = [
  { symbol: 'BTCUSDT', side: 'LONG', size: 45.9, entryPrice: 782.68, markPrice: 2371.7, pnl: 2.49, pnlPct: 2.645, liqPrice: 0.0031, leverage: 10, margin: 2813.51, tp: 0 },
  { symbol: 'XRPUSDT', side: 'LONG', size: 14060.9, entryPrice: 1.4037, markPrice: 1.4749, pnl: -80.46, pnlPct: -3.881, liqPrice: 0.0031, leverage: 10, margin: 1.2494, tp: 0 },
  { symbol: 'SOLUSDT', side: 'SHORT', size: 45.9, entryPrice: 95.4279, markPrice: 96.3, pnl: -1.371, pnlPct: -3.375, liqPrice: 243.6389, leverage: 10, margin: 189.7449, tp: 90.5508 },
  { symbol: 'BTCUSDT', side: 'SHORT', size: 0.004, entryPrice: 68975.1, markPrice: 82385.0, pnl: -20.439, pnlPct: -20.439, liqPrice: 177121.5547, leverage: 10, margin: 76926.3, tp: 0 },
];

// ── 전략 성과 지표 ──
const STRATEGY_METRICS = [
  { label: '총 수익률', val: '+2.708%', color: '#00ff88' },
  { label: '트레이드 수', val: '12', color: '#00d4ff' },
  { label: '승률', val: '41.41%', color: '#ffd166' },
  { label: '실현 P&L', val: '+96.82 USDT', color: '#00ff88' },
  { label: '미실현 P&L', val: '+0.335%', color: '#00ff88' },
  { label: '샤프 비율', val: '22.6', color: '#a855f7' },
];

// ── 백테스트 결과 ──
const BACKTEST_RESULTS = [
  { name: 'backtest-v4', trades: 344, winRate: 25.9, pnl: -49.77, maxDD: -0.51, sharpe: 0.33, wins: 33, loss: -1.26, status: 'active' },
  { name: 'wwy_g5u74_v4_00', trades: 2, winRate: 100, pnl: 949.99, maxDD: 0, sharpe: 0, wins: 0, loss: 0, status: 'live' },
  { name: 'wwy_g5u74_v4_01', trades: 0, winRate: 0, pnl: 0, maxDD: 0, sharpe: 0, wins: 0, loss: 0, status: 'idle' },
  { name: 'intégral', trades: 126, winRate: 13.5, pnl: 0, maxDD: 0, sharpe: 0.96, wins: 37, loss: 0, status: 'active' },
  { name: 'wwy_g5u69_52x4_00', trades: 0, winRate: 0.24, pnl: 0, maxDD: 0, sharpe: 0, wins: 0, loss: 0, status: 'idle' },
  { name: 'wwy_g5u69_52x4_01', trades: 0, winRate: 0, pnl: 0, maxDD: 0, sharpe: 0, wins: 0, loss: 0, status: 'idle' },
  { name: 'wwy_g5u69_52x4_02', trades: 0, winRate: 0, pnl: 0, maxDD: 0, sharpe: 0, wins: 0, loss: 0, status: 'idle' },
];

// ── 차트 데이터 생성 ──
function genCandleData(base: number, vol: number, count: number, seed: number) {
  const data: { t: string; v: number; open: number; high: number; low: number; close: number }[] = [];
  let price = base;
  for (let i = 0; i < count; i++) {
    const change = (Math.sin(i * 0.4 + seed) * vol + (Math.random() - 0.5) * vol * 0.5);
    const open = price;
    price = Math.max(price + change, base * 0.3);
    const high = Math.max(open, price) * (1 + Math.random() * 0.005);
    const low = Math.min(open, price) * (1 - Math.random() * 0.005);
    data.push({ t: `${String(i % 24).padStart(2, '0')}:00`, v: parseFloat(price.toFixed(2)), open, high, low, close: price });
  }
  return data;
}

const CHART_DATA: Record<Symbol, Record<TF, ReturnType<typeof genCandleData>>> = {
  BTCUSDT: { '30M': genCandleData(102300, 800, 48, 1), '1H': genCandleData(102300, 1200, 24, 2), '4H': genCandleData(102300, 2000, 12, 3), '1D': genCandleData(102300, 3000, 7, 4) },
  ETHUSDT: { '30M': genCandleData(2377, 30, 48, 5), '1H': genCandleData(2377, 50, 24, 6), '4H': genCandleData(2377, 80, 12, 7), '1D': genCandleData(2377, 120, 7, 8) },
  SOLUSDT: { '30M': genCandleData(96.3, 2, 48, 9), '1H': genCandleData(96.3, 3, 24, 10), '4H': genCandleData(96.3, 5, 12, 11), '1D': genCandleData(96.3, 8, 7, 12) },
  XRPUSDT: { '30M': genCandleData(1.4749, 0.02, 48, 13), '1H': genCandleData(1.4749, 0.03, 24, 14), '4H': genCandleData(1.4749, 0.05, 12, 15), '1D': genCandleData(1.4749, 0.08, 7, 16) },
};

const SYMBOL_PRICES: Record<Symbol, number> = { BTCUSDT: 102300, ETHUSDT: 2377.98, SOLUSDT: 96.37, XRPUSDT: 1.4749 };
const SYMBOL_COLORS: Record<Symbol, string> = { BTCUSDT: '#f7931a', ETHUSDT: '#627eea', SOLUSDT: '#9945ff', XRPUSDT: '#00aae4' };

const TFS: TF[] = ['30M', '1H', '4H', '1D'];
const SYMBOLS: Symbol[] = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT'];

// ── 미니 차트 ──
function MiniChart({ symbol, tf }: { symbol: Symbol; tf: TF }) {
  const data = CHART_DATA[symbol][tf];
  const last = data[data.length - 1].v;
  const first = data[0].v;
  const isUp = last >= first;
  const color = isUp ? '#00ff88' : '#ff4757';
  const winRate = 52 + Math.floor(Math.random() * 25);
  const longPct = 35 + Math.floor(Math.random() * 30);

  return (
    <div style={{ background: '#0d1117', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 6, padding: '8px', position: 'relative', overflow: 'hidden' }}>
      {/* 헤더 */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: SYMBOL_COLORS[symbol], display: 'inline-block' }} />
          <span style={{ fontSize: 9, fontWeight: 700, color: '#e5e7eb', fontFamily: 'Share Tech Mono, monospace' }}>{symbol} Perpetual Contract</span>
        </div>
        <span style={{ fontSize: 8, color: '#6b7280' }}>{tf}</span>
      </div>
      {/* 가격 */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: color, fontFamily: 'Share Tech Mono, monospace' }}>
          {last.toLocaleString('en-US', { minimumFractionDigits: symbol === 'XRPUSDT' ? 4 : 2, maximumFractionDigits: symbol === 'XRPUSDT' ? 4 : 2 })}
        </span>
        <span style={{ fontSize: 9, color: color }}>{isUp ? '+' : ''}{(((last - first) / first) * 100).toFixed(2)}%</span>
      </div>
      {/* 차트 */}
      <ResponsiveContainer width="100%" height={60}>
        <AreaChart data={data} margin={{ top: 2, right: 0, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id={`grad-${symbol}-${tf}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.2} />
              <stop offset="95%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area type="monotone" dataKey="v" stroke={color} strokeWidth={1.5} fill={`url(#grad-${symbol}-${tf})`} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
      {/* 하단 지표 */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
        <span style={{ fontSize: 8, color: '#6b7280' }}>승률 <span style={{ color: winRate > 60 ? '#00ff88' : '#ffd166' }}>{winRate}%</span></span>
        <span style={{ fontSize: 8, color: '#6b7280' }}>LONG <span style={{ color: '#00d4ff' }}>{longPct}%</span></span>
        <span style={{ fontSize: 8, color: '#6b7280' }}>SHORT <span style={{ color: '#ff4757' }}>{100 - longPct}%</span></span>
      </div>
    </div>
  );
}

export default function TradingFlow() {
  const [activeSymbol, setActiveSymbol] = useState<Symbol>('BTCUSDT');
  const [activeTF, setActiveTF] = useState<TF>('1H');
  const [showAllPositions, setShowAllPositions] = useState(false);
  const [tab, setTab] = useState<'positions' | 'backtest' | 'signals'>('positions');

  const mainData = CHART_DATA[activeSymbol][activeTF];
  const totalPnl = POSITIONS.reduce((s, p) => s + p.pnl, 0);
  const totalMargin = POSITIONS.reduce((s, p) => s + p.margin, 0);

  return (
    <div style={{ background: '#0a0e1a', minHeight: '100vh', color: '#e5e7eb', fontFamily: "'Share Tech Mono', 'Noto Sans KR', monospace", fontSize: 12 }}>

      {/* ── 상단 계정 요약 ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 1, background: '#161b2e', borderBottom: '1px solid rgba(255,255,255,0.06)', padding: '10px 16px' }}>
        {[
          { label: 'ACCOUNT', val: '6,871.67 USDT', sub: '-135.82 USDT', color: '#ff4757' },
          { label: 'EQUITY', val: '4,823.74 USDT', sub: '', color: '#e5e7eb' },
          { label: 'UNREALIZED P&L', val: '+96.82 USDT', sub: '', color: '#00ff88' },
          { label: '총 수익률', val: '+2.708%', sub: '전략 기준', color: '#00ff88' },
          { label: '트레이드', val: '12', sub: '오늘', color: '#00d4ff' },
          { label: '샤프 비율', val: '22.6', sub: '연환산', color: '#a855f7' },
        ].map(item => (
          <div key={item.label} style={{ padding: '4px 8px' }}>
            <div style={{ fontSize: 8, color: '#6b7280', letterSpacing: 0.5, marginBottom: 3 }}>{item.label}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: item.color }}>{item.val}</div>
            {item.sub && <div style={{ fontSize: 9, color: '#6b7280' }}>{item.sub}</div>}
          </div>
        ))}
      </div>

      <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>

        {/* ── 메인 차트 + 심볼 선택 ── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 200px', gap: 12 }}>
          <div style={{ background: '#0d1117', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 8, padding: '12px' }}>
            {/* 심볼 + TF 선택 */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <div style={{ display: 'flex', gap: 4 }}>
                {SYMBOLS.map(s => (
                  <button key={s} onClick={() => setActiveSymbol(s)} style={{
                    padding: '4px 10px', fontSize: 10, borderRadius: 4, cursor: 'pointer',
                    background: activeSymbol === s ? `${SYMBOL_COLORS[s]}22` : 'transparent',
                    border: `1px solid ${activeSymbol === s ? SYMBOL_COLORS[s] : 'rgba(255,255,255,0.1)'}`,
                    color: activeSymbol === s ? SYMBOL_COLORS[s] : '#6b7280', fontWeight: activeSymbol === s ? 700 : 400,
                  }}>{s.replace('USDT', '')}</button>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 4 }}>
                {TFS.map(tf => (
                  <button key={tf} onClick={() => setActiveTF(tf)} style={{
                    padding: '3px 8px', fontSize: 9, borderRadius: 3, cursor: 'pointer',
                    background: activeTF === tf ? 'rgba(0,212,255,0.15)' : 'transparent',
                    border: `1px solid ${activeTF === tf ? '#00d4ff' : 'rgba(255,255,255,0.08)'}`,
                    color: activeTF === tf ? '#00d4ff' : '#6b7280',
                  }}>{tf}</button>
                ))}
              </div>
            </div>
            {/* 가격 */}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 8 }}>
              <span style={{ fontSize: 22, fontWeight: 700, color: '#e5e7eb' }}>
                {SYMBOL_PRICES[activeSymbol].toLocaleString('en-US', { minimumFractionDigits: activeSymbol === 'XRPUSDT' ? 4 : 2 })}
              </span>
              <span style={{ fontSize: 11, color: '#00ff88' }}>+1.24%</span>
            </div>
            {/* 차트 */}
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={mainData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="mainGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={SYMBOL_COLORS[activeSymbol]} stopOpacity={0.25} />
                    <stop offset="95%" stopColor={SYMBOL_COLORS[activeSymbol]} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="t" tick={{ fill: '#4b5563', fontSize: 8 }} axisLine={false} tickLine={false} interval={Math.floor(mainData.length / 6)} />
                <YAxis tick={{ fill: '#4b5563', fontSize: 8 }} axisLine={false} tickLine={false}
                  tickFormatter={v => v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v.toFixed(activeSymbol === 'XRPUSDT' ? 3 : 0)} />
                <Tooltip contentStyle={{ background: '#161b2e', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 6, fontSize: 10 }}
                  labelStyle={{ color: '#6b7280' }} itemStyle={{ color: SYMBOL_COLORS[activeSymbol] }} />
                <Area type="monotone" dataKey="v" stroke={SYMBOL_COLORS[activeSymbol]} strokeWidth={2} fill="url(#mainGrad)" dot={false} activeDot={{ r: 3 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* 사이드 전략 지표 */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ background: '#0d1117', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 8, padding: '12px' }}>
              <div style={{ fontSize: 9, color: '#6b7280', letterSpacing: 1, marginBottom: 10 }}>전략 성과 지표</div>
              {STRATEGY_METRICS.map(m => (
                <div key={m.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontSize: 9, color: '#6b7280' }}>{m.label}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, color: m.color }}>{m.val}</span>
                </div>
              ))}
            </div>
            {/* 타이머 */}
            <div style={{ background: '#0d1117', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, padding: '12px', textAlign: 'center' }}>
              <div style={{ fontSize: 9, color: '#6b7280', marginBottom: 6 }}>다음 신호까지</div>
              <div style={{ fontSize: 28, fontWeight: 700, color: '#00d4ff', fontFamily: 'Share Tech Mono, monospace', letterSpacing: 2 }}>01:24</div>
              <div style={{ fontSize: 8, color: '#4b5563', marginTop: 4 }}>NEXT SCAN</div>
            </div>
          </div>
        </div>

        {/* ── 탭: 포지션 / 백테스트 / 신호 ── */}
        <div style={{ background: '#0d1117', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 8 }}>
          <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            {[
              { id: 'positions', label: '⚡ 오픈 포지션' },
              { id: 'backtest', label: '📊 백테스트 결과' },
              { id: 'signals', label: '🔔 신호 로그' },
            ].map(t => (
              <button key={t.id} onClick={() => setTab(t.id as any)} style={{
                padding: '10px 16px', fontSize: 10, cursor: 'pointer', fontWeight: tab === t.id ? 700 : 400,
                background: 'transparent', border: 'none',
                borderBottom: `2px solid ${tab === t.id ? '#00d4ff' : 'transparent'}`,
                color: tab === t.id ? '#00d4ff' : '#6b7280',
              }}>{t.label}</button>
            ))}
          </div>

          {/* 포지션 테이블 */}
          {tab === 'positions' && (
            <div style={{ overflowX: 'auto', padding: '4px 0' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 10 }}>
                <thead>
                  <tr style={{ background: 'rgba(0,212,255,0.03)' }}>
                    {['심볼', '방향', '수량', '진입가', '현재가', 'P&L', 'P&L%', '청산가', '레버리지', '마진', 'TP'].map(h => (
                      <th key={h} style={{ padding: '8px 10px', textAlign: 'center', color: '#4b5563', fontSize: 9, fontWeight: 700, letterSpacing: 0.5, whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {POSITIONS.map((p, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      <td style={{ padding: '8px 10px', textAlign: 'center' }}>
                        <span style={{ color: SYMBOL_COLORS[p.symbol], fontWeight: 700 }}>{p.symbol}</span>
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'center' }}>
                        <span style={{ padding: '2px 8px', borderRadius: 3, background: p.side === 'LONG' ? 'rgba(0,255,136,0.15)' : 'rgba(255,71,87,0.15)', color: p.side === 'LONG' ? '#00ff88' : '#ff4757', fontWeight: 700, fontSize: 9 }}>{p.side}</span>
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: '#e5e7eb' }}>{p.size.toLocaleString()}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: '#9ca3af' }}>{p.entryPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: '#e5e7eb', fontWeight: 700 }}>{p.markPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: p.pnl >= 0 ? '#00ff88' : '#ff4757', fontWeight: 700 }}>
                        {p.pnl >= 0 ? '+' : ''}{p.pnl.toFixed(2)}
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: p.pnlPct >= 0 ? '#00ff88' : '#ff4757' }}>
                        {p.pnlPct >= 0 ? '+' : ''}{p.pnlPct.toFixed(3)}%
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: '#ff4757', fontSize: 9 }}>{p.liqPrice.toFixed(4)}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', color: '#ffd166' }}>{p.leverage}x</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: '#9ca3af' }}>{p.margin.toFixed(2)}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: '#6b7280' }}>{p.tp > 0 ? p.tp.toFixed(4) : '—'}</td>
                    </tr>
                  ))}
                  <tr style={{ borderTop: '1px solid rgba(0,212,255,0.15)', background: 'rgba(0,212,255,0.03)' }}>
                    <td colSpan={5} style={{ padding: '8px 10px', color: '#6b7280', fontSize: 9 }}>합계</td>
                    <td style={{ padding: '8px 10px', textAlign: 'right', color: totalPnl >= 0 ? '#00ff88' : '#ff4757', fontWeight: 700 }}>
                      {totalPnl >= 0 ? '+' : ''}{totalPnl.toFixed(2)} USDT
                    </td>
                    <td colSpan={5} style={{ padding: '8px 10px', textAlign: 'right', color: '#6b7280', fontSize: 9 }}>
                      총 마진: {totalMargin.toFixed(2)} USDT
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}

          {/* 백테스트 결과 */}
          {tab === 'backtest' && (
            <div style={{ overflowX: 'auto', padding: '4px 0' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 10 }}>
                <thead>
                  <tr style={{ background: 'rgba(0,212,255,0.03)' }}>
                    {['전략명', '트레이드', '승률', 'P&L', '최대낙폭', '샤프', '승', '손실', '상태'].map(h => (
                      <th key={h} style={{ padding: '8px 10px', textAlign: 'center', color: '#4b5563', fontSize: 9, fontWeight: 700, letterSpacing: 0.5 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {BACKTEST_RESULTS.map((r, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', background: r.status === 'live' ? 'rgba(0,255,136,0.03)' : 'transparent' }}>
                      <td style={{ padding: '8px 10px', color: r.status === 'live' ? '#00ff88' : r.status === 'active' ? '#00d4ff' : '#6b7280', fontWeight: 700 }}>{r.name}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', color: '#e5e7eb' }}>{r.trades}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', color: r.winRate > 50 ? '#00ff88' : r.winRate > 30 ? '#ffd166' : '#ff4757' }}>{r.winRate}%</td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: r.pnl >= 0 ? '#00ff88' : '#ff4757', fontWeight: 700 }}>
                        {r.pnl !== 0 ? `${r.pnl >= 0 ? '+' : ''}${r.pnl.toFixed(2)}` : '—'}
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', color: '#ff4757' }}>{r.maxDD !== 0 ? `${r.maxDD.toFixed(2)}%` : '—'}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', color: '#a855f7' }}>{r.sharpe !== 0 ? r.sharpe.toFixed(2) : '—'}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', color: '#00ff88' }}>{r.wins !== 0 ? r.wins : '—'}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', color: '#ff4757' }}>{r.loss !== 0 ? r.loss.toFixed(2) : '—'}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'center' }}>
                        <span style={{ padding: '2px 8px', borderRadius: 3, fontSize: 9, fontWeight: 700,
                          background: r.status === 'live' ? 'rgba(0,255,136,0.15)' : r.status === 'active' ? 'rgba(0,212,255,0.1)' : 'rgba(107,114,128,0.15)',
                          color: r.status === 'live' ? '#00ff88' : r.status === 'active' ? '#00d4ff' : '#6b7280',
                          border: `1px solid ${r.status === 'live' ? '#00ff8855' : r.status === 'active' ? '#00d4ff55' : 'rgba(107,114,128,0.3)'}`,
                        }}>{r.status.toUpperCase()}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* 신호 로그 */}
          {tab === 'signals' && (
            <div style={{ padding: '12px 16px' }}>
              {[
                { time: '2026-05-13 08:41', symbol: 'BTCUSDT', action: 'LONG 진입', reason: 'MU+WDC +3.2% → 반도체 급등 시나리오 → BTC 강세 연동', color: '#00ff88' },
                { time: '2026-05-13 07:22', symbol: 'SOLUSDT', action: 'SHORT 진입', reason: 'SOX -1.8% → 반도체 약세 → SOL 하락 헤지', color: '#ff4757' },
                { time: '2026-05-12 23:15', symbol: 'XRPUSDT', action: 'LONG 청산', reason: 'TP 도달 +2.1% → 수익 실현', color: '#ffd166' },
                { time: '2026-05-12 21:44', symbol: 'ETHUSDT', action: 'LONG 진입', reason: 'KOSPI 강보합 +0.64% → 위험자산 선호 → ETH 매수', color: '#00ff88' },
                { time: '2026-05-12 18:30', symbol: 'BTCUSDT', action: 'SHORT 청산', reason: 'VIX 28.7 → 리스크오프 해소 → 인버스 청산', color: '#ffd166' },
              ].map((log, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.04)', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: 9, color: '#4b5563', whiteSpace: 'nowrap', minWidth: 120, fontFamily: 'Share Tech Mono, monospace' }}>{log.time}</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: SYMBOL_COLORS[log.symbol as Symbol], minWidth: 70 }}>{log.symbol}</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: log.color, minWidth: 80 }}>{log.action}</span>
                  <span style={{ fontSize: 9, color: '#6b7280', lineHeight: 1.4 }}>{log.reason}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── 멀티 차트 그리드 4×4 ── */}
        <div>
          <div style={{ fontSize: 10, fontWeight: 700, color: '#6b7280', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 10 }}>
            멀티 차트 그리드 — BTC / ETH / SOL / XRP × 4 타임프레임
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {SYMBOLS.map(symbol =>
              TFS.map(tf => (
                <MiniChart key={`${symbol}-${tf}`} symbol={symbol} tf={tf} />
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
