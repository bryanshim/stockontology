// ─── ontologyData.ts ───
// SOX-KOSPI 온톨로지 지식그래프 데이터 (v2 확장판)
// 마이크론/샌디스크 개별주 + 5종목 KODEX + 강보합 조건 추가

export interface KGNode {
  id: string;
  label: string;
  type: string;
  layer: 'data' | 'signal' | 'strategy' | 'performance' | 'consulting' | 'risk' | 'market';
  color: string;
  r: number;
  desc: string;
  props?: [string, string][];
  x?: number;
  y?: number;
  fx?: number | null;
  fy?: number | null;
}

export interface KGLink {
  source: string | KGNode;
  target: string | KGNode;
  label: string;
  strength: number;
  color: string;
}

export interface SWRLRule {
  id: string;
  name: string;
  rule: string;
  desc: string;
  color: string;
}

const C = {
  data: '#00d4ff',
  signal: '#f0b429',
  strategy: '#a855f7',
  performance: '#00ff88',
  consulting: '#00c8a0',
  risk: '#ff4757',
  market: '#0088bb',
};

export const kgNodes: KGNode[] = [
  // ── Market Layer ──
  {
    id: 'sox', label: 'SOX\n지수', type: 'owl:Class', layer: 'market', color: C.data, r: 26,
    desc: '필라델피아 반도체 지수. PHLX Semiconductor Sector Index. 미국 반도체 업종 30개 기업 시가총액 가중 지수.',
    props: [['owl:sameAs', ':PHLX_SOX'], ['hasTickerSymbol', '"^SOX"'], ['hasCurrentValue', '5,049.18'], ['hasExchange', ':NASDAQ']],
  },
  {
    id: 'micron', label: 'Micron\n마이크론', type: 'owl:Individual', layer: 'market', color: '#00b4d8', r: 22,
    desc: 'Micron Technology (MU). 미국 최대 메모리 반도체 기업. DRAM/NAND 제조. 삼성전자·하이닉스와 직접 경쟁. SOX보다 삼전·하이닉스와 상관관계 높음.',
    props: [['hasTickerSymbol', '"MU"'], ['hasExchange', ':NASDAQ'], ['hasCurrentPrice', '$108.42'], ['hasCorrelation_Samsung', '0.82'], ['hasCorrelation_Hynix', '0.79'], ['hasCorrelation_SOX', '0.74'], ['rdfs:comment', '"DRAM/NAND 직접 경쟁사"']],
  },
  {
    id: 'sandisk', label: 'SanDisk\n샌디스크', type: 'owl:Individual', layer: 'market', color: '#48cae4', r: 20,
    desc: 'SanDisk (WDC/SNDK). Western Digital 분사. NAND 플래시 전문. 삼성전자 반도체 사업부와 높은 상관관계.',
    props: [['hasTickerSymbol', '"SNDK"'], ['hasParent', ':WesternDigital'], ['hasCurrentPrice', '$47.83'], ['hasCorrelation_Samsung', '0.78'], ['hasCorrelation_Hynix', '0.75'], ['rdfs:comment', '"NAND 플래시 전문 기업"']],
  },
  {
    id: 'samsung', label: '삼성전자\n반도체', type: 'owl:Individual', layer: 'market', color: '#0077b6', r: 20,
    desc: '삼성전자 반도체 사업부. DRAM/NAND 세계 1위. 마이크론+샌디스크 주가 합산이 삼전+하이닉스 주가를 선행 반영.',
    props: [['hasTickerCode', '"005930"'], ['hasExchange', ':KRX'], ['hasCurrentPrice', '71,500원'], ['hasSector', 'DRAM/NAND/Logic']],
  },
  {
    id: 'hynix', label: 'SK하이닉스', type: 'owl:Individual', layer: 'market', color: '#0096c7', r: 18,
    desc: 'SK하이닉스. DRAM 세계 2위. HBM(고대역폭메모리) 선도. 마이크론 주가와 높은 상관관계.',
    props: [['hasTickerCode', '"000660"'], ['hasExchange', ':KRX'], ['hasCurrentPrice', '178,000원'], ['hasSector', 'DRAM/HBM']],
  },
  {
    id: 'kospi200', label: 'KOSPI\n200', type: 'owl:Class', layer: 'market', color: C.data, r: 20,
    desc: 'KOSPI 200 지수. 한국 유가증권시장 시가총액 상위 200개 종목. 국내 지수 강보합 판단 기준.',
    props: [['hasTickerSymbol', '"KOSPI200"'], ['hasExchange', ':KRX'], ['hasCurrentValue', '342.87'], ['hasStrongBullThreshold', '+0.5%']],
  },
  {
    id: 'vix', label: 'VIX\n공포지수', type: 'owl:Class', layer: 'market', color: C.risk, r: 15,
    desc: 'CBOE Volatility Index. 시장 공포 지수. 30 초과 시 고위험 구간.',
    props: [['hasCurrentValue', '18.42'], ['hasThreshold', '30.0'], ['hasRiskLevel', ':NORMAL']],
  },
  {
    id: 'semi_cycle', label: '반도체\n사이클', type: 'owl:Class', layer: 'market', color: C.data, r: 14,
    desc: '반도체 산업 경기 사이클. 업사이클/다운사이클 구분. SOX·마이크론과 높은 상관관계.',
    props: [['hasCurrentPhase', ':UPCYCLE'], ['hasCycleDuration', '24~36개월']],
  },

  // ── Data Layer ──
  {
    id: 'micron_return', label: 'MU\n등락률', type: 'owl:DatatypeProperty', layer: 'data', color: '#00b4d8', r: 14,
    desc: '마이크론(MU) 일별 등락률. SOX보다 삼전·하이닉스와 상관관계 높아 더 정밀한 신호 생성.',
    props: [['rdfs:range', 'xsd:decimal'], ['hasUnit', 'percentage'], ['hasCorrelation_KOSPI200', '0.76']],
  },
  {
    id: 'sandisk_return', label: 'SNDK\n등락률', type: 'owl:DatatypeProperty', layer: 'data', color: '#48cae4', r: 14,
    desc: '샌디스크(SNDK) 일별 등락률. NAND 사이클 선행 지표.',
    props: [['rdfs:range', 'xsd:decimal'], ['hasUnit', 'percentage'], ['hasCorrelation_KOSPI200', '0.71']],
  },
  {
    id: 'combined_signal', label: 'MU+SNDK\n합산신호', type: 'owl:Class', layer: 'data', color: '#90e0ef', r: 16,
    desc: '마이크론+샌디스크 등락률 합산 신호. SOX 단독보다 삼전·하이닉스 예측력 향상.',
    props: [['hasFormula', '(MU_return + SNDK_return) / 2'], ['hasCorrelation_Samsung', '0.83'], ['hasCorrelation_Hynix', '0.80']],
  },
  {
    id: 'sox_return', label: 'SOX\n등락률', type: 'owl:DatatypeProperty', layer: 'data', color: C.data, r: 15,
    desc: 'SOX 일별 등락률. 매매 신호 생성의 기본 입력값.',
    props: [['rdfs:range', 'xsd:decimal'], ['hasCurrentValue', '+3.21%']],
  },
  {
    id: 'sox_ma20', label: 'SOX\nMA20', type: 'owl:DatatypeProperty', layer: 'data', color: C.signal, r: 13,
    desc: 'SOX 20일 단순이동평균. 전략C/D의 추가 필터.',
    props: [['hasValue', '4921.44'], ['hasPeriod', '20']],
  },
  {
    id: 'kospi_status', label: 'KOSPI\n강보합', type: 'owl:Class', layer: 'data', color: '#90e0ef', r: 15,
    desc: '국내 KOSPI200 지수 강보합 상태. +0.5% 이상 상승 시 강보합 판정. KODEX증권 매수 조건.',
    props: [['hasThreshold', '+0.5%'], ['hasAction', ':BUY_KODEX_Securities'], ['rdfs:comment', '"강보합 = KOSPI200 > +0.5%"']],
  },
  {
    id: 'data_pipeline', label: '데이터\n파이프라인', type: 'owl:Class', layer: 'data', color: C.data, r: 15,
    desc: '자동화된 시장 데이터 수집. Bloomberg/Yahoo Finance API 연동.',
    props: [['hasSchedule', 'daily 21:00 ET'], ['hasLatency', '<1min']],
  },

  // ── Signal Layer ──
  {
    id: 'signal', label: 'SOX추종\n시그널', type: 'owl:Class', layer: 'signal', color: C.signal, r: 20,
    desc: '온톨로지 추론 엔진이 생성하는 매매 시그널. BUY/SELL/HOLD 3가지 타입.',
    props: [['hasType', ':BUY | :SELL | :HOLD'], ['hasTrigger', ':SOX_Return | :MU_Return']],
  },
  {
    id: 'buy_signal', label: '매수\n신호', type: 'owl:Individual', layer: 'signal', color: C.performance, r: 14,
    desc: 'SOX/MU/SNDK 등락률 > 임계값 시 생성되는 매수 신호.',
    props: [['hasCondition', 'SOX_return > threshold OR MU_return > threshold'], ['hasStrength', ':STRONG | :WEAK']],
  },
  {
    id: 'sell_signal', label: '매도\n신호', type: 'owl:Individual', layer: 'signal', color: C.risk, r: 14,
    desc: 'SOX/MU/SNDK 등락률 < -임계값 시 생성되는 인버스 매수 신호.',
    props: [['hasCondition', 'SOX_return < -threshold'], ['hasAction', ':BUY_KODEX_INV']],
  },
  {
    id: 'securities_signal', label: '증권주\n매수신호', type: 'owl:Individual', layer: 'signal', color: '#f0b429', r: 15,
    desc: '국내 KOSPI200 강보합(+0.5% 이상) 시 생성되는 KODEX증권 매수 신호.',
    props: [['hasCondition', 'KOSPI200_return > 0.5%'], ['hasAction', ':BUY_KODEX_Securities'], ['hasRationale', '"증권업종은 시장 강세 시 베타 높아 초과수익"']],
  },
  {
    id: 'threshold_filter', label: '임계값\n필터', type: 'owl:Restriction', layer: 'signal', color: C.signal, r: 13,
    desc: '노이즈 제거 임계값 필터. 기본값 0.5%.',
    props: [['hasDefaultValue', '0.5%'], ['hasOptimalValue', '0.5%']],
  },
  {
    id: 'ma20_cross', label: 'MA20\n크로스', type: 'owl:Class', layer: 'signal', color: C.signal, r: 13,
    desc: 'SOX 현재가와 20일 이동평균 교차 신호.',
    props: [['hasType', 'GOLDEN_CROSS | DEAD_CROSS']],
  },

  // ── Strategy Layer (5종목) ──
  {
    id: 'strategy', label: '5종목\n스위칭전략', type: 'owl:Class', layer: 'strategy', color: C.strategy, r: 26,
    desc: '5종목 KODEX ETF 스위칭 전략. SOX/MU/SNDK 신호 + KOSPI 강보합 조건으로 최적 ETF 선택.',
    props: [['hasETFs', '5개 KODEX ETF'], ['hasSignalSources', 'SOX, MU, SNDK, KOSPI200'], ['hasVariant', '4개 전략']],
  },
  {
    id: 'kodex200', label: 'KODEX\n200', type: 'owl:Individual', layer: 'strategy', color: C.data, r: 18,
    desc: 'KODEX 200 ETF (069500). KOSPI200 1배 추종. SOX/MU 상승 + KOSPI 중립 시 매수.',
    props: [['hasTickerCode', '"069500"'], ['hasNAV', '37,450원'], ['hasTER', '0.15%'], ['hasTrigger', 'SOX>0 AND KOSPI_neutral']],
  },
  {
    id: 'kodex_inv', label: 'KODEX\n인버스', type: 'owl:Individual', layer: 'strategy', color: C.risk, r: 18,
    desc: 'KODEX 인버스 ETF (114800). KOSPI200 -1배. 미국장 폭락 시 매수.',
    props: [['hasTickerCode', '"114800"'], ['hasLeverage', '-1x'], ['hasTrigger', 'SOX<-1% OR MU<-2%']],
  },
  {
    id: 'kodex_semi', label: 'KODEX\n반도체', type: 'owl:Individual', layer: 'strategy', color: '#a8dadc', r: 18,
    desc: 'KODEX 반도체 ETF (091160). 국내 반도체 업종 추종. MU+SNDK 강한 상승 시 매수.',
    props: [['hasTickerCode', '"091160"'], ['hasNAV', '43,200원'], ['hasTER', '0.45%'], ['hasTrigger', 'MU>2% AND SNDK>2%'], ['hasComponents', '삼성전자, SK하이닉스, DB하이텍 등']],
  },
  {
    id: 'kodex_battery', label: 'KODEX\n2차전지', type: 'owl:Individual', layer: 'strategy', color: '#a8e6cf', r: 18,
    desc: 'KODEX 2차전지산업 ETF (305720). 배터리 업종 추종. 전기차 사이클 연동.',
    props: [['hasTickerCode', '"305720"'], ['hasNAV', '12,840원'], ['hasTER', '0.45%'], ['hasTrigger', 'EV_cycle_up AND KOSPI_strong'], ['hasComponents', 'LG에너지솔루션, 삼성SDI, SK이노베이션']],
  },
  {
    id: 'kodex_securities', label: 'KODEX\n증권', type: 'owl:Individual', layer: 'strategy', color: '#ffd166', r: 20,
    desc: 'KODEX 증권 ETF (102970). 국내 증권업종 추종. KOSPI200 강보합(+0.5% 이상) 시 매수. 시장 강세 시 베타 높아 초과수익 기대.',
    props: [['hasTickerCode', '"102970"'], ['hasNAV', '8,920원'], ['hasTER', '0.45%'], ['hasTrigger', 'KOSPI200_return > 0.5%'], ['hasBeta', '1.35'], ['hasRationale', '"증권업 = 시장 레버리지"']],
  },
  {
    id: 'strategy_c', label: '전략C\nMA결합', type: 'owl:Individual', layer: 'strategy', color: C.performance, r: 20,
    desc: '전략C: MA20 크로스 결합. SOX 신호 + MA20 상향돌파 동시 충족 시 강한 매수 신호. 최고 수익률.',
    props: [['hasTotalReturn', '+134.7%'], ['hasAnnualReturn', '+16.1%'], ['hasMDD', '-14.2%'], ['hasSharpe', '1.98'], ['isOptimal', 'true']],
  },
  {
    id: 'strategy_d', label: '전략D\n리스크관리', type: 'owl:Individual', layer: 'strategy', color: C.strategy, r: 18,
    desc: '전략D: 리스크 관리 통합. VIX 연동 포지션 조절 + 트레일링 스탑로스.',
    props: [['hasTotalReturn', '+118.9%'], ['hasMDD', '-9.8%'], ['hasSharpe', '2.14']],
  },

  // ── Performance Layer ──
  {
    id: 'performance', label: '전략\n성과', type: 'owl:Class', layer: 'performance', color: C.performance, r: 18,
    desc: '백테스팅 성과 지표. 총수익률, 연환산수익률, MDD, 샤프지수, 승률.',
    props: [['hasMetrics', '6개 지표'], ['hasBacktestPeriod', '6년']],
  },
  {
    id: 'backtesting', label: '백테스팅\n엔진', type: 'owl:Class', layer: 'performance', color: C.performance, r: 16,
    desc: '전략 검증 백테스팅 엔진. Python Backtrader 기반. 워크포워드 검증.',
    props: [['hasFramework', 'Python Backtrader'], ['hasDataRange', '2015-2024']],
  },

  // ── Risk Layer ──
  {
    id: 'risk_mgmt', label: '리스크\n관리체계', type: 'owl:Class', layer: 'risk', color: C.risk, r: 18,
    desc: '투자 리스크 관리 온톨로지. VaR/CVaR, 스탑로스, 포지션 사이징.',
    props: [['hasComponents', 'VaR, CVaR, StopLoss, PositionSizing']],
  },
  {
    id: 'stop_loss', label: '스탑\n로스', type: 'owl:Individual', layer: 'risk', color: C.risk, r: 13,
    desc: '트레일링 스탑로스. MDD 3% 초과 시 자동 청산.',
    props: [['hasType', 'Trailing Stop'], ['hasThreshold', '-3%']],
  },

  // ── Consulting Layer ──
  {
    id: 'consulting', label: '전략\n컨설팅', type: 'owl:Class', layer: 'consulting', color: C.consulting, r: 18,
    desc: '투자 전략 컨설팅. 6단계 프레임워크.',
    props: [['hasFramework', '6-Step Consulting']],
  },
  {
    id: 'ontology_engine', label: '온톨로지\n엔진', type: 'owl:Class', layer: 'consulting', color: C.consulting, r: 16,
    desc: 'Apache Jena 기반 OWL2 추론 엔진. SWRL 규칙 실행, SPARQL 쿼리.',
    props: [['hasFramework', 'Apache Jena 4.x'], ['hasReasoner', 'Pellet / HermiT']],
  },
  {
    id: 'tobe_model', label: 'TO-BE\n모델', type: 'owl:Class', layer: 'consulting', color: C.consulting, r: 14,
    desc: 'AS-IS 페인포인트 해소를 위한 TO-BE 목표 모델.',
    props: [['hasPainPoints', '5개'], ['hasKPI', '연환산 +16.1%']],
  },
  {
    id: 'modeling', label: '모델링\n시뮬레이션', type: 'owl:Class', layer: 'consulting', color: C.consulting, r: 14,
    desc: '반복 최적화 모델링. 격자탐색 + 몬테카를로.',
    props: [['hasIterations', '1000+']],
  },
];

// ─── Object Properties (Links) ───
export const kgLinks: KGLink[] = [
  // Micron/SanDisk → Samsung/Hynix (핵심 상관관계)
  { source: 'micron', target: 'samsung', label: 'correlates(0.82)', strength: 0.9, color: '#00b4d8' },
  { source: 'micron', target: 'hynix', label: 'correlates(0.79)', strength: 0.85, color: '#00b4d8' },
  { source: 'sandisk', target: 'samsung', label: 'correlates(0.78)', strength: 0.85, color: '#48cae4' },
  { source: 'sandisk', target: 'hynix', label: 'correlates(0.75)', strength: 0.8, color: '#48cae4' },
  { source: 'micron', target: 'sox', label: 'componentOf', strength: 0.7, color: '#00b4d8' },
  { source: 'sandisk', target: 'sox', label: 'relatedTo', strength: 0.65, color: '#48cae4' },

  // MU+SNDK → Combined Signal
  { source: 'micron', target: 'micron_return', label: 'hasDailyReturn', strength: 0.9, color: '#00b4d8' },
  { source: 'sandisk', target: 'sandisk_return', label: 'hasDailyReturn', strength: 0.9, color: '#48cae4' },
  { source: 'micron_return', target: 'combined_signal', label: 'contributesTo', strength: 0.85, color: '#90e0ef' },
  { source: 'sandisk_return', target: 'combined_signal', label: 'contributesTo', strength: 0.85, color: '#90e0ef' },
  { source: 'combined_signal', target: 'signal', label: 'enhances', strength: 0.8, color: '#90e0ef' },

  // SOX Data → Signal
  { source: 'sox', target: 'sox_return', label: 'hasDailyReturn', strength: 0.9, color: C.data },
  { source: 'sox', target: 'sox_ma20', label: 'hasMA20', strength: 0.7, color: C.data },
  { source: 'sox_return', target: 'signal', label: 'triggers', strength: 0.9, color: C.signal },
  { source: 'sox_return', target: 'threshold_filter', label: 'filteredBy', strength: 0.8, color: C.signal },
  { source: 'threshold_filter', target: 'buy_signal', label: 'generates', strength: 0.85, color: C.performance },
  { source: 'threshold_filter', target: 'sell_signal', label: 'generates', strength: 0.85, color: C.risk },
  { source: 'sox_ma20', target: 'ma20_cross', label: 'determines', strength: 0.75, color: C.signal },
  { source: 'ma20_cross', target: 'buy_signal', label: 'confirms', strength: 0.7, color: C.performance },

  // KOSPI 강보합 → 증권주 신호
  { source: 'kospi200', target: 'kospi_status', label: 'determines', strength: 0.9, color: '#ffd166' },
  { source: 'kospi_status', target: 'securities_signal', label: 'triggers', strength: 0.9, color: '#ffd166' },
  { source: 'securities_signal', target: 'kodex_securities', label: 'buyAction', strength: 0.95, color: '#ffd166' },

  // Signal → 5종목 ETF
  { source: 'buy_signal', target: 'kodex200', label: 'triggers', strength: 0.85, color: C.performance },
  { source: 'sell_signal', target: 'kodex_inv', label: 'triggers', strength: 0.9, color: C.risk },
  { source: 'combined_signal', target: 'kodex_semi', label: 'triggers', strength: 0.85, color: '#a8dadc' },
  { source: 'signal', target: 'kodex_battery', label: 'conditionalTrigger', strength: 0.6, color: '#a8e6cf' },

  // Strategy
  { source: 'strategy', target: 'kodex200', label: 'includes', strength: 0.7, color: C.strategy },
  { source: 'strategy', target: 'kodex_inv', label: 'includes', strength: 0.7, color: C.strategy },
  { source: 'strategy', target: 'kodex_semi', label: 'includes', strength: 0.7, color: C.strategy },
  { source: 'strategy', target: 'kodex_battery', label: 'includes', strength: 0.65, color: C.strategy },
  { source: 'strategy', target: 'kodex_securities', label: 'includes', strength: 0.7, color: C.strategy },
  { source: 'strategy', target: 'strategy_c', label: 'hasVariant', strength: 0.7, color: C.performance },
  { source: 'strategy', target: 'strategy_d', label: 'hasVariant', strength: 0.7, color: C.strategy },
  { source: 'ma20_cross', target: 'strategy_c', label: 'usedIn', strength: 0.8, color: C.performance },
  { source: 'risk_mgmt', target: 'strategy_d', label: 'integratedIn', strength: 0.8, color: C.risk },

  // Performance
  { source: 'strategy_c', target: 'performance', label: 'achieves', strength: 0.9, color: C.performance },
  { source: 'strategy_d', target: 'performance', label: 'achieves', strength: 0.85, color: C.performance },
  { source: 'backtesting', target: 'performance', label: 'validates', strength: 0.9, color: C.performance },

  // Risk
  { source: 'vix', target: 'risk_mgmt', label: 'informs', strength: 0.8, color: C.risk },
  { source: 'risk_mgmt', target: 'stop_loss', label: 'includes', strength: 0.8, color: C.risk },

  // Consulting
  { source: 'consulting', target: 'ontology_engine', label: 'designs', strength: 0.8, color: C.consulting },
  { source: 'ontology_engine', target: 'signal', label: 'infers', strength: 0.9, color: C.consulting },
  { source: 'consulting', target: 'tobe_model', label: 'defines', strength: 0.75, color: C.consulting },
  { source: 'modeling', target: 'backtesting', label: 'iterates', strength: 0.85, color: C.consulting },
  { source: 'modeling', target: 'strategy', label: 'optimizes', strength: 0.8, color: C.consulting },

  // Samsung/Hynix → KOSPI
  { source: 'samsung', target: 'kospi200', label: 'heavyWeight', strength: 0.85, color: '#0077b6' },
  { source: 'hynix', target: 'kospi200', label: 'heavyWeight', strength: 0.8, color: '#0096c7' },
  { source: 'semi_cycle', target: 'micron', label: 'drives', strength: 0.7, color: C.data },
  { source: 'semi_cycle', target: 'sandisk', label: 'drives', strength: 0.65, color: C.data },
  { source: 'data_pipeline', target: 'micron_return', label: 'collects', strength: 0.7, color: C.data },
  { source: 'data_pipeline', target: 'sandisk_return', label: 'collects', strength: 0.7, color: C.data },
];

// ─── SWRL Rules (확장판) ───
export const swrlRules: SWRLRule[] = [
  {
    id: 'R1',
    name: 'SOX 상승 → KODEX200 매수',
    rule: 'SOX(?s) ∧ hasDailyReturn(?s, ?r) ∧ greaterThan(?r, 0.0) → hasSignal(?s, BUY_KODEX200)',
    desc: 'SOX 일별 등락률 > 0% 시 KODEX200 매수 신호 생성',
    color: '#00ff88',
  },
  {
    id: 'R2',
    name: 'SOX 하락 → KODEX인버스 매수',
    rule: 'SOX(?s) ∧ hasDailyReturn(?s, ?r) ∧ lessThan(?r, 0.0) → hasSignal(?s, BUY_KODEX_INV)',
    desc: 'SOX 등락률 < 0% 시 KODEX인버스 매수 (미국장 폭락 대응)',
    color: '#ff4757',
  },
  {
    id: 'R3',
    name: 'MU+SNDK 강세 → KODEX반도체 매수',
    rule: 'Micron(?m) ∧ SanDisk(?s) ∧ hasDailyReturn(?m, ?r1) ∧ hasDailyReturn(?s, ?r2) ∧ greaterThan(?r1, 2.0) ∧ greaterThan(?r2, 2.0) → hasSignal(:combined, BUY_KODEX_SEMI)',
    desc: 'MU > +2% AND SNDK > +2% 동시 충족 시 KODEX반도체 매수 (SOX보다 정밀)',
    color: '#a8dadc',
  },
  {
    id: 'R4',
    name: 'KOSPI 강보합 → KODEX증권 매수',
    rule: 'KOSPI200(?k) ∧ hasDailyReturn(?k, ?r) ∧ greaterThan(?r, 0.5) → hasSignal(?k, BUY_KODEX_SECURITIES)',
    desc: '국내 KOSPI200 > +0.5% 강보합 시 KODEX증권 매수 (증권업 베타 1.35)',
    color: '#ffd166',
  },
  {
    id: 'R5',
    name: 'MA20 결합 강화 (전략C)',
    rule: 'SOX(?s) ∧ hasSignal(?s, BUY) ∧ hasMA20Cross(?s, ABOVE) → hasStrongSignal(?s, BUY_STRONG)',
    desc: 'SOX 매수 신호 + MA20 상향돌파 동시 충족 시 강한 매수 신호',
    color: '#a855f7',
  },
  {
    id: 'R6',
    name: 'VIX 고위험 → 포지션 축소',
    rule: 'VIX(?v) ∧ hasValue(?v, ?x) ∧ greaterThan(?x, 30) → hasRiskLevel(?v, HIGH) ∧ reducePosition(0.5)',
    desc: 'VIX > 30 고위험 구간 시 포지션 50% 축소, 현금 비중 확대',
    color: '#ff9f43',
  },
  {
    id: 'R7',
    name: '미국장 폭락 → 전량 인버스 전환',
    rule: 'SOX(?s) ∧ hasDailyReturn(?s, ?r) ∧ lessThan(?r, -2.0) → hasSignal(?s, FULL_INVERSE)',
    desc: 'SOX < -2% 폭락 시 KODEX인버스 전량 매수 (강력 하락 대응)',
    color: '#ff4757',
  },
  {
    id: 'R8',
    name: '스탑로스 자동 트리거',
    rule: 'Position(?p) ∧ hasDrawdown(?p, ?d) ∧ lessThan(?d, -0.03) → triggerStopLoss(?p)',
    desc: '포지션 낙폭 -3% 초과 시 자동 스탑로스 실행 (전략D)',
    color: '#ff9f43',
  },
];

// ─── Signal Log Data (5종목 확장) ───
export const signalLogData = [
  { date: '2024-12-27', sox: '+3.21%', mu: '+4.12%', sndk: '+3.87%', kospi: '+0.64%', signal: '매수', action: 'KODEX반도체 매수', k200: '+0.87%', kinv: '-0.87%', pos: 'SEMI', ret: '+1.24%' },
  { date: '2024-12-26', sox: '-1.45%', mu: '-2.18%', sndk: '-1.92%', kospi: '-0.52%', signal: '매도', action: 'KODEX인버스 매수', k200: '-0.62%', kinv: '+0.62%', pos: 'INV', ret: '+0.62%' },
  { date: '2024-12-24', sox: '+0.32%', mu: '+0.45%', sndk: '+0.28%', kospi: '+0.82%', signal: '증권매수', action: 'KODEX증권 매수', k200: '+0.18%', kinv: '-0.18%', pos: 'SEC', ret: '+1.08%' },
  { date: '2024-12-23', sox: '+2.18%', mu: '+3.42%', sndk: '+2.91%', kospi: '+1.24%', signal: '강매수', action: 'KODEX반도체+증권', k200: '+1.24%', kinv: '-1.24%', pos: 'SEMI+SEC', ret: '+1.87%' },
  { date: '2024-12-20', sox: '-3.42%', mu: '-4.18%', sndk: '-3.76%', kospi: '-1.87%', signal: '폭락대응', action: 'KODEX인버스 전량', k200: '-1.87%', kinv: '+1.87%', pos: 'FULL_INV', ret: '+1.87%' },
  { date: '2024-12-19', sox: '-2.15%', mu: '-2.87%', sndk: '-2.34%', kospi: '-1.12%', signal: '매도', action: 'KODEX인버스 매수', k200: '-1.12%', kinv: '+1.12%', pos: 'INV', ret: '+1.12%' },
  { date: '2024-12-18', sox: '+1.87%', mu: '+2.43%', sndk: '+2.18%', kospi: '+0.94%', signal: '매수', action: 'KODEX반도체+200', k200: '+0.94%', kinv: '-0.94%', pos: 'SEMI+200', ret: '+1.42%' },
  { date: '2024-12-17', sox: '+0.45%', mu: '+0.62%', sndk: '+0.38%', kospi: '+0.55%', signal: '증권매수', action: 'KODEX증권 매수', k200: '+0.22%', kinv: '-0.22%', pos: 'SEC', ret: '+0.74%' },
  { date: '2024-12-16', sox: '-0.89%', mu: '-1.24%', sndk: '-0.97%', kospi: '-0.45%', signal: '매도', action: 'KODEX인버스 매수', k200: '-0.45%', kinv: '+0.45%', pos: 'INV', ret: '+0.45%' },
  { date: '2024-12-13', sox: '+4.12%', mu: '+5.34%', sndk: '+4.87%', kospi: '+2.18%', signal: '강매수', action: 'KODEX반도체+증권', k200: '+2.18%', kinv: '-2.18%', pos: 'SEMI+SEC', ret: '+3.12%' },
];

// ─── Strategy Compare Data ───
export const strategyCompareData = [
  { name: '전략A\n단순모멘텀', totalReturn: 87.4, annualReturn: 11.8, mdd: -18.3, sharpe: 1.47, winRate: 58.2 },
  { name: '전략B\n임계값필터', totalReturn: 112.3, annualReturn: 14.2, mdd: -15.1, sharpe: 1.73, winRate: 61.4 },
  { name: '전략C\nMA20결합', totalReturn: 134.7, annualReturn: 16.1, mdd: -14.2, sharpe: 1.98, winRate: 63.7 },
  { name: '전략D\n리스크관리', totalReturn: 118.9, annualReturn: 14.9, mdd: -9.8, sharpe: 2.14, winRate: 62.1 },
];

// ─── Walk-Forward Data ───
export const walkForwardData = [
  { period: 'WF-1', range: '2018-2020', inSample: 34.2, outSample: 28.7, efficiency: 83.9 },
  { period: 'WF-2', range: '2019-2021', inSample: 41.5, outSample: 33.2, efficiency: 80.0 },
  { period: 'WF-3', range: '2020-2022', inSample: -8.3, outSample: -11.4, efficiency: null },
  { period: 'WF-4', range: '2021-2023', inSample: 22.1, outSample: 19.8, efficiency: 89.6 },
  { period: 'WF-5', range: '2022-2024', inSample: 28.7, outSample: 24.3, efficiency: 84.7 },
];

// ─── Correlation Matrix (확장) ───
export const correlationMatrix = {
  labels: ['SOX', 'MU', 'SNDK', 'KOSPI200', 'KODEX200', 'KODEX인버스', 'VIX'],
  data: [
    [1.00, 0.88, 0.82, 0.74, 0.72, -0.71, -0.48],
    [0.88, 1.00, 0.91, 0.82, 0.79, -0.78, -0.52],
    [0.82, 0.91, 1.00, 0.76, 0.73, -0.72, -0.49],
    [0.74, 0.82, 0.76, 1.00, 0.98, -0.97, -0.42],
    [0.72, 0.79, 0.73, 0.98, 1.00, -0.99, -0.41],
    [-0.71, -0.78, -0.72, -0.97, -0.99, 1.00, 0.39],
    [-0.48, -0.52, -0.49, -0.42, -0.41, 0.39, 1.00],
  ],
};
